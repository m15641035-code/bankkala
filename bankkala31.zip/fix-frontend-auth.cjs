const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else {
      if (file.endsWith('.tsx') || file.endsWith('.ts')) results.push(file);
    }
  });
  return results;
}

const files = walk('./src');
files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;

  // Replace fetch calls to include credentials
  if (content.includes('fetch(') || content.includes('fetch (')) {
    // This is tricky. A simpler approach: just globally replace localStorage.getItem("token") with ""
    // and replace fetch(url, { ... }) with fetch(url, { credentials: 'include', ... })
    
    // Instead of complex AST, let's just do text replacements for common patterns
    content = content.replace(
      /Authorization:\s*`Bearer \$\{localStorage\.getItem\("token"\)\}`/g,
      '/* Auth Header Removed */'
    );
    
    // If there's an empty headers object, it might cause issues, but usually there's Content-Type.
    // Let's add credentials to any fetch call that has an options object.
    content = content.replace(
      /fetch\(([^,]+),\s*\{/g,
      'fetch($1, { credentials: "include",'
    );
    changed = true;
  }
  
  if (content.includes('localStorage.setItem("token"')) {
    content = content.replace(/localStorage\.setItem\("token",.*?\);/g, '');
    changed = true;
  }
  if (content.includes('localStorage.removeItem("token"')) {
    content = content.replace(/localStorage\.removeItem\("token"\);/g, '');
    changed = true;
  }
  if (content.includes('localStorage.getItem("token")')) {
    // Any remaining ones
    content = content.replace(/localStorage\.getItem\("token"\)/g, '""');
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(file, content);
  }
});
