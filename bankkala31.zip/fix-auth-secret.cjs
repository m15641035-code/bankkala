const fs = require('fs');

let auth = fs.readFileSync('src/services/authMiddleware.ts', 'utf8');
auth = auth.replace(
  /const JWT_SECRET = process\.env\.JWT_SECRET;\s*if \(!JWT_SECRET\) throw new Error\('JWT_SECRET environment variable is required'\);/g,
  ''
);
auth = auth.replace(
  /jwt\.verify\(token, JWT_SECRET,/g,
  'jwt.verify(token, process.env.JWT_SECRET!,'
);

fs.writeFileSync('src/services/authMiddleware.ts', auth);

let enc = fs.readFileSync('src/services/integrations/woocommerce/EncryptionService.ts', 'utf8');
enc = enc.replace(
  /const raw = process\.env\.ENCRYPTION_KEY;\s*if \(!raw\) throw new Error\('ENCRYPTION_KEY environment variable is required'\);\s*const key = crypto\.createHash\('sha256'\)\.update\(raw\)\.digest\(\);/g,
  `function getKey() { 
    const raw = process.env.ENCRYPTION_KEY;
    if (!raw) throw new Error('ENCRYPTION_KEY environment variable is required');
    return crypto.createHash('sha256').update(raw).digest();
  }`
);
enc = enc.replace(/const cipher = crypto\.createCipheriv\(algorithm, key, iv\);/g, 'const cipher = crypto.createCipheriv(algorithm, getKey(), iv);');
enc = enc.replace(/const decipher = crypto\.createDecipheriv\(algorithm, key, iv\);/g, 'const decipher = crypto.createDecipheriv(algorithm, getKey(), iv);');
fs.writeFileSync('src/services/integrations/woocommerce/EncryptionService.ts', enc);
