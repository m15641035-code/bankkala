const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Restore three braces
content = content.replace("localStorage.removeItem('user'); } }, [token]);", "localStorage.removeItem('user'); } } }, [token]);");
fs.writeFileSync('src/App.tsx', content);

console.log('App.tsx restored to three braces. Running tsc...');
const { execSync } = require('child_process');
try {
  execSync('npx tsc --noEmit', { stdio: 'inherit' });
  console.log('TypeScript compilation succeeded!');
} catch (e) {
  console.log('TypeScript compilation failed with error code:', e.status);
}
