import fs from 'fs';

let css = fs.readFileSync('src/index.css', 'utf8');

const themeVariables = `
@theme {
  --color-background: var(--background);
  --color-surface: var(--surface);
  --color-card: var(--card);
  --color-elevated: var(--elevated);

  --color-text-primary: var(--text-primary);
  --color-text-secondary: var(--text-secondary);
  --color-text-muted: var(--text-muted);
  --color-text-inverse: var(--text-inverse);

  --color-border-default: var(--border);
  --color-border-subtle: var(--border-subtle);

  --color-primary-default: var(--primary);
  --color-primary-hover: var(--primary-hover);
  --color-success: var(--success);
  --color-warning: var(--warning);
  --color-danger: var(--danger);

  --font-sans: "Vazirmatn", "Inter", ui-sans-serif, system-ui, sans-serif;
  --font-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace;
}

@layer base {
  :root {
    --background: #f8fafc; /* slate-50 */
    --surface: #f1f5f9; /* slate-100 */
    --card: #ffffff; /* white */
    --elevated: #ffffff; /* white */

    --text-primary: #0f172a; /* slate-900 */
    --text-secondary: #334155; /* slate-700 */
    --text-muted: #64748b; /* slate-500 */
    --text-inverse: #ffffff;

    --border: #cbd5e1; /* slate-300 */
    --border-subtle: #e2e8f0; /* slate-200 */

    --primary: #4f46e5; /* indigo-600 */
    --primary-hover: #4338ca; /* indigo-700 */
    --success: #10b981; /* emerald-500 */
    --warning: #f59e0b; /* amber-500 */
    --danger: #ef4444; /* red-500 */
  }

  .dark {
    --background: #020617; /* slate-950 */
    --surface: #0f172a; /* slate-900 */
    --card: #1e293b; /* slate-800 */
    --elevated: #334155; /* slate-700 */

    --text-primary: #f8fafc; /* slate-50 */
    --text-secondary: #cbd5e1; /* slate-300 */
    --text-muted: #94a3b8; /* slate-400 */
    --text-inverse: #020617; /* slate-950 */

    --border: #475569; /* slate-600 */
    --border-subtle: #334155; /* slate-700 */

    --primary: #6366f1; /* indigo-500 */
    --primary-hover: #818cf8; /* indigo-400 */
    --success: #10b981; /* emerald-500 */
    --warning: #f59e0b; /* amber-500 */
    --danger: #ef4444; /* red-500 */
  }

  body {
    font-family: var(--font-sans);
    background-color: var(--background);
    color: var(--text-primary);
  }

  /* Smooth transitions */
  *, *::before, *::after {
    transition: background-color 300ms cubic-bezier(0.4, 0, 0.2, 1), 
                color 300ms cubic-bezier(0.4, 0, 0.2, 1), 
                border-color 300ms cubic-bezier(0.4, 0, 0.2, 1), 
                box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  /* Modern input fields styling */
  input[type="text"],
  input[type="number"],
  input[type="email"],
  input[type="password"],
  input[type="tel"],
  input[type="url"],
  select,
  textarea {
    @apply bg-surface border border-border-subtle rounded-xl px-4 py-2.5 text-sm outline-none text-text-primary;
    box-shadow: inset 0 2px 4px 0 rgba(0, 0, 0, 0.02);
  }

  .dark input[type="text"],
  .dark input[type="number"],
  .dark input[type="email"],
  .dark input[type="password"],
  .dark input[type="tel"],
  .dark input[type="url"],
  .dark select,
  .dark textarea {
    background-color: var(--background);
    box-shadow: inset 0 2px 4px 0 rgba(0, 0, 0, 0.3);
  }

  input::placeholder,
  textarea::placeholder {
    color: var(--text-muted);
    opacity: 1;
  }

  input:focus, select:focus, textarea:focus {
    @apply bg-card border-primary-default ring-4 ring-primary-default/20 scale-[1.01] shadow-lg shadow-primary-default/10;
    transform: translateY(-1px) scale(1.01);
  }

  .dark input:focus, .dark select:focus, .dark textarea:focus {
    @apply bg-surface border-primary-default;
    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.25), 0 4px 12px rgba(0, 0, 0, 0.5);
  }

  input:disabled, select:disabled, textarea:disabled {
    @apply bg-surface text-text-muted border-border-subtle opacity-70 cursor-not-allowed;
  }

  /* Beautiful modern buttons global guidelines */
  button {
    font-family: var(--font-sans);
  }

  button:focus-visible, a:focus-visible, input:focus-visible, select:focus-visible, textarea:focus-visible {
    @apply outline-none ring-2 ring-primary-default ring-offset-2 ring-offset-background;
  }
}

/* Card and Surface styles for dark mode */
.dark .bg-card, .dark .bg-surface {
  border: 1px solid var(--border-subtle);
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.8), 0 8px 10px -6px rgba(0, 0, 0, 0.5), inset 0 1px 0 0 rgba(255, 255, 255, 0.05);
}

html:not(.dark) .bg-card, html:not(.dark) .bg-surface {
  border: 1px solid var(--border-subtle);
}

/* Custom Floating Animations */
@keyframes float {
  0% { transform: translateY(0px) scale(1) rotate(0deg); }
  50% { transform: translateY(-30px) scale(1.05) rotate(4deg); }
  100% { transform: translateY(0px) scale(1) rotate(0deg); }
}
@keyframes float-delayed {
  0% { transform: translateY(0px) scale(1) rotate(0deg); }
  50% { transform: translateY(25px) scale(1.08) rotate(-5deg); }
  100% { transform: translateY(0px) scale(1) rotate(0deg); }
}
.animate-float {
  animation: float 14s ease-in-out infinite;
}
.animate-float-delayed {
  animation: float-delayed 18s ease-in-out infinite;
}
`;

// Replace the entire file with our new cleanly scoped CSS
fs.writeFileSync('src/index.css', `@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap');\n@import "tailwindcss";\n${themeVariables}`);
