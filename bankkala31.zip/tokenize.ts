import ts from 'typescript';
import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const scanner = ts.createScanner(ts.ScriptTarget.Latest, true);
scanner.setText(content);

const pStack: any[] = [];
const cStack: any[] = [];

let token = scanner.scan();
while (token !== ts.SyntaxKind.EndOfFileToken) {
  const pos = scanner.getTokenPos();
  const text = scanner.getTokenText();
  
  // We can get the line and character from the content
  // Simple line counter
  const beforeText = content.substring(0, pos);
  const line = beforeText.split('\n').length;
  
  if (token === ts.SyntaxKind.OpenParen) {
    pStack.push({ line, pos, text: content.substring(pos, pos + 40).replace(/\n/g, ' ') });
  } else if (token === ts.SyntaxKind.CloseParen) {
    if (pStack.length > 0) pStack.pop();
  } else if (token === ts.SyntaxKind.OpenBrace) {
    cStack.push({ line, pos, text: content.substring(pos, pos + 40).replace(/\n/g, ' ') });
  } else if (token === ts.SyntaxKind.CloseBrace) {
    if (cStack.length > 0) cStack.pop();
  }
  
  token = scanner.scan();
}

console.log('=== UNCLOSED CURLY BRACES ===');
cStack.forEach((c, idx) => {
  console.log(`${idx + 1}. Line ${c.line} (char ${c.pos}): ${c.text}`);
});

console.log('\n=== UNCLOSED PARENTHESES ===');
pStack.forEach((p, idx) => {
  console.log(`${idx + 1}. Line ${p.line} (char ${p.pos}): ${p.text}`);
});
