import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

console.log('Substring from 34350 to 34550:');
console.log(line339.substring(34350, 34550));
