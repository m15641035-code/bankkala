const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target = "// Navigation states //'login' |'role_select' |'supplier_form' |'store_manager_form' |'dashboard'   const [view, setView] = useState<";
if (content.includes(target)) {
  content = content.replace(target, "\n// Navigation states \n//'login' |'role_select' |'supplier_form' |'store_manager_form' |'dashboard'\nconst [view, setView] = useState<");
  console.log('Successfully split Navigation states comment!');
} else {
  // Let's do a search with indexOf
  const idx = content.indexOf("// Navigation states");
  if (idx !== -1) {
    console.log('Found partial match starting with // Navigation states:');
    const sub = content.substring(idx, idx + 200);
    console.log(sub);
    const splitIndex = sub.indexOf("const");
    if (splitIndex !== -1) {
      const commentPart = sub.substring(0, splitIndex);
      const codePart = sub.substring(splitIndex);
      content = content.replace(sub, `\n${commentPart}\n${codePart}`);
      console.log('Split completed in App.tsx');
    }
  }
}

fs.writeFileSync('src/App.tsx', content);
