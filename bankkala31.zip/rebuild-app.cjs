const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// First, let's reverse any previous splits we did to start from a clean state
code = code.replace(/\n\/\/ /g, " // ");
code = code.replace(/\/\/ [^\n]*\n/g, (match) => match.trim() + " ");

// Let's reload the original file or clean it up.
// Let's write a character-by-character parser to format it.
let result = "";
let inSingleQuote = false;
let inDoubleQuote = false;
let inTemplateLiteral = false;
let inComment = false;

// List of comments we want to put on their own lines
const comments = [
  "// Navigation states //'login' |'role_select' |'supplier_form' |'store_manager_form' |'dashboard'",
  "// Navigation states",
  "// Auto-login if token exists",
  "// Check for payment callback redirect parameters",
  "// Clean up URL query parameters so they don't keep showing on refresh",
  "// Login form state",
  "// Supplier form state (5 steps)",
  "// Store Manager form state (4 steps)",
  "// Draft save functions",
  "// Clear all registration drafts",
  "// Personal Info",
  "// Business Info",
  "// Financial Info",
  "// Credentials Summary",
  "// Store Details",
  "// STEP 1:",
  "// STEP 2:",
  "// STEP 3:",
  "// STEP 4:",
  "// STEP 5:",
  "// Supplier Draft Restore Banner",
  "// Shaba validation function",
  "// Public Messages for Landing Page"
];

for (let i = 0; i < code.length; i++) {
  const char = code[i];
  const nextChar = code[i + 1];
  
  // Handle escape character in strings
  if (char === '\\' && (inSingleQuote || inDoubleQuote || inTemplateLiteral)) {
    result += char + nextChar;
    i++;
    continue;
  }
  
  // Handle string literals
  if (char === "'" && !inDoubleQuote && !inTemplateLiteral) {
    inSingleQuote = !inSingleQuote;
    result += char;
    continue;
  }
  if (char === '"' && !inSingleQuote && !inTemplateLiteral) {
    inDoubleQuote = !inDoubleQuote;
    result += char;
    continue;
  }
  if (char === '`' && !inSingleQuote && !inDoubleQuote) {
    inTemplateLiteral = !inTemplateLiteral;
    result += char;
    continue;
  }
  
  // If we are inside a string, don't split
  if (inSingleQuote || inDoubleQuote || inTemplateLiteral) {
    result += char;
    continue;
  }
  
  // Check if we are at the start of any comment from our list
  let matchedComment = null;
  for (const c of comments) {
    if (code.substring(i, i + c.length) === c) {
      matchedComment = c;
      break;
    }
  }
  
  if (matchedComment) {
    result += "\n" + matchedComment + "\n";
    i += matchedComment.length - 1;
    continue;
  }
  
  // Outside of strings, split on semicolons and braces followed by space
  if (char === ';' && nextChar === ' ') {
    result += ";\n";
    i++; // skip the space
    continue;
  }
  if (char === '}' && nextChar === ' ') {
    result += "}\n";
    i++; // skip the space
    continue;
  }
  if (char === '{' && nextChar === ' ') {
    result += "{\n";
    i++; // skip the space
    continue;
  }
  
  result += char;
}

// Write the formatted file back
fs.writeFileSync('src/App.tsx', result);
console.log('App.tsx rebuilt and formatted by parser.');
