import fs from 'fs';
import path from 'path';

function walk(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walk(dirPath, callback) : callback(path.join(dir, f));
  });
}

walk('src', (filepath) => {
  if (!filepath.endsWith('.tsx') && !filepath.endsWith('.ts')) return;
  let content = fs.readFileSync(filepath, 'utf8');
  let original = content;

  // Cleanup mistaken doubles
  content = content.replace(/bg-primary-default\/10\/20/g, 'bg-primary-default/5');
  content = content.replace(/border-primary-default\/20\/50/g, 'border-primary-default/20');
  
  // Cleanup leftover slates/indigos
  content = content.replace(/text-indigo-950/g, 'text-primary-hover');
  content = content.replace(/bg-slate-150/g, 'bg-surface');
  content = content.replace(/hover:bg-slate-200/g, 'hover:bg-background');
  content = content.replace(/hover:text-slate-600/g, 'hover:text-primary');
  content = content.replace(/hover:text-slate-700/g, 'hover:text-primary');
  content = content.replace(/hover:text-slate-800/g, 'hover:text-primary');
  content = content.replace(/text-slate-500/g, 'text-muted');

  if (content !== original) {
    fs.writeFileSync(filepath, content, 'utf8');
  }
});
console.log('Final cleanup complete.');
