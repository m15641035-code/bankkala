import ts from 'typescript';
import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const sourceFile = ts.createSourceFile(
  filePath,
  content,
  ts.ScriptTarget.Latest,
  true,
  ts.ScriptKind.TSX
);

const diagnostics = (sourceFile as any).parseDiagnostics || [];
console.log(`Found ${diagnostics.length} parse diagnostics:`);
for (const diag of diagnostics) {
  const { line, character } = ts.getLineAndCharacterOfPosition(sourceFile, diag.start);
  console.log(`Error: ${diag.messageText} at line ${line + 1}, col ${character + 1}`);
}
