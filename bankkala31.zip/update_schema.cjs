const fs = require('fs');
let schema = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Insert User relations
schema = schema.replace(
  '  storeProductSelections StoreProductSelection[]\n  storeConnection        StoreConnection?\n  wallet                 Wallet?\n}',
  `  storeProductSelections StoreProductSelection[]
  storeConnection        StoreConnection?
  wallet                 Wallet?
  payments               Payment[]
  supplierPayables       SupplierPayable[]
  settlements            Settlement[]
  auditTrails            AuditTrail[]
}`
);

// Append new models
const newModels = `
enum PaymentStatus {
  PENDING
  PAID
  FAILED
  REFUNDED
  CANCELLED
}

model Payment {
  id               String        @id @default(uuid())
  amount           Decimal
  currency         String        @default("IRR")
  status           PaymentStatus @default(PENDING)
  idempotencyKey   String        @unique
  gatewayReference String?
  userId           Int           
  createdAt        DateTime      @default(now())
  updatedAt        DateTime      @updatedAt

  user             User          @relation(fields: [userId], references: [id])
  supplierPayables SupplierPayable[]
  transactionLogs  TransactionLog[]
  invoice          Invoice?

  @@index([idempotencyKey])
  @@index([gatewayReference])
  @@index([status])
}

model SupplierPayable {
  id           String      @id @default(uuid())
  supplierId   Int
  paymentId    String
  settlementId String?
  amount       Decimal
  status       String      @default("PENDING") // PENDING, SETTLED
  dueDate      DateTime?
  createdAt    DateTime    @default(now())
  updatedAt    DateTime    @updatedAt

  supplier     User        @relation(fields: [supplierId], references: [id])
  payment      Payment     @relation(fields: [paymentId], references: [id])
  settlement   Settlement? @relation(fields: [settlementId], references: [id])

  @@index([supplierId])
  @@index([status])
}

model Settlement {
  id             String      @id @default(uuid())
  supplierId     Int
  totalAmount    Decimal
  status         String      @default("PENDING") // PENDING, PROCESSING, SUCCESS, FAILED
  settlementDate DateTime?
  bankReference  String?
  createdAt      DateTime    @default(now())
  updatedAt      DateTime    @updatedAt

  supplier       User        @relation(fields: [supplierId], references: [id])
  payables       SupplierPayable[]

  @@index([supplierId])
  @@index([status])
}

model TransactionLog {
  id           String      @id @default(uuid())
  paymentId    String
  action       String      
  payload      String?     @db.Text
  responseCode String?
  ipAddress    String?
  createdAt    DateTime    @default(now())

  payment      Payment     @relation(fields: [paymentId], references: [id])
  
  @@index([paymentId])
}

model Invoice {
  id            String      @id @default(uuid())
  invoiceNumber String      @unique
  paymentId     String      @unique
  pdfUrl        String?
  issuedAt      DateTime    @default(now())

  payment       Payment     @relation(fields: [paymentId], references: [id])
}

model AuditTrail {
  id         String   @id @default(uuid())
  actorId    Int?
  action     String
  resource   String
  metadata   String?  @db.Text
  createdAt  DateTime @default(now())

  actor      User?    @relation(fields: [actorId], references: [id])
}
`;

schema = schema + "\n" + newModels;
fs.writeFileSync('prisma/schema.prisma', schema);
