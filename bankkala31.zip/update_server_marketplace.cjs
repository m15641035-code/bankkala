const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStr = `    const products = await prisma.product.findMany({
      where,
      include: {
        category: true,
        images: true,
        variants: true
      },`;
      
const replaceStr = `    const products = await prisma.product.findMany({
      where,
      include: {
        category: true,
        images: true,
        variants: true,
        supplier: {
          select: { brandName: true, firstName: true, lastName: true }
        }
      },`;

code = code.replace(targetStr, replaceStr);

const targetMap = `const sanitizedProducts = products.map((product: any) => {`;
const replaceMap = `const sanitizedProducts = products.map((product: any) => {
      const supplierName = product.supplier?.brandName || (product.supplier?.firstName ? \`\${product.supplier.firstName} \${product.supplier.lastName}\` : 'نامشخص');`;

code = code.replace(targetMap, replaceMap);

const targetDrop = `const { supplierId, supplierBasePrice, marginType, marginValue, ...safeProduct } = product;
            
      return { ...safeProduct, finalPrice: fPrice };`;
const replaceDrop = `const { supplierId, supplierBasePrice, marginType, marginValue, supplier, ...safeProduct } = product;
            
      return { ...safeProduct, supplierName, finalPrice: fPrice };`;

code = code.replace(targetDrop, replaceDrop);

fs.writeFileSync('server.ts', code);
