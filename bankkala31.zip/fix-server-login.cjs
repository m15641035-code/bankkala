const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

// Fix logout endpoint being inside the if block
server = server.replace(
  /app\.post\('\/api\/auth\/logout', \(req: any, res: any\) => \{\s*res\.clearCookie\('token'\);\s*res\.json\(\{ success: true \}\);\s*\}\);/g,
  ''
);

server = server.replace(
  /return res\.json\(\{\s*message: 'ورود با موفقیت انجام شد\.',\s*token,\s*user: userWithoutPassword\s*\}\);/g,
  `res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 24 * 60 * 60 * 1000 });
    return res.json({
      message: 'ورود با موفقیت انجام شد.',
      token,
      user: userWithoutPassword
    });`
);

server = server.replace(
  /app\.post\('\/api\/auth\/login', async \(req, res\) => \{/,
  `app.post('/api/auth/logout', (req: any, res: any) => {
  res.clearCookie('token');
  res.json({ success: true });
});\n\napp.post('/api/auth/login', async (req, res) => {`
);

fs.writeFileSync('server.ts', server);
