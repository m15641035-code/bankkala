const fs = require('fs');
let server = fs.readFileSync('server.ts', 'utf8');
server = 'import "dotenv/config";\n' + server;
fs.writeFileSync('server.ts', server);

// Also remove from EncryptionService.ts top-level check, let it lazily evaluate or something? 
// No, import "dotenv/config" should fix it.
