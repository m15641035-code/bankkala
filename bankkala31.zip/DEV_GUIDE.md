# Development Guide

## Prerequisites
- Node.js (v20+ recommended).
- npm.

## Local Development
1. Install dependencies: `npm install`.
2. Start the dev server: `npm run dev`.
3. Open `http://localhost:3000`.

## Testing Changes
1. Run the development server and verify the UI/API interaction.
2. Run `npm run build` to ensure the production build succeeds.
3. Run `npm run lint` to check for syntax errors.
