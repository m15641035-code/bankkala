# Project Rules

## Core Principles
1. **Respect Intent**: Always prioritize the user's explicit request.
2. **Persistence**: Maintain all documentation files updated after any significant change.
3. **Safety**: Never delete any code, file, or asset without explicit user confirmation.
4. **Clean Code**: Keep the code modular and well-documented.

## Roles
- SuperAdmin, Supplier, StoreManager.

## Constraints
- Do not add unsolicited features.
- Build exactly what is requested.
- Always review documentation before making changes.
