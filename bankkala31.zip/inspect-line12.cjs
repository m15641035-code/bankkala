const fs = require('fs');
const content = fs.readFileSync('src/components/ContrastDiagnostic.tsx', 'utf8');
const lines = content.split('\n');
console.log('Line 12 length:', lines[11].length);
console.log('Line 12 start:', lines[11].substring(0, 300));
console.log('Line 12 end:', lines[11].substring(lines[11].length - 300));
