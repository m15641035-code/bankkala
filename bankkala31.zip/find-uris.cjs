const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');

const fetchRegex = /fetch\s*\(\s*['"`]([^'"`]+)['"`]/g;
let match;
while ((match = fetchRegex.exec(content)) !== null) {
  console.log('fetch URI:', match[1]);
}

const axiosRegex = /axios\.[a-z]+\s*\(\s*['"`]([^'"`]+)['"`]/g;
while ((match = axiosRegex.exec(content)) !== null) {
  console.log('axios URI:', match[1]);
}
