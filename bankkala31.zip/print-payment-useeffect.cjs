const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

for (let i = 230; i < 260; i++) {
  if (lines[i] !== undefined) {
    console.log(`Line ${i + 1}: ${lines[i]}`);
  }
}
