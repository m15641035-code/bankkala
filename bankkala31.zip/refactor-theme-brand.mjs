import fs from 'fs';
import path from 'path';

function walk(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walk(dirPath, callback) : callback(path.join(dir, f));
  });
}

const colorMap = {
  // Primary
  'bg-indigo-600': 'bg-primary-default',
  'bg-indigo-700': 'bg-primary-hover',
  'text-indigo-600': 'text-primary-default',
  'border-indigo-600': 'border-primary-default',
  'border-indigo-500': 'border-primary-default',
  'text-indigo-500': 'text-primary-default',
  
  // Success
  'bg-emerald-500': 'bg-success',
  'bg-emerald-600': 'bg-success',
  'text-emerald-500': 'text-success',
  'text-emerald-600': 'text-success',
  'border-emerald-500': 'border-success',
  
  // Danger
  'bg-rose-500': 'bg-danger',
  'bg-rose-600': 'bg-danger',
  'text-rose-500': 'text-danger',
  'text-rose-600': 'text-danger',
  'border-rose-500': 'border-danger',
  
  // Warning
  'bg-amber-500': 'bg-warning',
  'bg-amber-600': 'bg-warning',
  'text-amber-500': 'text-warning',
  'text-amber-600': 'text-warning',
  'border-amber-500': 'border-warning',

  // Cleanup old unreplaced text-white
  'text-white': 'text-inverse',
};

const regexes = Object.entries(colorMap).map(([oldClass, newClass]) => [
  new RegExp(`(?<![a-zA-Z0-9:-])` + oldClass + `(?![a-zA-Z0-9-])`, 'g'),
  newClass
]);

walk('src', (filepath) => {
  if (!filepath.endsWith('.tsx') && !filepath.endsWith('.ts')) return;
  let content = fs.readFileSync(filepath, 'utf8');
  let original = content;

  // Replace light mode hardcoded colors
  for (const [regex, newClass] of regexes) {
    content = content.replace(regex, newClass);
  }
  
  // Also clean up hover: variants
  content = content.replace(/hover:bg-indigo-[67]00/g, 'hover:bg-primary-hover');
  content = content.replace(/hover:text-indigo-[67]00/g, 'hover:text-primary-hover');
  
  if (content !== original) {
    fs.writeFileSync(filepath, content, 'utf8');
  }
});
console.log('Brand refactoring complete.');
