const fs = require('fs');

function unflatten(code) {
  // Replace "// some comment text {code}" where {code} is actual code on the same line
  // The simplest heuristic for these minified files: 
  // If we see `// (some words) app.` -> `\n// $1\napp.`
  // Actually, we can just replace ALL `// ` with `\n// `
  // But what if it's already properly formatted?
  
  let newCode = code.replace(/\/\/ ([a-zA-Z0-9 _\-\=\(\)]+) app\./g, '\n// $1\napp.');
  newCode = newCode.replace(/\/\/ ([a-zA-Z0-9 _\-\=\(\)]+) const /g, '\n// $1\nconst ');
  newCode = newCode.replace(/\/\/ ([a-zA-Z0-9 _\-\=\(\)]+) return /g, '\n// $1\nreturn ');
  newCode = newCode.replace(/\/\/ ========================================== ([a-zA-Z0-9 _\-\=\(\)]+) ========================================== app\./g, '\n// ==========================================\n// $1\n// ==========================================\napp.');
  newCode = newCode.replace(/\/\/ ========================================== app\./g, '\n// ==========================================\napp.');
  return newCode;
}

['src/services/announcementsRoute.ts', 'src/services/newFeaturesRoute.ts', 'src/services/configRoute.ts', 'src/services/orderLabelRoute.ts'].forEach(filename => {
  // Let's just download them fresh from the zip, unflatten, then format
});
