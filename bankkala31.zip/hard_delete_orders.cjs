const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStr = `    await prisma.$transaction(async (tx) => {
      // Cancel requested orders
      for (const item of existingOrderItems) {
        if (item.status === 'REQUESTED' || item.status === 'PENDING') {
          await tx.orderItem.update({
            where: { id: item.id },
            data: { status: 'CANCELLED' }
          });
          // Also cancel the parent order if this is the only/main item (simplified logic)
          await tx.order.update({
            where: { id: item.orderId },
            data: { status: 'CANCELLED' }
          });
        }
      }

      await tx.storeProductSelection.deleteMany({
        where: { storeId, productId }
      });
    });`;

const newStr = `    await prisma.$transaction(async (tx) => {
      // Hard delete requested orders
      for (const item of existingOrderItems) {
        if (item.status === 'REQUESTED' || item.status === 'PENDING') {
          await tx.orderItem.delete({
            where: { id: item.id }
          });
          // Delete parent order if it has no other items
          const otherItems = await tx.orderItem.count({ where: { orderId: item.orderId } });
          if (otherItems === 0) {
            await tx.order.delete({
              where: { id: item.orderId }
            });
          }
        }
      }

      await tx.storeProductSelection.deleteMany({
        where: { storeId, productId }
      });
    });`;
code = code.replace(targetStr, newStr);
fs.writeFileSync('server.ts', code);
