const fs = require('fs');

const file = 'src/services/NotificationService.ts';
let code = fs.readFileSync(file, 'utf8');

// Find all occurrences of '// '
const regex = /\/\/.*?(\b(?:appEvents|console\.log|const|let|var|if|return|export|class|function|public|private|this\.|app\.|router\.|res\.|req\.|try|catch|import)\b)/g;

code = code.replace(regex, (match, p1) => {
    // The comment is everything from '//' up to (but not including) p1.
    // So we replace the match with the comment + '\n' + p1.
    // Wait, regex is greedy or non-greedy? .*? is non-greedy.
    return match.substring(0, match.length - p1.length) + '\n' + p1;
});

console.log(code);
