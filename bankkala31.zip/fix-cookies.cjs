const fs = require('fs');

// 1. Update server.ts
let server = fs.readFileSync('server.ts', 'utf8');
if (!server.includes('cookie-parser')) {
  server = server.replace(
    /import express from "express";/,
    'import express from "express";\nimport cookieParser from "cookie-parser";'
  );
  server = server.replace(
    /app\.use\(express\.json\(\)\);/,
    'app.use(express.json());\n  app.use(cookieParser());'
  );
  
  // Also CORS for credentials
  server = server.replace(
    /app\.use\(cors\(\)\);/,
    `app.use(cors({ origin: true, credentials: true }));`
  );

  // Login endpoint
  server = server.replace(
    /res\.json\(\{ token, user: \{[\s\S]*?\} \}\);/g,
    `res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 24 * 60 * 60 * 1000 });
      res.json({ token, user: { id: user.id, username: user.username, role: user.role, firstName: user.firstName, lastName: user.lastName, status: user.status } });`
  );

  // Logout endpoint
  if (!server.includes('/api/auth/logout')) {
    server = server.replace(
      /app\.post\('\/api\/auth\/login',[\s\S]*?\}\);/g,
      `$&
      
app.post('/api/auth/logout', (req: any, res: any) => {
  res.clearCookie('token');
  res.json({ success: true });
});`
    );
  }
  
  fs.writeFileSync('server.ts', server);
}

// 2. Update authMiddleware.ts
let auth = fs.readFileSync('src/services/authMiddleware.ts', 'utf8');
auth = auth.replace(
  /const authHeader = req\.headers\['authorization'\];[\s\S]*?const token = authHeader && authHeader\.split\(' '\)\[1\];[\s\S]*?if \(token == null\) return res\.status\(401\)\.json\(\{ error: 'عدم دسترسی' \}\);/g,
  `const authHeader = req.headers['authorization'];
    const headerToken = authHeader && authHeader.split(' ')[1];
    const token = req.cookies?.token || headerToken;
    if (!token) return res.status(401).json({ error: 'عدم دسترسی' });`
);
fs.writeFileSync('src/services/authMiddleware.ts', auth);

