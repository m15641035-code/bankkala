const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const users = await prisma.user.findMany({
    select: { id: true, username: true, role: true }
  });
  console.log('--- USERS ---');
  console.log(JSON.stringify(users, null, 2));

  const orders = await prisma.order.findMany({
    include: { items: true, invoice: true }
  });
  console.log('--- ORDERS ---');
  console.log(JSON.stringify(orders, null, 2));

  const invoices = await prisma.storeInvoice.findMany();
  console.log('--- INVOICES ---');
  console.log(JSON.stringify(invoices, null, 2));
}

main()
  .catch(e => console.error(e))
  .finally(() => prisma.$disconnect());
