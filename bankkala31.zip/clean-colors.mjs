import fs from 'fs';
import path from 'path';

function walk(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walk(dirPath, callback) : callback(path.join(dir, f));
  });
}

const colorMap = {
  // Backgrounds
  'bg-slate-50': 'bg-background',
  'bg-slate-100': 'bg-surface',
  'bg-slate-200': 'bg-surface',
  'bg-slate-300': 'bg-surface',
  'bg-slate-700': 'bg-surface',
  'bg-slate-800': 'bg-surface',
  'bg-slate-850': 'bg-surface',
  'bg-slate-900': 'bg-background',
  'bg-slate-950': 'bg-background',
  'bg-gray-50': 'bg-background',
  'bg-gray-100': 'bg-surface',
  'bg-gray-800': 'bg-surface',
  'bg-gray-900': 'bg-background',
  'bg-indigo-50': 'bg-primary-default/10',
  'bg-indigo-100': 'bg-primary-default/20',
  'bg-indigo-900': 'bg-primary-default/20',
  'bg-indigo-950': 'bg-primary-default/10',
  'bg-emerald-50': 'bg-success/10',
  'bg-emerald-100': 'bg-success/20',
  'bg-emerald-900': 'bg-success/20',
  'bg-rose-50': 'bg-danger/10',
  'bg-rose-100': 'bg-danger/20',
  'bg-rose-900': 'bg-danger/20',
  'bg-rose-950': 'bg-danger/10',
  'bg-amber-50': 'bg-warning/10',
  'bg-amber-100': 'bg-warning/20',
  
  // Text
  'text-slate-900': 'text-primary',
  'text-slate-800': 'text-primary',
  'text-slate-700': 'text-secondary',
  'text-slate-600': 'text-muted',
  'text-slate-500': 'text-muted',
  'text-slate-400': 'text-muted',
  'text-slate-300': 'text-inverse',
  'text-slate-200': 'text-inverse',
  'text-slate-100': 'text-inverse',
  'text-slate-50': 'text-inverse',
  
  'text-indigo-700': 'text-primary-hover',
  'text-indigo-600': 'text-primary-default',
  'text-indigo-500': 'text-primary-default',
  'text-indigo-400': 'text-primary-default',
  'text-indigo-300': 'text-primary-default',
  
  // Borders
  'border-slate-100': 'border-subtle',
  'border-slate-200': 'border-subtle',
  'border-slate-300': 'border-default',
  'border-slate-400': 'border-default',
  'border-slate-500': 'border-default',
  'border-slate-600': 'border-default',
  'border-slate-700': 'border-subtle',
  'border-slate-800': 'border-subtle',
  'border-slate-900': 'border-subtle',
  
  'border-indigo-100': 'border-primary-default/20',
  'border-indigo-200': 'border-primary-default/30',
  'border-indigo-300': 'border-primary-default/40',
  'border-indigo-400': 'border-primary-default',
  'border-indigo-500': 'border-primary-default',
  'border-indigo-600': 'border-primary-default',
  
  // Rings
  'ring-indigo-100': 'ring-primary-default/20',
  'ring-indigo-500': 'ring-primary-default',
  'ring-rose-100': 'ring-danger/20',
  
  // Shadows
  'shadow-indigo-500': 'shadow-primary-default',
  'shadow-indigo-600': 'shadow-primary-default',
};

walk('src', (filepath) => {
  if (!filepath.endsWith('.tsx') && !filepath.endsWith('.ts')) return;
  let content = fs.readFileSync(filepath, 'utf8');
  let original = content;

  // Cleanup explicit dark: variants that weren't caught
  content = content.replace(/dark:(?:hover:)?(bg|text|border|ring|shadow)-(?:slate|gray|indigo|rose|emerald|amber|red|green|yellow|white|black)[-\w]*(?:\/[0-9]+)?/g, '');

  for (const [oldClass, newClass] of Object.entries(colorMap)) {
    // Also handle hover:, focus: etc prefixes automatically
    const regex = new RegExp(`(?<![a-zA-Z0-9-])(hover:|focus:|active:|group-hover:)?${oldClass}(?![a-zA-Z0-9-])`, 'g');
    content = content.replace(regex, (match, p1) => {
      if (p1) return p1 + newClass;
      return newClass;
    });
  }
  
  // Handle /opacity on base classes we missed
  content = content.replace(/(bg|text|border)-(slate|gray)-[0-9]{2,3}\/[0-9]{2,3}/g, '$1-subtle');
  content = content.replace(/(bg|text|border)-(indigo)-[0-9]{2,3}\/[0-9]{2,3}/g, '$1-primary-default/20');
  
  // clean up extra spaces
  content = content.replace(/\s{2,}/g, ' ');
  content = content.replace(/className=(["'`])\s+/g, 'className=$1');
  content = content.replace(/\s+(["'`])/g, '$1');

  if (content !== original) {
    fs.writeFileSync(filepath, content, 'utf8');
  }
});
console.log('Final color cleanup complete.');
