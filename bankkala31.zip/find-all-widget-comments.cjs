const fs = require('fs');
const content = fs.readFileSync('src/components/UserDashboardWidgets.tsx', 'utf8');

// Simple regex to find // comments not in strings
const lines = content.split('\n');
lines.forEach((line, idx) => {
  let inQuote = false;
  let quoteChar = '';
  for (let i = 0; i < line.length - 1; i++) {
    const char = line[i];
    if ((char === '"' || char === "'" || char === '`') && (i === 0 || line[i - 1] !== '\\')) {
      if (!inQuote) {
        inQuote = true;
        quoteChar = char;
      } else if (char === quoteChar) {
        inQuote = false;
      }
    }
    if (!inQuote && char === '/' && line[i + 1] === '/') {
      console.log(`Line ${idx + 1} has comment: ${line.substring(i, i + 100)}`);
      break;
    }
  }
});
