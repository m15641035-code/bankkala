import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
let content = fs.readFileSync(filePath, 'utf8');

if (content.includes(') )}$')) {
  console.log('Found corrupted ) )}$! Replacing it with ) )');
  content = content.replace(') )}$', ') )');
  fs.writeFileSync(filePath, content, 'utf8');
  console.log('Saved corrected file.');
} else {
  console.log('Corrupted sequence not found.');
}
