const fs = require('fs');

// 1. Fix contrast in Overview.tsx
let overview = fs.readFileSync('src/components/superadmin/Overview.tsx', 'utf8');
overview = overview.replace(
  /text-inverse/g,
  'text-white'
);
fs.writeFileSync('src/components/superadmin/Overview.tsx', overview);

// 2. Remove quick login from App.tsx
let appStr = fs.readFileSync('src/App.tsx', 'utf8');

// The Quick Login block starts around "Beautifully Redesigned Quick Login Section"
const quickLoginRegex = /\{\/\* Beautifully Redesigned Quick Login Section \*\/\}.*?\{\/\* Quick Register link \*\/\}/s;
appStr = appStr.replace(quickLoginRegex, '{/* Quick Register link */}');

fs.writeFileSync('src/App.tsx', appStr);
