const fs = require('fs');
const content = fs.readFileSync('src/components/ContrastDiagnostic.tsx', 'utf8');
const lines = content.split('\n');
console.log('ContrastDiagnostic total lines:', lines.length);
for (let i = 0; i < lines.length; i++) {
  console.log(`Line ${i + 1}: ${lines[i].substring(0, 150)}`);
}
