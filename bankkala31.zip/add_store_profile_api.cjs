const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetProfileAPI = `app.put('/api/supplier/profile'`;

const newProfileAPI = `app.put('/api/store-manager/profile', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const userId = req.user.userId || req.user.id;
    const { firstName, lastName, shaba, mobile } = req.body;
    
    await prisma.user.update({
      where: { id: userId },
      data: { firstName, lastName, shaba, mobile }
    });
    
    res.json({ message: 'پروفایل با موفقیت بروزرسانی شد' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/supplier/profile'`;

if (code.includes(targetProfileAPI)) {
  code = code.replace(targetProfileAPI, newProfileAPI);
  fs.writeFileSync('server.ts', code);
  console.log("Added profile API");
}
