import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr = 'ORDERS TAB';
const idx = line339.indexOf(searchStr);
const endIdx = line339.indexOf('WALLET TAB');

if (idx !== -1 && endIdx !== -1) {
  const segment = line339.substring(idx, endIdx);
  console.log('End of ORDERS TAB segment (last 150 chars):');
  console.log(segment.substring(segment.length - 150));
}
