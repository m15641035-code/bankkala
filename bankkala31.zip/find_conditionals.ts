import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

// Find occurrences of modal or conditional blocks
const terms = ['isSettlementModalOpen', 'selectedSettlement', 'changingOrder', 'isWithdrawalModalOpen'];
for (const term of terms) {
  let idx = -1;
  while ((idx = line339.indexOf(term, idx + 1)) !== -1) {
    console.log(`Found ${term} at index ${idx}:`);
    console.log(line339.substring(idx - 50, idx + 150));
  }
}
