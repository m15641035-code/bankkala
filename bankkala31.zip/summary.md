1. **prisma/schema.prisma**: Added `quantity` and `notes` to the `OrderItem` model to handle manual order specifications without breaking existing relationships.
2. **src/components/store-manager/StoreOrders.tsx**: Created a new component for Store Managers to list their manual orders and create new ones. The creation form fetches products strictly from their existing "Product Bank".
3. **src/components/store-manager/StoreManagerDashboard.tsx**: Integrated the new `StoreOrders` component into the side navigation and view renderer.
4. **src/components/supplier/SupplierDashboard.tsx**: Enhanced the orders tab to render the new `REQUESTED`, `SUPPLIER_APPROVED`, `REJECTED`, `PAID`, `PREPARING`, `COMPLETED` statuses. Added explicit "Approve" and "Reject" buttons for Requested orders.
5. **server.ts**: 
   - `POST /api/store-manager/orders`: Creates the manual order, calculates prices, and triggers a Notification to the Supplier.
   - `POST /api/supplier/orders/:itemId/approve` & `/reject`: Updates the order statuses and triggers a Notification back to the Store Manager.
   - `POST /api/store-manager/orders/:orderId/pay`: Simulates the Zibal payment gateway execution. Splits the payment, generates a `Payment` record, creates an `AuditTrail`, adds an `ORDER_REVENUE` `LedgerEntry` to the Supplier's `Wallet`, and generates a `SupplierPayable` record representing the accounting split.
   - `PATCH /api/supplier/orders/:itemId`: Ensured the main `Order` status is kept in sync with the `OrderItem` status when updated (e.g., from `PAID` to `PREPARING` to `COMPLETED`).
