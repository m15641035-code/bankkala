const fs = require('fs');

let code = fs.readFileSync('src/components/store-manager/StoreOrders.tsx', 'utf8');

const targetModalStr = `            <form onSubmit={handleCreateOrder} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">انتخاب محصول از بانک کالا</label>
                <select 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={selectedProduct}
                  onChange={(e) => setSelectedProduct(e.target.value)}
                  required
                >
                  <option value="">-- انتخاب محصول --</option>
                  {myCatalog.map(sel => (
                    <option key={sel.productId} value={sel.productId}>
                      {sel.product.name} (حداقل: {sel.product.minOrderQuantity})
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">تعداد (تعداد مجاز)</label>
                <input 
                  type="number"
                  min="1"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">یادداشت (اختیاری)</label>
                <textarea 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="توضیحات تکمیلی برای تامین‌کننده..."
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
                >
                  انصراف
                </button>
                <button 
                  type="submit"
                  disabled={submitting}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors disabled:opacity-50"
                >
                  {submitting ? 'در حال ثبت...' : 'ثبت سفارش'}
                </button>
              </div>
            </form>`;

const newModalStr = `            <form onSubmit={handleCreateOrder} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">انتخاب محصول از بانک کالا</label>
                <div className="max-h-60 overflow-y-auto space-y-2 border border-slate-100 p-2 rounded-xl bg-slate-50">
                  {myCatalog.length === 0 && (
                    <div className="text-center py-4 text-sm text-slate-500">بانک کالای شما خالی است</div>
                  )}
                  {myCatalog.map(sel => (
                    <div 
                      key={sel.productId} 
                      onClick={() => setSelectedProduct(sel.productId.toString())}
                      className={\`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors border \${selectedProduct === sel.productId.toString() ? 'border-indigo-600 bg-indigo-50' : 'border-transparent hover:bg-slate-100 bg-white'}\`}
                    >
                      <div className="w-12 h-12 bg-slate-200 rounded-lg overflow-hidden flex-shrink-0">
                        {sel.product.images?.length > 0 ? (
                          <img src={sel.product.images[0].url} className="w-full h-full object-cover" alt="" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-400">
                            <ShoppingCart className="w-5 h-5" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-slate-800 truncate">{sel.product.name}</h4>
                        <div className="flex gap-3 mt-1 text-xs text-slate-500">
                          <span>SKU: {sel.product.sku || '-'}</span>
                          <span>موجودی: {sel.product.inventory}</span>
                        </div>
                      </div>
                      {selectedProduct === sel.productId.toString() && (
                        <Check className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">تعداد سفارش</label>
                <input 
                  type="number"
                  min="1"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">یادداشت (اختیاری)</label>
                <textarea 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="توضیحات تکمیلی برای تامین‌کننده..."
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
                >
                  انصراف
                </button>
                <button 
                  type="submit"
                  disabled={submitting || !selectedProduct}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors disabled:opacity-50"
                >
                  {submitting ? 'در حال ثبت...' : 'ثبت سفارش'}
                </button>
              </div>
            </form>`;

code = code.replace(targetModalStr, newModalStr);
fs.writeFileSync('src/components/store-manager/StoreOrders.tsx', code);
