/** * Smart parser for the shipping address field. * Parses both the structured pipe format (|) and plain text formats. */
export function parseShippingAddress(addressStr: string) {
  const result = {
    province: "",
    city: "",
    detail: addressStr || "",
    postalCode: "",
    recipientName: "",
    recipientPhone: "",
  };
  if (!addressStr) return result;
  if (addressStr.includes("|")) {
    const parts = addressStr.split("|");
    parts.forEach((part) => {
      const indexOfSeparator = part.indexOf(":");
      if (indexOfSeparator !== -1) {
        const key = part.substring(0, indexOfSeparator).trim();
        const value = part.substring(indexOfSeparator + 1).trim();
        if (key.includes("استان")) result.province = value;
        else if (key.includes("شهر")) result.city = value;
        else if (key.includes("نشانی")) result.detail = value;
        else if (key.includes("کد پستی") || key.includes("پستی"))
          result.postalCode = value;
        else if (key.includes("گیرنده")) result.recipientName = value;
        else if (key.includes("تلفن") || key.includes("موبایل"))
          result.recipientPhone = value;
      }
    });
  }
  return result;
} /** * Opens a print-friendly window with a beautiful, official A4 invoice (فاکتور رسمی خرید) * for the Store Manager. Keeps identities protected by using usernames instead of full personal details. */
export function printOrderInvoice(order: any) {
  const parsed = parseShippingAddress(order.shippingAddress || "");
  // Masked or safe user profiles
  const buyerStoreName = order.store?.storeName || order.store?.username || 'فروشگاه عضو همکار کالا';
  const buyerUsername = order.store?.username ? `@${order.store.username}` : 'نامشخص';
  const sellerBrandName = order.items?.[0]?.product?.supplier?.brandName || order.items?.[0]?.product?.supplier?.username || 'تامین‌کننده همکار کالا';
  const sellerUsername = order.items?.[0]?.product?.supplier?.username ? `@${order.items?.[0]?.product?.supplier?.username}` : 'نامشخص';
  
  // Format creation date
  const orderDate = new Date(order.createdAt || Date.now()).toLocaleDateString('fa-IR');
  
  // Order items rendering
  let totalBaseAmount = 0;
  const itemsHtml = (order.items || []).map((item: any, index: number) => {
    const unitPrice = item.price || item.product?.finalPrice || item.product?.supplierBasePrice || 0;
    const itemTotal = unitPrice * item.quantity;
    totalBaseAmount += itemTotal;
    return `
      <tr class="item-row">
        <td class="text-center">${index + 1}</td>
        <td>
          <div class="product-name">${item.product?.name || 'کالای سفارشی'}</div>
          <div class="product-sku">شناسه محصول (SKU): ${item.product?.sku || '-'}</div>
        </td>
        <td class="text-center">${item.quantity}</td>
        <td class="text-left font-mono">${unitPrice.toLocaleString()} ریال</td>
        <td class="text-left font-mono">${itemTotal.toLocaleString()} ریال</td>
      </tr>
    `;
  }).join('');

  let taxRate = 9;
  try {
    const saved = localStorage.getItem("system_config");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && typeof parsed.TAX_RATE === "number") {
        taxRate = parsed.TAX_RATE;
      }
    }
  } catch (e) {
    console.error("Error reading cached TAX_RATE for invoice print", e);
  }

  const totalTax = Math.round(totalBaseAmount * (taxRate / 100)); // Dynamic VAT
  const totalPayable = totalBaseAmount + totalTax;
  const printWindow = window.open('','_blank');
  if (!printWindow) {
    alert('لطفاً اجازه باز شدن پاپ‌آپ (Pop-up blocker) را بدهید تا فاکتور باز شود.');
    return;
  }
 const invoiceHtml =` <!DOCTYPE html> <html lang="fa" dir="rtl"> <head> <meta charset="UTF-8"> <title>فاکتور رسمی سفارش #${order.id}</title> <style> @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700;800;900&display=swap'); * { box-sizing: border-box; margin: 0; padding: 0; font-family:'Vazirmatn', Tahoma, sans-serif; } body { background: #f8fafc; padding: 30px; display: flex; flex-direction: column; align-items: center; color: #1e293b; } .no-print-bar { width: 210mm; margin-bottom: 20px; background: white; padding: 14px 24px; border-radius: 16px; box-shadow: 0 4px 12px -2px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; border: 1px solid #e2e8f0; } .btn { padding: 10px 20px; font-weight: bold; border-radius: 10px; cursor: pointer; font-size: 13px; transition: all 0.2s; border: none; } .btn-primary { background: #4f46e5; color: white; } .btn-primary:hover { background: #4338ca; } .btn-secondary { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; } .btn-secondary:hover { background: #e2e8f0; } /* Standard A4 Sheet */ .invoice-sheet { width: 210mm; min-height: 297mm; background: white; padding: 20mm; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08); border: 1px solid #e2e8f0; display: flex; flex-direction: column; justify-content: space-between; } .header-section { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #1e293b; padding-bottom: 15px; margin-bottom: 25px; } .header-logo-title { display: flex; flex-direction: column; gap: 4px; } .main-title { font-size: 24px; font-weight: 900; color: #1e293b; letter-spacing: -0.5px; } .sub-title { font-size: 11px; color: #64748b; font-weight: 700; } .meta-info-box { text-align: left; font-size: 11.5px; line-height: 1.8; } .meta-info-box span { font-weight: bold; color: #0f172a; } /* Parties Section */ .parties-container { display: grid; grid-cols: 1; gap: 15px; margin-bottom: 25px; } .party-box { border: 1px solid #cbd5e1; border-radius: 12px; padding: 14px; font-size: 12px; line-height: 1.6; background: #f8fafc; } .party-title { font-weight: 900; color: #4f46e5; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 8px; font-size: 13px; } .party-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; } /* Items Table */ .items-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 12px; } .items-table th { background: #0f172a; color: white; border: 1px solid #1e293b; padding: 10px; font-weight: bold; font-size: 11.5px; } .items-table td { border: 1px solid #e2e8f0; padding: 12px 10px; vertical-align: middle; } .item-row:nth-child(even) { background: #f8fafc; } .product-name { font-weight: 800; color: #0f172a; font-size: 12.5px; } .product-sku { font-size: 10px; color: #64748b; font-family:'Courier New', monospace; margin-top: 4px; } .text-center { text-align: center; } .text-left { text-align: left; } .text-right { text-align: right; } /* Calculation Summary Box */ .calc-summary-wrapper { display: flex; justify-content: flex-end; margin-bottom: 40px; } .calc-table { width: 45%; border-collapse: collapse; font-size: 12px; } .calc-table td { padding: 8px 10px; border: 1px solid #e2e8f0; } .calc-table tr.total-row { background: #f1f5f9; font-weight: 900; font-size: 13.5px; color: #4f46e5; border: 2px solid #4f46e5; } /* Signatures Section */ .signatures-section { display: grid; grid-template-columns: 1fr 1fr; gap: 50px; margin-top: auto; padding-top: 40px; border-top: 1px dashed #cbd5e1; } .signature-box { height: 100px; border: 1px dashed #cbd5e1; border-radius: 12px; display: flex; flex-direction: column; justify-content: space-between; padding: 12px; font-size: 11px; color: #64748b; text-align: center; } .signature-title { font-weight: bold; color: #334155; font-size: 12px; } .footer-note { font-size: 9.5px; color: #64748b; text-align: center; margin-top: 30px; line-height: 1.6; border-top: 1px solid #f1f5f9; padding-top: 10px; } @media print { body { background: white; padding: 0; } .no-print-bar { display: none !important; } .invoice-sheet { box-shadow: none; border: none; padding: 0; width: 100%; } } </style> </head> <body> <div class="no-print-bar"> <div style="font-weight: bold; font-size: 14px; color: #4f46e5;">📄 پیش‌نمایش فاکتور رسمی خریدار</div> <div style="display: flex; gap: 8px;"> <button class="btn btn-primary" onclick="window.print()">چاپ / خروجی PDF فاکتور</button> <button class="btn btn-secondary" onclick="window.close()">بستن پنجره</button> </div> </div> <div class="invoice-sheet"> <!-- Brand Header --> <div class="header-section"> <div class="header-logo-title"> <span class="main-title">صورت‌حساب رسمی فروش کالا</span> <span class="sub-title">سامانه توزیع کالا و انبارداری یکپارچه همکار کالا (بانک کالا)</span> </div> <div class="meta-info-box"> <div>شماره فاکتور: <strong>INV-${order.id}</strong></div> <div>تاریخ ثبت: <strong>${orderDate}</strong></div> <div>روش پرداخت: <strong>${order.paymentMethod ==='MANUAL' ?'پرداخت دستی / فاکتور رسمی' :'پرداخت آنلاین'}</strong></div> <div>وضعیت سفارش: <strong style="color: #059669;">${ order.status ==='PAID' ?'پرداخت شده' : order.status ==='PREPARING' ?'در حال آماده‌سازی' : order.status ==='COMPLETED' ?'تکمیل و ارسال شده' :'تایید شده / در انتظار پرداخت' }</strong></div> </div> </div> <!-- Parties details --> <div class="parties-container"> <!-- Supplier (Seller) --> <div class="party-box"> <div class="party-title">مشخصات فروشنده (تامین‌کننده کالا)</div> <div class="party-row"> <div>نام تجاری / برند: <strong>${sellerBrandName}</strong></div> <div>شناسه تامین‌کننده: <strong style="font-family:'Courier New', monospace;">${sellerUsername}</strong></div> </div> <div style="margin-top: 4px; font-size: 11px; color: #64748b;"> مبدا ارسال: تهران، انبار مرکزی پردازش کالا و مرسولات همکار کالا </div> </div> <!-- Store Manager (Buyer) --> <div class="party-box" style="border-color: #94a3b8;"> <div class="party-title" style="color: #0f172a; border-bottom-color: #cbd5e1;">مشخصات خریدار (فروشگاه عضو پلتفرم)</div> <div class="party-row"> <div>نام فروشگاه خریدار: <strong>${buyerStoreName}</strong></div> <div>نام کاربری خریدار: <strong style="font-family:'Courier New', monospace;">${buyerUsername}</strong></div> </div> ${order.shippingAddress ?` <div style="margin-top: 6px; padding-top: 6px; border-top: 1px dashed #e2e8f0; font-size: 11.5px;"> نشانی ارسال مرسولات: <strong>${parsed.province ?`${parsed.province}، ${parsed.city}، ${parsed.detail}` : parsed.detail}</strong> ${parsed.recipientName ?`<br/>تحویل‌گیرنده: <strong>${parsed.recipientName}</strong> (شماره تماس: <span style="font-family:'Courier New', monospace;">${parsed.recipientPhone}</span>)` :''} </div>` :` <div style="margin-top: 6px; padding-top: 6px; border-top: 1px dashed #e2e8f0; font-size: 11.5px; color: #64748b;"> نوع ارسال: <strong>پنل پستی شخصی (بارگذاری لیبل پستی مستقیم به تامین‌کننده)</strong> </div>`} </div> </div> <!-- Items Table --> <table class="items-table"> <thead> <tr> <th style="width: 6%;">ردیف</th> <th style="width: 50%; text-align: right;">نام کالا / جزئیات فنی</th> <th style="width: 10%;">تعداد</th> <th style="width: 16%; text-align: left;">قیمت واحد</th> <th style="width: 18%; text-align: left;">جمع کل (ریال)</th> </tr> </thead> <tbody> ${itemsHtml} </tbody> </table> <!-- Calculations Summary --> <div class="calc-summary-wrapper"> <table class="calc-table"> <tr> <td>مبلغ کل بدون مالیات:</td> <td class="text-left font-mono">${totalBaseAmount.toLocaleString()} ریال</td> </tr> <tr> <td>مالیات بر ارزش افزوده و عوارض (${taxRate}٪):</td> <td class="text-left font-mono">${totalTax.toLocaleString()} ریال</td> </tr> <tr class="total-row"> <td>مبلغ کل نهایی (قابل پرداخت):</td> <td class="text-left font-mono">${totalPayable.toLocaleString()} ریال</td> </tr> </table> </div> <!-- Signatures --> <div class="signatures-section"> <div class="signature-box"> <div class="signature-title">مهر و امضای فروشنده</div> <div>شرکت توزیع همکار کالا (انبارداری مرکزی)</div> </div> <div class="signature-box"> <div class="signature-title">مهر و امضای خریدار</div> <div>${buyerStoreName}</div> </div> </div> <!-- Footer Terms --> <div class="footer-note"> این سند بر اساس قوانین تجارت الکترونیک به صورت دیجیتال صادر شده و معتبر می‌باشد.<br/> فروشگاه‌های همکار موظفند سفارشات ثبت شده در این سند را طبق شرایط تفاهم‌نامه همکاری، ثبت و تایید نمایند. هرگونه مغایرت باید حداکثر ظرف ۲۴ ساعت کاری گزارش شود. </div> </div> </body> </html>`; printWindow.document.write(invoiceHtml); printWindow.document.close();
}
