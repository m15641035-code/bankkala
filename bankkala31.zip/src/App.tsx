import Announcements from "./components/Announcements";
import StoreManagerDashboard from "./components/store-manager/StoreManagerDashboard";
import SuperAdminDashboard from "./components/superadmin/SuperAdminDashboard";
import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { useTheme } from "./components/ThemeProvider";
import { ThemeToggleFloating } from "./components/ThemeToggleFloating";

import {
  User,
  Lock,
  ArrowLeft,
  ArrowRight,
  Check,
  Store,
  Truck,
  AlertCircle,
  Info,
  CheckCircle,
  CheckCircle2,
  Users,
  Package,
  LogOut,
  ShieldCheck,
  Building2,
  CreditCard,
  FileText,
  Database,
  Globe,
  Layers,
  TrendingUp,
  RefreshCw,
  Eye,
  EyeOff,
  Sun,
  Moon,
} from "lucide-react";
import { SupplierDashboard } from "./components/supplier/SupplierDashboard";
import ReferrerDashboard from "./components/referrer/ReferrerDashboard";
import { PROVINCES } from "./data/provinces";

// Shaba validation function

function formatAndValidateShaba(input: string): {
  isValid: boolean;
  formatted?: string;
  error?: string;
} {
  let clean = input.toUpperCase().replace(/[\s-]/g, "");
  if (!clean.startsWith("IR")) {
    clean = "IR" + clean;
  }
  const numericPart = clean.substring(2);
  if (numericPart.length !== 24 || !/^\d{24}$/.test(numericPart)) {
    return {
      isValid: false,
      error: "شماره شبا باید دقیقاً شامل ۲۴ رقم عددی باشد.",
    };
  }
  return {
    isValid: true,
    formatted: clean,
  };
}
interface PasswordStrength {
  score: number;
  label: string;
  color: string;
  width: string;
  hasMinLength: boolean;
  hasUpperLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
}
function getPasswordStrength(pwd: string): PasswordStrength {
  const hasMinLength = pwd.length >= 8;
  const hasUpperLower = /[a-z]/.test(pwd) && /[A-Z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[@$!%*?&#^()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd);
  let score = 0;
  if (pwd) {
    if (hasMinLength) score++;
    if (hasUpperLower) score++;
    if (hasNumber) score++;
    if (hasSpecial) score++;
  }
  let label = "خیلی ضعیف";
  let color = "bg-danger";
  let width = "w-[15%]";
  if (score === 1) {
    label = "ضعیف";
    color = "bg-danger";
    width = "w-[30%]";
  } else if (score === 2) {
    label = "متوسط";
    color = "bg-warning";
    width = "w-[55%]";
  } else if (score === 3) {
    label = "خوب";
    color = "bg-success";
    width = "w-[75%]";
  } else if (score === 4) {
    label = "عالی";
    color = "bg-success";
    width = "w-[100%]";
  } else if (!pwd) {
    label = "بدون رمز";
    color = "bg-surface";
    width = "w-0";
  }
  return {
    score,
    label,
    color,
    width,
    hasMinLength,
    hasUpperLower,
    hasNumber,
    hasSpecial,
  };
}
interface SearchableSelectProps {
  label: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
  disabled?: boolean;
}
function SearchableSelect({
  label,
  placeholder,
  value,
  onChange,
  options,
  disabled = false,
}: SearchableSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = React.useRef<HTMLDivElement>(null);
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  const filteredOptions = options.filter((opt) =>
    opt.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <div className="relative" ref={containerRef}>
      {" "}
      <label className="block text-xs font-black text-secondary mb-1.5">
        {label}
      </label>{" "}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-4 py-2.5 bg-background/50 border rounded-xl text-sm text-right flex justify-between items-center focus:outline-none focus:ring-2 focus:ring-primary-default disabled:opacity-50 text-primary placeholder:text-muted dark:placeholder:text-muted font-medium cursor-pointer"
      >
        {" "}
        <span className={value ? "text-primary font-medium" : "text-muted"}>
          {" "}
          {value || placeholder}{" "}
        </span>{" "}
        <svg
          className={`w-4 h-4 text-muted transition-transform ${isOpen ? "rotate-180" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          {" "}
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 9l-7 7-7-7"
          />{" "}
        </svg>{" "}
      </button>{" "}
      {isOpen && (
        <div className="absolute z-50 mt-1 w-full bg-card border rounded-xl shadow-xl max-h-60 overflow-hidden flex flex-col">
          {" "}
          <div className="p-2 border-b border-subtle bg-background">
            {" "}
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو کنید..."
              className="w-full px-3 py-1.5 text-xs bg-surface border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-default text-right text-primary"
              autoFocus
            />{" "}
          </div>{" "}
          <div className="overflow-y-auto flex-1 bg-card">
            {" "}
            {filteredOptions.length === 0 ? (
              <div className="p-3 text-xs text-muted text-center">
                موردی یافت نشد
              </div>
            ) : (
              filteredOptions.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => {
                    onChange(opt);
                    setIsOpen(false);
                    setSearch("");
                  }}
                  className={`w-full text-right px-4 py-2 text-xs transition-colors hover:bg-primary-default/10 cursor-pointer ${value === opt ? "bg-primary-default/10/75 font-bold text-primary-default" : "text-secondary"}`}
                >
                  {" "}
                  {opt}{" "}
                </button>
              ))
            )}{" "}
          </div>{" "}
        </div>
      )}{" "}
    </div>
  );
}
export default function App() {
  // Navigation states
  //'login' |'role_select' |'supplier_form' |'store_manager_form' |'dashboard'
  const [view, setView] = useState<
    | "login"
    | "role_select"
    | "supplier_form"
    | "store_manager_form"
    | "referrer_form"
    | "dashboard"
  >("login");
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem("token") || "";
  });
  const [notification, setNotification] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [registerError, setRegisterError] = useState<string | null>(null);
  const [refForm, setRefForm] = useState({
    username: "",
    password: "",
    firstName: "",
    lastName: "",
    mobile: "",
    email: "",
  });
  const { theme, toggleTheme } = useTheme();
  const darkMode = theme === "dark";
  // Auto-login if token exists
  useEffect(() => {
    if (token) {
      // In a real app we'd fetch profile. Let's decode or trust token for demonstration.
      try {
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
          setCurrentUser(JSON.parse(storedUser));
          setView("dashboard");
        }
      } catch (e) {
        
        localStorage.removeItem("user");
      }
    }
  }, [token]);

  // Fetch and cache system configuration rules
  useEffect(() => {
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data && !data.error) {
          localStorage.setItem("system_config", JSON.stringify(data));
        }
      })
      .catch((err) => console.error("Error caching system config:", err));
  }, []);
  // Check for payment callback redirect parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paymentStatus = params.get("payment_status");
    const trackId = params.get("trackId");
    const invoiceId = params.get("invoiceId");
    const reason = params.get("reason");
    const refParam = params.get("ref");
    if (refParam) {
      sessionStorage.setItem("referralCode", refParam);
      setSupplierData((prev: any) => ({ ...prev, referralCode: refParam }));
      showNotification(`کد معرف ${refParam} شناسایی و ذخیره شد.`, "success");
    }
    if (paymentStatus) {
      if (paymentStatus === "success") {
        showNotification(
          `تسویه حساب فاکتور رسمی شماره INV-${invoiceId} با کد رهگیری ${trackId} با موفقیت انجام شد و مبالغ تامین‌کنندگان شارژ گردید.`,
          "success",
        );
      } else if (paymentStatus === "failed") {
        const errorMsg =
          reason === "verification_failed"
            ? "تایید صحت تراکنش درگاه با خطا مواجه شد."
            : "عملیات پرداخت لغو شد یا ناموفق بود.";
        showNotification(
          `پرداخت فاکتور شماره INV-${invoiceId} ناموفق بود. ${errorMsg}`,
          "error",
        );
      }
      // Clean up URL query parameters so they don't keep showing on refresh
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);
  const showNotification = (message: string, type: "success" | "error") => {
    setNotification({
      message,
      type,
    });
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  // Login form state
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginShake, setLoginShake] = useState(false);
  const [publicMessages, setPublicMessages] = useState<any[]>([]);
  const [loginUsernameFocused, setLoginUsernameFocused] = useState(false);
  const [loginPasswordFocused, setLoginPasswordFocused] = useState(false);
  const [activeBanner, setActiveBanner] = useState<any>(null);
  useEffect(() => {
    if (view === 'login') {
      fetch('/api/banners').then(res => res.json()).then(data => {
        if (Array.isArray(data)) {
          const active = data.find((b: any) => b.isActive);
          if (active) setActiveBanner(active);
        }
      }).catch(() => {});
    }
  }, [view]);
  useEffect(() => {
    if (view === "login") {
      fetch("/api/public-messages")
        .then((res) => res.json())
        .then((data) => setPublicMessages(Array.isArray(data) ? data : []))
        .catch((err) => console.error("Error fetching public messages:", err));
    }
  }, [view]);

  // Supplier form state (5 steps)
  const [supplierStep, setSupplierStep] = useState(() => {
    const saved = sessionStorage.getItem("supplierStep");
    return saved ? parseInt(saved) : 1;
  });
  const [supplierErrors, setSupplierErrors] = useState<Record<string, string>>(
    {},
  );
  const [supplierData, setSupplierData] = useState(() => {
    const saved = sessionStorage.getItem("supplierData");
    if (saved) return JSON.parse(saved);
    return {
      firstName: "",
      lastName: "",
      mobile: "",
      email: "",
      brandName: "",
      activityType: "PRODUCER",
      address: "",
      province: "",
      city: "",
      postalCode: "",
      telephone: "",
      website: "",
      nationalCode: "",
      accountHolderName: "",
      shaba: "IR",
      bankName: "",
      termsAccepted: false,
      agreementVersion: "",
      agreementAcceptedAt: "",
      username: "",
      password: "",
      confirmPassword: "",
      referralCode: sessionStorage.getItem("referralCode") || "",
    };
  });
  useEffect(() => {
    sessionStorage.setItem("supplierData", JSON.stringify(supplierData));
  }, [supplierData]);
  useEffect(() => {
    sessionStorage.setItem("supplierStep", supplierStep.toString());
  }, [supplierStep]);

  // Store Manager form state (4 steps)
  const [storeStep, setStoreStep] = useState(() => {
    const saved = sessionStorage.getItem("storeStep");
    return saved ? parseInt(saved) : 1;
  });
  const [storeErrors, setStoreErrors] = useState<Record<string, string>>({});
  const [storeData, setStoreData] = useState(() => {
    const saved = sessionStorage.getItem("storeData");
    if (saved) return JSON.parse(saved);
    return {
      firstName: "",
      lastName: "",
      mobile: "",
      email: "",
      storeName: "",
      storeUrl: "",
      platformType: "WOOCOMMERCE",
      fieldOfActivity: "",
      productCount: "",
      storeAddress: "",
      username: "",
      password: "",
      confirmPassword: "",
    };
  });
  useEffect(() => {
    sessionStorage.setItem("storeData", JSON.stringify(storeData));
  }, [storeData]);
  useEffect(() => {
    sessionStorage.setItem("storeStep", storeStep.toString());
  }, [storeStep]);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [termsReadProgress, setTermsReadProgress] = useState(false);

  // Draft save functions
  const saveSupplierDraft = () => {
    localStorage.setItem("supplierDataDraft", JSON.stringify(supplierData));
    localStorage.setItem("supplierStepDraft", supplierStep.toString());
    showNotification(
      "پیش‌نویس ثبت‌نام تامین‌کننده با موفقیت در مرورگر ذخیره شد. هر زمان بازگردید، می‌توانید آن را بازیابی کنید.",
      "success",
    );
  };
  const saveStoreDraft = () => {
    localStorage.setItem("storeDataDraft", JSON.stringify(storeData));
    localStorage.setItem("storeStepDraft", storeStep.toString());
    showNotification(
      "پیش‌نویس ثبت‌نام مدیر فروشگاه با موفقیت در مرورگر ذخیره شد. هر زمان بازگردید، می‌توانید آن را بازیابی کنید.",
      "success",
    );
  };
  const handleSupplierStepChange = (targetStep: number) => {
    let errors: Record<string, string> = {};
    if (supplierStep === 1) {
      if (!supplierData.firstName) errors.firstName = "نام الزامی است";
      if (!supplierData.lastName) errors.lastName = "نام خانوادگی الزامی است";
      if (!supplierData.mobile || !/^09\d{9}$/.test(supplierData.mobile))
        errors.mobile = "شماره موبایل نامعتبر است. فرمت: 09123456789";
      if (!supplierData.nationalCode || supplierData.nationalCode.length !== 10)
        errors.nationalCode = "کد ملی باید ۱۰ رقم باشد";
    } else if (supplierStep === 2) {
      if (!supplierData.brandName) errors.brandName = "نام تجاری الزامی است";
      if (!supplierData.province) errors.province = "استان الزامی است";
      if (!supplierData.city) errors.city = "شهر الزامی است";
      if (!supplierData.address) errors.address = "آدرس الزامی است";
    } else if (supplierStep === 3) {
      if (!supplierData.accountHolderName)
        errors.accountHolderName = "نام صاحب حساب الزامی است";
      if (!supplierData.bankName) errors.bankName = "نام بانک الزامی است";
      if (!supplierData.shaba) errors.shaba = "شماره شبا الزامی است";
    } else if (supplierStep === 4) {
      if (!supplierData.termsAccepted)
        errors.termsAccepted = "پذیرش قوانین الزامی است";
    } else if (supplierStep === 5) {
      if (!supplierData.username) errors.username = "نام کاربری الزامی است";
      if (!supplierData.password) {
        errors.password = "کلمه عبور الزامی است";
      } else {
        const strength = getPasswordStrength(supplierData.password);
        if (strength.score < 2) {
          errors.password =
            "رمز عبور بسیار ضعیف است. لطفاً رمزی با امنیت متوسط یا بالاتر انتخاب کنید.";
        }
      }
      if (supplierData.password !== supplierData.confirmPassword) {
        errors.confirmPassword = "تکرار کلمه عبور با کلمه عبور مطابقت ندارد";
      }
    }
    if (Object.keys(errors).length > 0) {
      setSupplierErrors(errors);
      return;
    }
    setSupplierErrors({});
    if (targetStep <= 5) {
      setSupplierStep(targetStep);
    }
  };
  const handleStoreStepChange = (targetStep: number) => {
    let errors: Record<string, string> = {};
    if (storeStep === 1) {
      if (!storeData.firstName) errors.firstName = "نام الزامی است";
      if (!storeData.lastName) errors.lastName = "نام خانوادگی الزامی است";
      if (!storeData.mobile || !/^09\d{9}$/.test(storeData.mobile))
        errors.mobile = "شماره موبایل نامعتبر است. فرمت: 09123456789";
    } else if (storeStep === 2) {
      if (!storeData.storeName) errors.storeName = "نام فروشگاه الزامی است";
      if (!storeData.storeUrl) errors.storeUrl = "آدرس وب‌سایت الزامی است";
    } else if (storeStep === 3) {
      if (!storeData.platformType)
        errors.platformType = "نوع پلتفرم الزامی است";
    } else if (storeStep === 4) {
      if (!storeData.username) errors.username = "نام کاربری الزامی است";
      if (!storeData.password) {
        errors.password = "کلمه عبور الزامی است";
      } else {
        const strength = getPasswordStrength(storeData.password);
        if (strength.score < 2) {
          errors.password =
            "رمز عبور بسیار ضعیف است. لطفاً رمزی با امنیت متوسط یا بالاتر انتخاب کنید.";
        }
      }
      if (storeData.password !== storeData.confirmPassword) {
        errors.confirmPassword = "تکرار کلمه عبور با کلمه عبور مطابقت ندارد";
      }
    }
    if (Object.keys(errors).length > 0) {
      setStoreErrors(errors);
      return;
    }
    setStoreErrors({});
    if (targetStep <= 4) {
      setStoreStep(targetStep);
    }
  };
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("/api/auth/login", { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: loginUsername,
          password: loginPassword,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setLoginShake(true);
        setTimeout(() => setLoginShake(false), 500);
        throw new Error(data.error || "ورود ناموفق");
      }
      
      localStorage.setItem("user", JSON.stringify(data.user));
      localStorage.setItem("token", data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      showNotification("ورود با موفقیت انجام شد.", "success");
      setView("dashboard");
    } catch (err: any) {
      showNotification(err.message, "error");
    } finally {
      setLoading(false);
    }
  };
  const handleSupplierRegister = async () => {
    handleSupplierStepChange(5);
    if (Object.keys(supplierErrors).length > 0) return;
    setLoading(true);
    setRegisterError(null);
    try {
      const payload = {
        ...supplierData,
        agreementAccepted: supplierData.termsAccepted,
      };
      const response = await fetch("/api/auth/register/supplier", { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || "خطا در ثبت‌نام تامین‌کننده");
      
      localStorage.setItem("user", JSON.stringify(data.user));
      localStorage.setItem("token", data.token);
      setToken(data.token);
      setCurrentUser(data.user);

      // Clear all registration drafts
      sessionStorage.removeItem("supplierData");
      sessionStorage.removeItem("supplierStep");
      localStorage.removeItem("supplierDataDraft");
      localStorage.removeItem("supplierStepDraft");
      showNotification(
        "ثبت‌نام شما به عنوان تامین‌کننده با موفقیت انجام شد.",
        "success",
      );
      window.history.pushState({}, "", "/supplier/dashboard");
      setView("dashboard");
    } catch (err: any) {
      setRegisterError(err.message);
      showNotification(err.message, "error");
    } finally {
      setLoading(false);
    }
  };
  const handleStoreManagerRegister = async () => {
    handleStoreStepChange(4);
    if (Object.keys(storeErrors).length > 0) return;
    setLoading(true);
    try {
      const response = await fetch("/api/auth/register/store-manager", { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(storeData),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || "خطا در ثبت‌نام مدیر فروشگاه");
      
      localStorage.setItem("user", JSON.stringify(data.user));
      localStorage.setItem("token", data.token);
      setToken(data.token);
      setCurrentUser(data.user);

      // Clear all registration drafts
      sessionStorage.removeItem("storeData");
      sessionStorage.removeItem("storeStep");
      localStorage.removeItem("storeDataDraft");
      localStorage.removeItem("storeStepDraft");
      showNotification(
        "ثبت‌نام شما به عنوان مدیر فروشگاه با موفقیت انجام شد.",
        "success",
      );
      setView("dashboard");
    } catch (err: any) {
      showNotification(err.message, "error");
    } finally {
      setLoading(false);
    }
  };
  const handleReferrerRegister = async () => {
    if (!refForm.username || !refForm.password || !refForm.firstName || !refForm.lastName || !refForm.mobile) {
      showNotification("لطفاً تمامی فیلدهای اجباری را تکمیل نمایید.", "error");
      return;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/auth/register-referrer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(refForm),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || "خطا در ثبت‌نام معرف");

      localStorage.setItem("user", JSON.stringify(data.user));
      localStorage.setItem("token", data.token);
      setToken(data.token);
      setCurrentUser(data.user);

      showNotification(
        "ثبت‌نام شما به عنوان معرف با موفقیت انجام شد.",
        "success",
      );
      setView("dashboard");
    } catch (err: any) {
      showNotification(err.message, "error");
    } finally {
      setLoading(false);
    }
  };
  const logout = () => {
    
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    setToken(null);
    setCurrentUser(null);
    setView("login");
    showNotification("با موفقیت خارج شدید.", "success");
  };
  const getCitiesForProvince = (provName: string) => {
    return PROVINCES.find((p) => p.name === provName)?.cities || [];
  };
  const renderDashboard = () => {
    if (currentUser?.role === "SUPPLIER") {
      return (
        <SupplierDashboard
          user={currentUser}
          onLogout={logout}
          showNotification={showNotification}
          onUpdateUser={(updatedUser: any) => {
            setCurrentUser(updatedUser);
            localStorage.setItem("user", JSON.stringify(updatedUser));
          }}
        />
      );
    } else if (currentUser?.role === "STORE_MANAGER") {
      return (
        <StoreManagerDashboard
          user={currentUser}
          onLogout={logout}
          showNotification={showNotification}
        />
      );
    } else if (currentUser?.role === "SUPER_ADMIN") {
      return (
        <SuperAdminDashboard
          user={currentUser}
          onLogout={logout}
          showNotification={showNotification}
        />
      );
    } else if (currentUser?.role === "REFERRER") {
      return (
        <ReferrerDashboard
          currentUser={currentUser}
          onLogout={logout}
          showNotification={showNotification}
        />
      );
    }
    return <div>نقش کاربری نامعتبر است.</div>;
  };
  return (
    <>
      {" "}
      <div className="print:hidden min-h-screen bg-background font-sans text-primary selection:bg-primary-default/20 selection:text-primary-hover overflow-x-hidden flex flex-col transition-colors duration-300 relative">
        {" "}
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          {" "}
          {/* Advanced sophisticated floating gradients */}
          <div className="absolute top-[-20%] left-[-20%] w-[75%] h-[75%] bg-gradient-to-tr from-indigo-600/25 via-purple-500/15 to-transparent dark:from-indigo-500/20 dark:via-purple-500/10 rounded-full blur-[140px] animate-float"></div>{" "}
          <div className="absolute bottom-[-20%] right-[-20%] w-[75%] h-[75%] bg-gradient-to-bl from-emerald-500/20 via-teal-500/15 to-transparent dark:from-emerald-950/30 dark:via-teal-950/20 rounded-full blur-[140px] animate-float-delayed"></div>{" "}
          <div
            className="absolute top-[20%] right-[10%] w-[45%] h-[45%] bg-danger/15 rounded-full blur-[120px] animate-float"
            style={{
              animationDelay: "3s",
            }}
          ></div>{" "}
          <div
            className="absolute bottom-[20%] left-[10%] w-[40%] h-[40%] bg-amber-300/15 rounded-full blur-[110px] animate-float-delayed"
            style={{
              animationDelay: "6s",
            }}
          ></div>{" "}
        </div>{" "}
        {notification && (
          <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] animate-bounce-short">
            {" "}
            <div
              className={`flex items-center gap-2 px-6 py-3 rounded-full shadow-2xl font-bold text-sm backdrop-blur-md border ${notification.type === "success" ? "bg-success/90 text-inverse border-success" : "bg-danger/90 text-inverse border-danger"}`}
            >
              {" "}
              {notification.type === "success" ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : (
                <AlertCircle className="w-5 h-5" />
              )}
              {notification.message}
            </div>{" "}
          </div>
        )}
        {view === "dashboard" && renderDashboard()}
        {view !== "dashboard" && (
          <main className="flex-1 flex flex-col relative z-10 p-4 md:p-8 lg:p-12 items-center justify-center bg-[radial-gradient(#e2e8f0_1.2px,transparent_1.2px)] dark:bg-[radial-gradient(#1e293b_1.2px,transparent_1.2px)] [background-size:24px_24px]">
            {" "}
            <div className={`w-full perspective-1000 ${view === "login" ? "max-w-[1000px]" : "max-w-[540px]"}`}>
              {" "}
              {/* Login View */}
              {view === "login" && (
  <div className="w-full max-w-[1000px] flex flex-col md:flex-row bg-white dark:bg-surface rounded-[2.5rem] shadow-2xl overflow-hidden border border-border-default/50 dark:border-border-subtle/50" dir="rtl">
    {/* Right Side: Login Form */}
    <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary-default/10 rounded-full blur-3xl -z-10 translate-x-1/3 -translate-y-1/3"></div>
      
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 bg-gradient-to-br from-primary-default to-accent text-white rounded-xl flex items-center justify-center shadow-lg shadow-primary-default/20">
          <Store className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-text-primary">بانک کالا</h1>
          <p className="text-xs font-bold text-primary-default">پلتفرم یکپارچه B2B</p>
        </div>
      </div>

      <div className="mb-8 text-right">
        <h2 className="text-xl font-black text-text-primary mb-2">ورود به حساب کاربری</h2>
        <p className="text-sm text-text-muted font-medium">جهت ورود به سیستم اطلاعات خود را وارد کنید</p>
      </div>

      <form onSubmit={handleLoginSubmit} className="space-y-5">
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-text-secondary">نام کاربری</label>
          <div className="relative group">
            <input
              type="text"
              required
              value={loginUsername}
              onChange={(e) => setLoginUsername(e.target.value)}
              className="w-full pl-4 pr-11 py-3.5 bg-background hover:bg-surface/80 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all text-text-primary font-bold border-gray-300 dark:border-indigo-500/50"
              placeholder="نام کاربری یا موبایل"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-text-muted group-focus-within:text-primary-default transition-colors">
              <User className="w-5 h-5" />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-text-secondary">رمز عبور</label>
            <a href="#" className="text-[10px] text-primary-default font-bold hover:underline">فراموشی رمز؟</a>
          </div>
          <div className="relative group">
            <input
              type={showLoginPassword ? "text" : "password"}
              required
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              className="w-full pl-12 pr-11 py-3.5 bg-background hover:bg-surface/80 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all text-text-primary font-bold border-gray-300 dark:border-indigo-500/50"
              placeholder="رمز عبور"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-text-muted group-focus-within:text-primary-default transition-colors">
              <Lock className="w-5 h-5" />
            </div>
            <button
              type="button"
              onClick={() => setShowLoginPassword(!showLoginPassword)}
              className="absolute inset-y-0 left-0 pl-4 flex items-center text-text-muted hover:text-primary-default transition-colors"
            >
              {showLoginPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <motion.button
          type="submit"
          disabled={loading}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          className="w-full bg-primary-default hover:bg-primary-hover text-white font-black py-4 rounded-xl shadow-lg shadow-primary-default/25 transition-all flex items-center justify-center gap-2 mt-2 disabled:opacity-75"
        >
          {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <span>ورود به سیستم</span>}
        </motion.button>
      </form>

      
      {/* Quick accounts selection removed as requested */}
      
      <div className="mt-8 text-center border-t border-border-default/50 dark:border-border-subtle/50 pt-6">
        <p className="text-xs text-text-muted">
          حساب کاربری ندارید؟ 
          <button onClick={() => setView("role_select")} className="text-primary-default font-bold mr-1 hover:underline">ثبت‌نام سریع</button>
        </p>
      </div>
    </div>

    {/* Left Side: Dynamic Banners & Announcements */}
    <div className="hidden md:flex w-1/2 bg-surface dark:bg-background relative p-8 flex-col justify-between overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] z-0"></div>
      
      <div className="relative z-10">
        <div className="bg-primary-default/10 text-primary-default text-xs font-bold px-3 py-1.5 rounded-full inline-block mb-4">
          اطلاعیه سامانه
        </div>
        <Announcements role="ALL" />
      </div>

      {activeBanner && (
        <div className="relative z-10 mt-12 bg-gradient-to-br from-primary-default/5 to-accent/5 border border-primary-default/10 rounded-2xl p-6 backdrop-blur-sm">
          {activeBanner.imageUrl ? (
            <img src={activeBanner.imageUrl} alt={activeBanner.title} className="w-full h-32 object-cover rounded-xl mb-4" />
          ) : (
            <div className="w-10 h-10 bg-primary-default/10 text-primary-default rounded-xl flex items-center justify-center mb-4">
              <Globe className="w-5 h-5" />
            </div>
          )}
          <h3 className="text-lg font-black text-text-primary mb-2">{activeBanner.title}</h3>
          <p className="text-sm text-text-muted leading-relaxed">
            {activeBanner.description}
          </p>
        </div>
      )}
    </div>
  </div>
)}
              {/* Role Select View */}
              {view === "role_select" && (
                <div
                  id="view-role"
                  className="bg-card/95 backdrop-blur-xl p-8 rounded-[2rem] shadow-2xl border animate-fade-in text-center relative"
                >
                  {" "}
                  <button
                    type="button"
                    onClick={() => setView("login")}
                    className="absolute top-6 right-6 text-muted hover:text-primary transition-colors bg-surface rounded-full p-2 cursor-pointer"
                    aria-label="بازگشت به صفحه ورود"
                  >
                    {" "}
                    <ArrowLeft className="w-5 h-5" />{" "}
                  </button>{" "}

                  <div className="w-16 h-16 bg-primary-default/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    {" "}
                    <Users className="w-8 h-8 text-primary-default" />{" "}
                  </div>{" "}
                  <h2 className="text-2xl font-black text-primary mb-2">
                    به بانک کالا بپیوندید
                  </h2>{" "}
                  <p className="text-primary text-sm mb-8">
                    نوع حساب کاربری خود را برای شروع انتخاب کنید
                  </p>{" "}
                  <div className="space-y-4">
                    {" "}
                    <button
                      type="button"
                      onClick={() => setView("supplier_form")}
                      className="w-full group bg-card border-2 border-subtle p-5 rounded-2xl hover:border-primary-default hover:shadow-xl hover:shadow-primary-default/10 transition-all text-right relative overflow-hidden flex items-center gap-4 cursor-pointer"
                      aria-label="ثبت نام به عنوان تامین کننده یا عمده فروش"
                    >
                      {" "}
                      <div className="w-14 h-14 bg-primary-default/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 group-hover:bg-primary-hover group-hover:text-white transition-all duration-300 text-primary-default">
                        {" "}
                        <Package className="w-6 h-6" />{" "}
                      </div>{" "}
                      <div>
                        {" "}
                        <h3 className="text-lg font-black text-primary group-hover:text-primary-hover dark:group-hover:text-primary-default transition-colors">
                          تامین‌کننده / عمده‌فروش
                        </h3>{" "}
                        <p className="text-xs text-primary mt-1 leading-relaxed font-medium">
                          ثبت محصولات، قیمت‌گذاری عمده و دریافت سفارشات از
                          فروشگاه‌ها
                        </p>{" "}
                      </div>{" "}
                    </button>{" "}
                    <button
                      type="button"
                      onClick={() => setView("store_manager_form")}
                      className="w-full group bg-card border-2 border-subtle p-5 rounded-2xl hover:border-success hover:shadow-xl hover:shadow-emerald-600/10 transition-all text-right relative overflow-hidden flex items-center gap-4 cursor-pointer"
                      aria-label="ثبت نام به عنوان مدیر فروشگاه خرده فروشی"
                    >
                      {" "}
                      <div className="w-14 h-14 bg-success/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 group-hover:bg-success group-hover:text-white transition-all duration-300 text-success">
                        {" "}
                        <Store className="w-6 h-6" />{" "}
                      </div>{" "}
                      <div>
                        {" "}
                        <h3 className="text-lg font-black text-primary group-hover:text-success dark:group-hover:text-success transition-colors">
                          مدیر فروشگاه (خرده‌فروش)
                        </h3>{" "}
                        <p className="text-xs text-primary mt-1 leading-relaxed font-medium">
                          تامین کالا برای فروشگاه، اتصال ووکامرس و ارسال مستقیم
                          به مشتری
                        </p>{" "}
                      </div>{" "}
                    </button>{" "}
                    <button
                      type="button"
                      onClick={() => setView("referrer_form")}
                      className="w-full group bg-card border-2 border-subtle p-5 rounded-2xl hover:border-indigo-500 hover:shadow-xl hover:shadow-indigo-500/10 transition-all text-right relative overflow-hidden flex items-center gap-4 cursor-pointer"
                      aria-label="ثبت نام به عنوان معرف سیستم"
                    >
                      {" "}
                      <div className="w-14 h-14 bg-indigo-500/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 text-indigo-500">
                        {" "}
                        <Users className="w-6 h-6" />{" "}
                      </div>{" "}
                      <div>
                        {" "}
                        <h3 className="text-lg font-black text-primary group-hover:text-indigo-600 dark:group-hover:text-indigo-500 transition-colors">
                          همکار معرف (Referrer)
                        </h3>{" "}
                        <p className="text-xs text-primary mt-1 leading-relaxed font-medium">
                          کسب سود همیشگی از فروش تامین‌کنندگانی که به سیستم معرفی می‌کنید
                        </p>{" "}
                      </div>{" "}
                    </button>{" "}
                  </div>{" "}
                </div>
              )}
            </div>{" "}
            <div className="w-full max-w-[800px]">
              {" "}
              {/* 3. SUPPLIER MULTI-STEP FORM */}
              {view === "supplier_form" && (
                <div
                  id="view-supplier-form"
                  className="space-y-6 animate-fade-in text-right"
                >
                  {" "}
                  <div className="bg-card/95 backdrop-blur-xl p-6 md:p-10 rounded-[2rem] shadow-2xl border">
                    {" "}
                    <div className="flex items-center justify-between mb-8 pb-6 border-b border-subtle">
                      {" "}
                      <div>
                        {" "}
                        <h2 className="text-2xl font-black text-primary flex items-center gap-3">
                          {" "}
                          <div className="w-10 h-10 bg-primary-default/20 text-primary-default rounded-xl flex items-center justify-center">
                            {" "}
                            <Package className="w-5 h-5" />{" "}
                          </div>{" "}
                          ثبت‌نام تامین‌کننده{" "}
                        </h2>{" "}
                        <p className="text-muted text-sm mt-2 mr-1">
                          مرحله {supplierStep}
                          از ۵:{" "}
                          {supplierStep === 1
                            ? "اطلاعات فردی"
                            : supplierStep === 2
                              ? "اطلاعات کسب‌وکار"
                              : supplierStep === 3
                                ? "اطلاعات مالی"
                                : supplierStep === 4
                                  ? "پذیرش قوانین"
                                  : "تنظیم رمز عبور"}
                        </p>{" "}
                      </div>{" "}
                      <div className="flex items-center gap-3">
                        {" "}

                        <button
                          onClick={() => setView("role_select")}
                          className="text-muted hover:text-secondary bg-surface p-2.5 rounded-full transition-colors cursor-pointer"
                          title="بازگشت"
                        >
                          {" "}
                          <ArrowLeft className="w-5 h-5" />{" "}
                        </button>{" "}
                      </div>{" "}
                    </div>{" "}
                    {/* Supplier Draft Restore Banner */}
                    {localStorage.getItem("supplierDataDraft") && (
                      <div className="mb-6 p-4 bg-primary-default/10 border border-primary-default/30 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-3 animate-fade-in text-primary-hover text-xs">
                        {" "}
                        <div className="flex items-center gap-2">
                          {" "}
                          <Info className="w-4 h-4 shrink-0 text-primary-default" />{" "}
                          <span>
                            یک پیش‌نویس ذخیره‌شده از ثبت‌نام قبلی شما یافت شد.
                            آیا مایل به بازیابی اطلاعات قبلی هستید؟
                          </span>{" "}
                        </div>{" "}
                        <div className="flex gap-2 shrink-0">
                          {" "}
                          <button
                            type="button"
                            onClick={() => {
                              const savedData =
                                localStorage.getItem("supplierDataDraft");
                              const savedStep =
                                localStorage.getItem("supplierStepDraft");
                              if (savedData) {
                                setSupplierData(JSON.parse(savedData));
                              }
                              if (savedStep) {
                                setSupplierStep(parseInt(savedStep));
                              }
                              showNotification(
                                "پیش‌نویس قبلی شما با موفقیت بازیابی شد.",
                                "success",
                              );
                            }}
                            className="px-3 py-1.5 bg-primary-default hover:bg-primary-hover text-white font-bold rounded-lg transition-colors cursor-pointer"
                          >
                            {" "}
                            بازیابی پیش‌نویس{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={() => {
                              localStorage.removeItem("supplierDataDraft");
                              localStorage.removeItem("supplierStepDraft");
                              showNotification(
                                "پیش‌نویس ذخیره‌شده حذف گردید.",
                                "success",
                              );
                            }}
                            className="px-3 py-1.5 border hover:bg-surface text-secondary font-bold rounded-lg transition-colors cursor-pointer"
                          >
                            {" "}
                            حذف{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                    {/* STEP 1: Personal Info */}
                    {supplierStep === 1 && (
                      <div className="space-y-4 animate-fade-in text-right">
                        {" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              نام *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={supplierData.firstName}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  firstName: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                            />{" "}
                            {supplierErrors.firstName && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.firstName}
                              </p>
                            )}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              نام خانوادگی *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={supplierData.lastName}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  lastName: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                            />{" "}
                            {supplierErrors.lastName && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.lastName}
                              </p>
                            )}
                          </div>{" "}
                        </div>{" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              شماره موبایل *
                            </label>{" "}
                            <input
                              type="tel"
                              required
                              value={supplierData.mobile}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  mobile: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                            {supplierErrors.mobile && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.mobile}
                              </p>
                            )}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              کد ملی *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={supplierData.nationalCode}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  nationalCode: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                            {supplierErrors.nationalCode && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.nationalCode}
                              </p>
                            )}
                          </div>{" "}
                        </div>{" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              ایمیل (اختیاری)
                            </label>{" "}
                            <input
                              type="email"
                              value={supplierData.email}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  email: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              کد معرف (اختیاری)
                            </label>{" "}
                            <input
                              type="text"
                              value={supplierData.referralCode}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  referralCode: e.target.value,
                                })
                              }
                              placeholder="مثال: REF-XYZ123"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                        </div>{" "}
                        <div className="flex gap-3 justify-between items-center mt-6">
                          {" "}
                          <button
                            type="button"
                            onClick={() => handleSupplierStepChange(2)}
                            className="flex-1 bg-primary-default hover:bg-primary-hover dark:hover:bg-primary-hover text-white font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                          >
                            {" "}
                            ادامه مسیر ثبت‌نام{" "}
                            <ArrowLeft className="w-4 h-4" />{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={saveSupplierDraft}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                          >
                            {" "}
                            <Database className="w-4 h-4" /> ذخیره پیش‌نویس{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                    {/* STEP 2: Business Info */}
                    {supplierStep === 2 && (
                      <div className="space-y-4 animate-fade-in text-right">
                        {" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              نام برند / نام تجاری *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={supplierData.brandName}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  brandName: e.target.value,
                                })
                              }
                              placeholder="نام تجاری کسب‌وکار"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                            />{" "}
                            {supplierErrors.brandName && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.brandName}
                              </p>
                            )}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              نوع فعالیت اصلی *
                            </label>{" "}
                            <select
                              value={supplierData.activityType}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  activityType: e.target.value,
                                })
                              }
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default"
                            >
                              {" "}
                              <option value="PRODUCER">تولیدکننده</option>{" "}
                              <option value="WHOLESALER">
                                عمده‌فروش / بنکدار
                              </option>{" "}
                              <option value="IMPORTER">واردکننده مستقیم</option>{" "}
                              <option value="OTHER">سایر</option>{" "}
                            </select>{" "}
                          </div>{" "}
                        </div>{" "}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {" "}
                          <SearchableSelect
                            label="استان *"
                            placeholder="انتخاب استان..."
                            value={supplierData.province}
                            onChange={(val) =>
                              setSupplierData({
                                ...supplierData,
                                province: val,
                                city: "",
                              })
                            }
                            options={PROVINCES.map((p) => p.name)}
                          />{" "}
                          <SearchableSelect
                            label="شهر *"
                            placeholder="انتخاب شهر..."
                            value={supplierData.city}
                            onChange={(val) =>
                              setSupplierData({ ...supplierData, city: val })
                            }
                            options={getCitiesForProvince(
                              supplierData.province,
                            )}
                            disabled={!supplierData.province}
                          />{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              کد پستی *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={supplierData.postalCode}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  postalCode: e.target.value,
                                })
                              }
                              placeholder="کد پستی ۱۰ رقمی"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                            {supplierErrors.postalCode && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.postalCode}
                              </p>
                            )}
                          </div>{" "}
                        </div>{" "}
                        <div>
                          {" "}
                          <label className="block text-xs font-black text-secondary mb-1.5">
                            نشانی دقیق دفتر مرکزی یا انبار *
                          </label>{" "}
                          <textarea
                            rows={2}
                            value={supplierData.address}
                            onChange={(e) =>
                              setSupplierData({
                                ...supplierData,
                                address: e.target.value,
                              })
                            }
                            placeholder="مثال: تهران، خیابان شریعتی، بن‌بست الوند، پلاک ۲، واحد ۴"
                            className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                          />{" "}
                          {supplierErrors.address && (
                            <p className="text-[10px] text-danger mt-1 font-semibold">
                              {supplierErrors.address}
                            </p>
                          )}
                        </div>{" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              تلفن ثابت فروشگاه/شرکت *
                            </label>{" "}
                            <input
                              type="tel"
                              required
                              value={supplierData.telephone}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  telephone: e.target.value,
                                })
                              }
                              placeholder="مثال: 02188888888"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                            {supplierErrors.telephone && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {supplierErrors.telephone}
                              </p>
                            )}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              آدرس وب‌سایت یا کانال فروش (اختیاری)
                            </label>{" "}
                            <input
                              type="url"
                              value={supplierData.website}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  website: e.target.value,
                                })
                              }
                              placeholder="https://mybrand.ir"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all font-mono"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                        </div>{" "}
                        <div className="flex gap-3 justify-between items-center mt-6">
                          {" "}
                          <button
                            type="button"
                            onClick={() => setSupplierStep(1)}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                          >
                            {" "}
                            مرحله قبل{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={() => handleSupplierStepChange(3)}
                            className="flex-1 bg-primary-default hover:bg-primary-hover dark:hover:bg-primary-hover text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                          >
                            {" "}
                            ادامه مسیر ثبت‌نام{" "}
                            <ArrowLeft className="w-4 h-4" />{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={saveSupplierDraft}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                          >
                            {" "}
                            <Database className="w-4 h-4" /> ذخیره پیش‌نویس{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                    {/* STEP 3: Financial Details */}
                    {supplierStep === 3 && (
                      <div className="space-y-4 animate-fade-in text-right">
                        {" "}
                        <div className="p-4 bg-warning/10 border border-amber-200 rounded-xl flex gap-3 text-amber-900 text-xs text-right">
                          {" "}
                          <Info className="w-5 h-5 text-warning shrink-0 mt-0.5" />{" "}
                          <div>
                            {" "}
                            <span className="font-bold block mb-1">
                              دقت در وارد کردن اطلاعات شبا
                            </span>{" "}
                            جهت تسویه حساب و واریز اتوماتیک سهم تامین‌کننده،
                            حتماً شبا بانکی معتبر متعلق به نام صاحب کسب‌وکار را
                            وارد نمایید.{" "}
                          </div>{" "}
                        </div>{" "}
                        <div>
                          {" "}
                          <label className="block text-xs font-black text-secondary mb-1.5">
                            نام و نام خانوادگی صاحب حساب *
                          </label>{" "}
                          <input
                            type="text"
                            required
                            value={supplierData.accountHolderName}
                            onChange={(e) =>
                              setSupplierData({
                                ...supplierData,
                                accountHolderName: e.target.value,
                              })
                            }
                            placeholder="نام کامل ثبت شده در بانک"
                            className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                          />{" "}
                          {supplierErrors.accountHolderName && (
                            <p className="text-[10px] text-danger mt-1 font-semibold">
                              {supplierErrors.accountHolderName}
                            </p>
                          )}
                        </div>{" "}
                        <div>
                          {" "}
                          <div className="flex justify-between items-center mb-1.5">
                            {" "}
                            <label className="block text-xs font-black text-secondary">
                              شماره شبا (IBAN) *
                            </label>{" "}
                            {supplierData.shaba.length >= 24 && (
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${formatAndValidateShaba(supplierData.shaba).isValid ? "bg-success/20 text-emerald-800" : "bg-danger/20 text-rose-800"}`}
                              >
                                {" "}
                                {formatAndValidateShaba(supplierData.shaba)
                                  .isValid
                                  ? "✓ شبا معتبر است"
                                  : "✗ شبا نامعتبر است"}
                              </span>
                            )}
                          </div>{" "}
                          <div className="relative">
                            {" "}
                            <input
                              type="text"
                              required
                              value={supplierData.shaba}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  shaba: e.target.value,
                                })
                              }
                              maxLength={30}
                              placeholder="IR000000000000000000000000"
                              className={`w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:bg-card dark:focus:bg-surface/50 transition-all ${supplierData.shaba.length >= 24 ? (formatAndValidateShaba(supplierData.shaba).isValid ? "border-emerald-300 focus:ring-success" : "border-rose-300 focus:ring-rose-500") : " focus:ring-primary-default"}`}
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                          {supplierErrors.shaba && (
                            <p className="text-[10px] text-danger mt-1 font-semibold">
                              {supplierErrors.shaba}
                            </p>
                          )}
                          <p className="text-[10px] text-muted mt-1">
                            با یا بدون پیشوند IR و فاصله قابل قبول است.
                          </p>{" "}
                        </div>{" "}
                        <div>
                          {" "}
                          <label className="block text-xs font-black text-secondary mb-1.5">
                            نام بانک صادرکننده کارت/حساب *
                          </label>{" "}
                          <input
                            type="text"
                            required
                            value={supplierData.bankName}
                            onChange={(e) =>
                              setSupplierData({
                                ...supplierData,
                                bankName: e.target.value,
                              })
                            }
                            placeholder="مثال: بانک ملی، ملت، سامان و ..."
                            className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-primary-default dark:focus:ring-primary-default focus:bg-card dark:focus:bg-surface/50 transition-all"
                          />{" "}
                          {supplierErrors.bankName && (
                            <p className="text-[10px] text-danger mt-1 font-semibold">
                              {supplierErrors.bankName}
                            </p>
                          )}
                        </div>{" "}
                        <div className="flex gap-3 justify-between items-center mt-6">
                          {" "}
                          <button
                            type="button"
                            onClick={() => setSupplierStep(2)}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                          >
                            {" "}
                            مرحله قبل{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={() => handleSupplierStepChange(4)}
                            className="flex-1 bg-primary-default hover:bg-primary-hover dark:hover:bg-primary-hover text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                          >
                            {" "}
                            ادامه مسیر ثبت‌نام{" "}
                            <ArrowLeft className="w-4 h-4" />{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={saveSupplierDraft}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                          >
                            {" "}
                            <Database className="w-4 h-4" /> ذخیره پیش‌نویس{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                    {/* STEP 4: Terms and Conditions */}
                    {supplierStep === 4 && (
                      <div className="space-y-4 animate-fade-in text-right">
                        {" "}
                        <div className="p-6 bg-background border rounded-2xl space-y-4 text-right">
                          {" "}
                          <div className="flex items-center gap-2">
                            {" "}
                            <FileText className="w-5 h-5 text-primary-default" />{" "}
                            <h4 className="font-bold text-primary text-sm">
                              قوانین و ضوابط همکاری پلتفرم بازارگاه
                            </h4>{" "}
                          </div>{" "}
                          <p className="text-xs text-muted leading-relaxed font-light">
                            {" "}
                            عضویت و فعالیت در بازارگاه به عنوان تامین‌کننده
                            مستلزم مطالعه دقیق، پذیرش بندهای حقوقی و تعهد به
                            تامین کالای باکیفیت و اصل، همگام با قیمت‌گذاری
                            منصفانه است.{" "}
                          </p>{" "}
                          <button
                            onClick={() => {
                              setShowTermsModal(true);
                              setTermsReadProgress(true);
                            }}
                            className="text-xs font-semibold text-primary-default hover:text-primary-hover flex items-center gap-1 cursor-pointer"
                          >
                            {" "}
                            <Info className="w-4 h-4" /> نمایش و مطالعه کامل متن
                            قوانین همکاری{" "}
                          </button>{" "}
                        </div>{" "}
                        <div className="flex items-start gap-2.5">
                          {" "}
                          <input
                            type="checkbox"
                            id="supplier-terms"
                            checked={supplierData.termsAccepted}
                            onChange={(e) => {
                              const isChecked = e.target.checked;
                              setSupplierData({
                                ...supplierData,
                                termsAccepted: isChecked,
                                agreementVersion: isChecked ? "1.0" : "",
                                agreementAcceptedAt: isChecked
                                  ? new Date().toISOString()
                                  : "",
                              });
                            }}
                            className="rounded text-primary-default focus:ring-primary-default border-default w-4 h-4 mt-0.5 cursor-pointer"
                          />{" "}
                          <label
                            htmlFor="supplier-terms"
                            className="text-xs text-secondary leading-relaxed select-none cursor-pointer"
                          >
                            {" "}
                            اینجانب ضمن مطالعه کامل شرایط و قوانین فعالیت
                            تأمین‌کنندگان در پلتفرم بانک کالا، تمامی مفاد آن را
                            پذیرفته و متعهد به رعایت آن هستم.{" "}
                          </label>{" "}
                        </div>{" "}
                        {supplierErrors.termsAccepted && (
                          <p className="text-[10px] text-danger font-semibold">
                            {supplierErrors.termsAccepted}
                          </p>
                        )}
                        <div className="flex gap-3 justify-between items-center mt-6">
                          {" "}
                          <button
                            type="button"
                            onClick={() => setSupplierStep(3)}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                          >
                            {" "}
                            مرحله قبل{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={() => handleSupplierStepChange(5)}
                            className="flex-1 bg-primary-default hover:bg-primary-hover dark:hover:bg-primary-hover text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                            disabled={!supplierData.termsAccepted}
                          >
                            {" "}
                            ادامه به مرحله نهایی ساخت اکانت{" "}
                            <ArrowLeft className="w-4 h-4" />{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={saveSupplierDraft}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                          >
                            {" "}
                            <Database className="w-4 h-4" /> ذخیره پیش‌نویس{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                    {/* STEP 5: Account Credentials Creation */}
                    {supplierStep === 5 && (
                      <div className="space-y-4 animate-fade-in text-right">
                        {" "}
                        {/* Print Option */}
                        <div className="p-4 bg-primary-default/10/50 border border-primary-default/30 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4 text-right">
                          {" "}
                          <div className="space-y-1">
                            {" "}
                            <h4 className="font-bold text-primary text-xs">
                              دریافت نسخه پیش‌نویس ثبت‌نام
                            </h4>{" "}
                            <p className="text-[10px] text-muted">
                              اطلاعات وارد شده خود را برای بایگانی چاپ کنید یا
                              به صورت PDF ذخیره نمایید.
                            </p>{" "}
                          </div>{" "}
                          <button
                            type="button"
                            onClick={() => window.print()}
                            className="px-4 py-2.5 bg-warning hover:bg-warning text-inverse text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:shadow-md"
                          >
                            {" "}
                            <FileText className="w-4 h-4" /> چاپ و نسخه PDF{" "}
                          </button>{" "}
                        </div>{" "}
                        {registerError && (
                          <div className="p-4 bg-danger/10 border border-rose-200 rounded-xl flex flex-col gap-1">
                            {" "}
                            <div className="flex items-center gap-2 text-danger font-bold text-sm">
                              {" "}
                              <AlertCircle className="w-4 h-4" /> خطا در
                              ثبت‌نام{" "}
                            </div>{" "}
                            <div className="text-xs text-danger leading-relaxed">
                              {" "}
                              {registerError}
                            </div>{" "}
                          </div>
                        )}
                        <div>
                          {" "}
                          <label className="block text-xs font-black text-secondary mb-1.5">
                            نام کاربری اختصاصی (Username) *
                          </label>{" "}
                          <input
                            type="text"
                            required
                            value={supplierData.username}
                            onChange={(e) =>
                              setSupplierData({
                                ...supplierData,
                                username: e.target.value,
                              })
                            }
                            placeholder="مثال: parsa_trading"
                            className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:ring-primary-default"
                            style={{
                              direction: "ltr",
                            }}
                          />{" "}
                          {supplierErrors.username && (
                            <p className="text-[10px] text-danger mt-1 font-semibold">
                              {supplierErrors.username}
                            </p>
                          )}
                          <p className="text-[10px] text-muted mt-1">
                            نام کاربری باید یکتا و به صورت حروف انگلیسی، اعداد
                            یا کاراکتر زیرخط (_) باشد.
                          </p>{" "}
                        </div>{" "}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              کلمه عبور (Password) *
                            </label>{" "}
                            <input
                              type="password"
                              required
                              value={supplierData.password}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  password: e.target.value,
                                })
                              }
                              placeholder="کلمه عبور مطمئن"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              تکرار کلمه عبور *
                            </label>{" "}
                            <input
                              type="password"
                              required
                              value={supplierData.confirmPassword}
                              onChange={(e) =>
                                setSupplierData({
                                  ...supplierData,
                                  confirmPassword: e.target.value,
                                })
                              }
                              placeholder="مجدداً کلمه عبور را وارد کنید"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-primary-default"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                          </div>{" "}
                        </div>{" "}
                        {supplierErrors.password && (
                          <p className="text-[10px] text-danger font-semibold">
                            {supplierErrors.password}
                          </p>
                        )}
                        {supplierErrors.confirmPassword && (
                          <p className="text-[10px] text-danger font-semibold">
                            {supplierErrors.confirmPassword}
                          </p>
                        )}
                        {/* Password Strength Meter */}
                        {supplierData.password && (
                          <div className="space-y-2 mt-2 bg-background p-3.5 rounded-xl border animate-fade-in">
                            {" "}
                            <div className="flex justify-between items-center text-xs">
                              {" "}
                              <span className="text-muted">
                                قدرت رمز عبور:
                              </span>{" "}
                              <span
                                className={`font-bold ${getPasswordStrength(supplierData.password).score <= 1 ? "text-danger" : getPasswordStrength(supplierData.password).score === 2 ? "text-warning" : "text-success"}`}
                              >
                                {" "}
                                {
                                  getPasswordStrength(supplierData.password)
                                    .label
                                }
                              </span>{" "}
                            </div>{" "}
                            {/* Progress Bar */}
                            <div className="h-1.5 w-full bg-surface rounded-full overflow-hidden flex flex-row-reverse">
                              {" "}
                              <div
                                className={`h-full rounded-full transition-all duration-300 ${getPasswordStrength(supplierData.password).color} ${getPasswordStrength(supplierData.password).width}`}
                              />{" "}
                            </div>{" "}
                            {/* Requirements Checklist */}
                            <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-1">
                              {" "}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                {" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasMinLength
                                      ? "text-success"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  {getPasswordStrength(supplierData.password)
                                    .hasMinLength
                                    ? "✓"
                                    : "•"}
                                </span>{" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasMinLength
                                      ? "text-secondary"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  حداقل ۸ کاراکتر{" "}
                                </span>{" "}
                              </div>{" "}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                {" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasUpperLower
                                      ? "text-success"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  {getPasswordStrength(supplierData.password)
                                    .hasUpperLower
                                    ? "✓"
                                    : "•"}
                                </span>{" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasUpperLower
                                      ? "text-secondary"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  حروف کوچک و بزرگ{" "}
                                </span>{" "}
                              </div>{" "}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                {" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasNumber
                                      ? "text-success"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  {getPasswordStrength(supplierData.password)
                                    .hasNumber
                                    ? "✓"
                                    : "•"}
                                </span>{" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasNumber
                                      ? "text-secondary"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  حداقل یک عدد{" "}
                                </span>{" "}
                              </div>{" "}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                {" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasSpecial
                                      ? "text-success"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  {getPasswordStrength(supplierData.password)
                                    .hasSpecial
                                    ? "✓"
                                    : "•"}
                                </span>{" "}
                                <span
                                  className={
                                    getPasswordStrength(supplierData.password)
                                      .hasSpecial
                                      ? "text-secondary"
                                      : "text-muted"
                                  }
                                >
                                  {" "}
                                  کاراکتر خاص (@$!%*?&){" "}
                                </span>{" "}
                              </div>{" "}
                            </div>{" "}
                          </div>
                        )}
                        <div className="flex gap-3 justify-between items-center mt-6">
                          {" "}
                          <button
                            type="button"
                            onClick={() => setSupplierStep(4)}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                          >
                            {" "}
                            مرحله قبل{" "}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={handleSupplierRegister}
                            disabled={loading}
                            className="flex-1 bg-primary-default hover:bg-primary-hover dark:hover:bg-primary-hover text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                          >
                            {" "}
                            {loading ? (
                              <span className="flex items-center gap-2">
                                {" "}
                                <RefreshCw className="w-4 h-4 animate-spin" />{" "}
                                در حال ایجاد حساب کاربری...{" "}
                              </span>
                            ) : (
                              "اتمام ثبت‌نام و ورود مستقیم"
                            )}
                          </button>{" "}
                          <button
                            type="button"
                            onClick={saveSupplierDraft}
                            className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                          >
                            {" "}
                            <Database className="w-4 h-4" /> ذخیره پیش‌نویس{" "}
                          </button>{" "}
                        </div>{" "}
                      </div>
                    )}
                  </div>{" "}
                </div>
              )}
              {/* REFERRER FORM */}
              {view === "referrer_form" && (
                <div
                  id="view-referrer-form"
                  className="space-y-6 animate-fade-in text-right"
                >
                  <div className="bg-card/95 backdrop-blur-xl p-6 md:p-10 rounded-[2rem] shadow-2xl border">
                    {/* Header & Back */}
                    <div className="flex items-center justify-between mb-6 pb-4 border-b border-subtle">
                      <button
                        onClick={() => setView("role_select")}
                        className="inline-flex items-center gap-1.5 text-xs text-muted hover:text-slate-850 font-bold transition-colors cursor-pointer"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        بازگشت به انتخاب نقش
                      </button>
                      <span className="text-xs font-semibold text-muted">
                        نقش: همکار معرف (Referrer)
                      </span>
                    </div>

                    <div className="mb-6">
                      <h2 className="text-2xl font-black text-primary">ثبت‌نام معرف سیستم</h2>
                      <p className="text-xs text-muted mt-1 leading-relaxed font-medium">
                        برای دریافت کد دعوت اختصاصی خود، لطفاً مشخصات زیر را تکمیل کنید.
                      </p>
                    </div>

                    <div className="space-y-5">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">نام <span className="text-danger">*</span></label>
                          <input
                            type="text"
                            required
                            value={refForm.firstName}
                            onChange={(e) => setRefForm({ ...refForm, firstName: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary"
                            placeholder="مثال: علی"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">نام خانوادگی <span className="text-danger">*</span></label>
                          <input
                            type="text"
                            required
                            value={refForm.lastName}
                            onChange={(e) => setRefForm({ ...refForm, lastName: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary"
                            placeholder="مثال: محمدی"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">شماره موبایل <span className="text-danger">*</span></label>
                          <input
                            type="text"
                            required
                            value={refForm.mobile}
                            onChange={(e) => setRefForm({ ...refForm, mobile: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary text-left font-mono"
                            placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">ایمیل (اختیاری)</label>
                          <input
                            type="email"
                            value={refForm.email}
                            onChange={(e) => setRefForm({ ...refForm, email: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary text-left font-mono"
                            placeholder="example@mail.com"
                          />
                        </div>
                      </div>

                      <div className="border-t border-border-default/50 pt-5 space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">نام کاربری <span className="text-danger">*</span></label>
                          <input
                            type="text"
                            required
                            value={refForm.username}
                            onChange={(e) => setRefForm({ ...refForm, username: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary text-left font-mono"
                            placeholder="username"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-text-secondary">رمز عبور <span className="text-danger">*</span></label>
                          <input
                            type="password"
                            required
                            value={refForm.password}
                            onChange={(e) => setRefForm({ ...refForm, password: e.target.value })}
                            className="w-full px-4 py-3 bg-background border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default border-gray-300 dark:border-indigo-500/50 text-text-primary text-left"
                            placeholder="••••••••"
                          />
                        </div>
                      </div>

                      <div className="flex gap-3 justify-between items-center mt-6">
                        <button
                          type="button"
                          onClick={() => setView("role_select")}
                          className="px-6 py-3 border hover:bg-surface text-secondary font-bold rounded-xl transition-all text-xs cursor-pointer"
                        >
                          انصراف
                        </button>
                        <button
                          type="button"
                          onClick={handleReferrerRegister}
                          disabled={loading}
                          className="flex-1 bg-primary-default hover:bg-primary-hover text-white font-black py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                        >
                          {loading ? (
                            <span className="flex items-center gap-2">
                              <RefreshCw className="w-4 h-4 animate-spin" />
                              در حال ثبت‌نام...
                            </span>
                          ) : (
                            "تکمیل ثبت‌نام و شروع همکاری"
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {/* 4. STORE MANAGER MULTI-STEP FORM */}
              {view === "store_manager_form" && (
                <div
                  id="view-store-form"
                  className="space-y-6 animate-fade-in text-right"
                >
                  {" "}
                  <div className="bg-card/95 backdrop-blur-xl p-6 md:p-10 rounded-[2rem] shadow-2xl border">
                    {" "}
                    {/* Header & Back */}
                    <div className="flex items-center justify-between mb-6 pb-4 border-b border-subtle">
                      {" "}
                      <button
                        onClick={() => {
                          if (storeStep > 1) {
                            setStoreStep(storeStep - 1);
                          } else {
                            setView("role_select");
                          }
                        }}
                        className="inline-flex items-center gap-1.5 text-xs text-muted hover:text-slate-850 font-bold transition-colors cursor-pointer"
                      >
                        {" "}
                        <ArrowRight className="w-3.5 h-3.5" />{" "}
                        {storeStep === 1 ? "بازگشت به انتخاب نقش" : "مرحله قبل"}
                      </button>{" "}
                      <div className="flex items-center gap-4">
                        {" "}
                        <span className="text-xs font-semibold text-muted">
                          نقش: مدیر فروشگاه (خرده‌فروش)
                        </span>{" "}

                      </div>{" "}
                    </div>{" "}
                    {/* Progress Indicators */}
                    <div className="space-y-2 mb-8">
                      {" "}
                      <div className="flex justify-between items-center text-xs">
                        {" "}
                        <span className="font-extrabold text-success">
                          مرحله {storeStep}
                          از ۴
                        </span>{" "}
                        <span className="text-muted font-medium">
                          {" "}
                          {storeStep === 1 && "مشخصات فردی مدیر"}
                          {storeStep === 2 && "اطلاعات فروشگاه"}
                          {storeStep === 3 && "اتصال فنی فروشگاه (آینده)"}
                          {storeStep === 4 && "اطلاعات ورود به اکانت"}
                        </span>{" "}
                      </div>{" "}
                      {/* Step bar */}
                      <div className="h-1.5 w-full bg-surface rounded-full overflow-hidden flex flex-row-reverse">
                        {" "}
                        <div
                          className="h-full bg-success rounded-full transition-all duration-300"
                          style={{
                            width: `${(storeStep / 4) * 100}%`,
                          }}
                        />{" "}
                      </div>{" "}
                    </div>{" "}
                    {/* Form Step Contents */}
                    <div className="space-y-4">
                      {" "}
                      {/* Store Manager Draft Restore Banner */}
                      {localStorage.getItem("storeDataDraft") && (
                        <div className="p-4 bg-success/10 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-3 animate-fade-in text-emerald-900 text-xs">
                          {" "}
                          <div className="flex items-center gap-2">
                            {" "}
                            <Info className="w-4 h-4 shrink-0 text-success" />{" "}
                            <span>
                              یک پیش‌نویس ذخیره‌شده از ثبت‌نام قبلی شما یافت شد.
                              آیا مایل به بازیابی اطلاعات قبلی هستید؟
                            </span>{" "}
                          </div>{" "}
                          <div className="flex gap-2 shrink-0">
                            {" "}
                            <button
                              type="button"
                              onClick={() => {
                                const savedData =
                                  localStorage.getItem("storeDataDraft");
                                const savedStep =
                                  localStorage.getItem("storeStepDraft");
                                if (savedData) {
                                  setStoreData(JSON.parse(savedData));
                                }
                                if (savedStep) {
                                  setStoreStep(parseInt(savedStep));
                                }
                                showNotification(
                                  "پیش‌نویس قبلی شما با موفقیت بازیابی شد.",
                                  "success",
                                );
                              }}
                              className="px-3 py-1.5 bg-success hover:bg-emerald-700 text-inverse font-bold rounded-lg transition-colors cursor-pointer"
                            >
                              {" "}
                              بازیابی پیش‌نویس{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={() => {
                                localStorage.removeItem("storeDataDraft");
                                localStorage.removeItem("storeStepDraft");
                                showNotification(
                                  "پیش‌نویس ذخیره‌شده حذف گردید.",
                                  "success",
                                );
                              }}
                              className="px-3 py-1.5 border hover:bg-surface text-secondary font-bold rounded-lg transition-colors cursor-pointer"
                            >
                              {" "}
                              حذف{" "}
                            </button>{" "}
                          </div>{" "}
                        </div>
                      )}
                      {/* STEP 1: Personal */}
                      {storeStep === 1 && (
                        <div className="space-y-4 animate-fade-in text-right">
                          {" "}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                نام مدیر فروشگاه *
                              </label>{" "}
                              <input
                                type="text"
                                required
                                value={storeData.firstName}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    firstName: e.target.value,
                                  })
                                }
                                placeholder="مثال: سهراب"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                              />{" "}
                              {storeErrors.firstName && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.firstName}
                                </p>
                              )}
                            </div>{" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                نام خانوادگی *
                              </label>{" "}
                              <input
                                type="text"
                                required
                                value={storeData.lastName}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    lastName: e.target.value,
                                  })
                                }
                                placeholder="مثال: سپهری"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                              />{" "}
                              {storeErrors.lastName && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.lastName}
                                </p>
                              )}
                            </div>{" "}
                          </div>{" "}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                شماره موبایل *
                              </label>{" "}
                              <input
                                type="tel"
                                required
                                value={storeData.mobile}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    mobile: e.target.value,
                                  })
                                }
                                placeholder="09121111111"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                              {storeErrors.mobile && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.mobile}
                                </p>
                              )}
                            </div>{" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                آدرس ایمیل *
                              </label>{" "}
                              <input
                                type="email"
                                required
                                value={storeData.email}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    email: e.target.value,
                                  })
                                }
                                placeholder="example@gmail.com"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                              {storeErrors.email && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.email}
                                </p>
                              )}
                            </div>{" "}
                          </div>{" "}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              آدرس دقیق فروشگاه (شامل استان، شهر، آدرس پستی و کد
                              پستی ۱۰ رقمی) *
                            </label>{" "}
                            <textarea
                              required
                              rows={2}
                              value={storeData.storeAddress}
                              onChange={(e) =>
                                setStoreData({
                                  ...storeData,
                                  storeAddress: e.target.value,
                                })
                              }
                              placeholder="مثال: تهران، تهران، خیابان آزادی، کوچه مریم، پلاک ۱۰، واحد ۳ - کد پستی: ۱۲۳۴۵۶۷۸۹۰"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all resize-none"
                            />{" "}
                            {storeErrors.storeAddress && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {storeErrors.storeAddress}
                              </p>
                            )}
                          </div>{" "}
                          <div className="flex gap-3 justify-between items-center mt-6">
                            {" "}
                            <button
                              type="button"
                              onClick={() => handleStoreStepChange(2)}
                              className="flex-1 bg-success hover:bg-emerald-700 text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                            >
                              {" "}
                              ادامه ثبت‌نام فروشگاه{" "}
                              <ArrowLeft className="w-4 h-4" />{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={saveStoreDraft}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                            >
                              {" "}
                              <Database className="w-4 h-4" /> ذخیره
                              پیش‌نویس{" "}
                            </button>{" "}
                          </div>{" "}
                        </div>
                      )}
                      {/* STEP 2: Store details */}
                      {storeStep === 2 && (
                        <div className="space-y-4 animate-fade-in text-right">
                          {" "}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                نام فروشگاه *
                              </label>{" "}
                              <input
                                type="text"
                                required
                                value={storeData.storeName}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    storeName: e.target.value,
                                  })
                                }
                                placeholder="نام تجاری فروشگاه آنلاین"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                              />{" "}
                              {storeErrors.storeName && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.storeName}
                                </p>
                              )}
                            </div>{" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                آدرس اینترنتی وب‌سایت فروشگاه
                              </label>{" "}
                              <input
                                type="url"
                                value={storeData.storeUrl}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    storeUrl: e.target.value,
                                  })
                                }
                                placeholder="https://mystore.ir"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                            </div>{" "}
                          </div>{" "}
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {" "}
                            <div className="col-span-1">
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                پلتفرم مدیریت فروشگاه *
                              </label>{" "}
                              <select
                                value={storeData.platformType}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    platformType: e.target.value,
                                  })
                                }
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success"
                              >
                                {" "}
                                <option value="WOOCOMMERCE">
                                  ووکامرس (WooCommerce)
                                </option>{" "}
                                <option value="SHOPIFY">
                                  شاپیفای (Shopify)
                                </option>{" "}
                                <option value="OTHER">
                                  سایر سیستم‌ها
                                </option>{" "}
                              </select>{" "}
                            </div>{" "}
                            <div className="col-span-1">
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                حوزه فعالیت اصلی *
                              </label>{" "}
                              <input
                                type="text"
                                required
                                value={storeData.fieldOfActivity}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    fieldOfActivity: e.target.value,
                                  })
                                }
                                placeholder="مثال: آرایشی، پوشاک، دیجیتال"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                              />{" "}
                              {storeErrors.fieldOfActivity && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.fieldOfActivity}
                                </p>
                              )}
                            </div>{" "}
                            <div className="col-span-1">
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                تعداد محصولات فعلی *
                              </label>{" "}
                              <input
                                type="number"
                                required
                                value={storeData.productCount}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    productCount: e.target.value,
                                  })
                                }
                                placeholder="عدد وارد کنید"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-success dark:focus:ring-success focus:bg-card dark:focus:bg-surface/50 transition-all"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                              {storeErrors.productCount && (
                                <p className="text-[10px] text-danger mt-1 font-semibold">
                                  {storeErrors.productCount}
                                </p>
                              )}
                            </div>{" "}
                          </div>{" "}
                          <div className="flex gap-3 justify-between items-center mt-6">
                            {" "}
                            <button
                              type="button"
                              onClick={() => setStoreStep(1)}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                            >
                              {" "}
                              مرحله قبل{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={() => handleStoreStepChange(3)}
                              className="flex-1 bg-success hover:bg-emerald-700 text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                            >
                              {" "}
                              ادامه ثبت‌نام فروشگاه{" "}
                              <ArrowLeft className="w-4 h-4" />{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={saveStoreDraft}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                            >
                              {" "}
                              <Database className="w-4 h-4" /> ذخیره
                              پیش‌نویس{" "}
                            </button>{" "}
                          </div>{" "}
                        </div>
                      )}
                      {/* STEP 3: Connect Account (Integration) */}
                      {storeStep === 3 && (
                        <div className="space-y-4 animate-fade-in text-right">
                          {" "}
                          <div className="p-6 border border-dashed border-default rounded-3xl bg-background flex flex-col items-center text-center space-y-4">
                            {" "}
                            <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center text-success animate-pulse">
                              {" "}
                              <Database className="w-8 h-8" />{" "}
                            </div>{" "}
                            <div className="space-y-1">
                              {" "}
                              <h4 className="font-bold text-primary text-sm">
                                اتصال هوشمند فنی به بازارگاه (به زودی)
                              </h4>{" "}
                              <p className="text-xs text-muted max-w-md leading-relaxed font-light">
                                {" "}
                                در آینده نزدیک، شما قادر خواهید بود با وارد کردن
                                کلیدهای API فروشگاه (WooCommerce Consumer Key یا
                                Shopify Access Token)، فرآیند همگام‌سازی
                                اتوماتیک قیمت‌ها، موجودی انبار و سفارشات را فعال
                                کنید.{" "}
                              </p>{" "}
                            </div>{" "}
                            <div className="flex gap-4 items-center">
                              {" "}
                              <span className="text-xs text-success bg-card border px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-semibold">
                                {" "}
                                <span className="w-2 h-2 rounded-full bg-success animate-ping"></span>{" "}
                                آماده‌سازی فنی در جریان{" "}
                              </span>{" "}
                            </div>{" "}
                          </div>{" "}
                          <div className="flex gap-3 justify-between items-center mt-6">
                            {" "}
                            <button
                              type="button"
                              onClick={() => setStoreStep(2)}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                            >
                              {" "}
                              مرحله قبل{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={() => setStoreStep(4)}
                              className="flex-1 bg-success hover:bg-emerald-700 text-inverse font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                            >
                              {" "}
                              عبور از این مرحله و ساخت اکانت{" "}
                              <ArrowLeft className="w-4 h-4" />{" "}
                            </button>{" "}
                          </div>{" "}
                        </div>
                      )}
                      {/* STEP 4: Account Credentials */}
                      {storeStep === 4 && (
                        <div className="space-y-4 animate-fade-in text-right">
                          {" "}
                          {/* Print Option */}
                          <div className="p-4 bg-success/10/50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4 text-right">
                            {" "}
                            <div className="space-y-1">
                              {" "}
                              <h4 className="font-bold text-primary text-xs">
                                دریافت نسخه پیش‌نویس ثبت‌نام
                              </h4>{" "}
                              <p className="text-[10px] text-muted">
                                اطلاعات فروشگاه خود را برای بایگانی چاپ کنید یا
                                به صورت PDF ذخیره نمایید.
                              </p>{" "}
                            </div>{" "}
                            <button
                              type="button"
                              onClick={() => window.print()}
                              className="px-4 py-2.5 bg-warning hover:bg-warning text-inverse text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:shadow-md"
                            >
                              {" "}
                              <FileText className="w-4 h-4" /> چاپ و نسخه
                              PDF{" "}
                            </button>{" "}
                          </div>{" "}
                          {registerError && (
                            <div className="p-4 bg-danger/10 border border-rose-200 rounded-xl flex flex-col gap-1">
                              {" "}
                              <div className="flex items-center gap-2 text-danger font-bold text-sm">
                                {" "}
                                <AlertCircle className="w-4 h-4" /> خطا در
                                ثبت‌نام{" "}
                              </div>{" "}
                              <div className="text-xs text-danger leading-relaxed">
                                {" "}
                                {registerError}
                              </div>{" "}
                            </div>
                          )}
                          <div>
                            {" "}
                            <label className="block text-xs font-black text-secondary mb-1.5">
                              نام کاربری اختصاصی (Username) *
                            </label>{" "}
                            <input
                              type="text"
                              required
                              value={storeData.username}
                              onChange={(e) =>
                                setStoreData({
                                  ...storeData,
                                  username: e.target.value,
                                })
                              }
                              placeholder="مثال: store_manager_sam"
                              className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left font-mono focus:outline-none focus:ring-2 focus:ring-success"
                              style={{
                                direction: "ltr",
                              }}
                            />{" "}
                            {storeErrors.username && (
                              <p className="text-[10px] text-danger mt-1 font-semibold">
                                {storeErrors.username}
                              </p>
                            )}
                          </div>{" "}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                کلمه عبور *
                              </label>{" "}
                              <input
                                type="password"
                                required
                                value={storeData.password}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    password: e.target.value,
                                  })
                                }
                                placeholder="رمز عبور مطمئن"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-success"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                            </div>{" "}
                            <div>
                              {" "}
                              <label className="block text-xs font-black text-secondary mb-1.5">
                                تکرار کلمه عبور *
                              </label>{" "}
                              <input
                                type="password"
                                required
                                value={storeData.confirmPassword}
                                onChange={(e) =>
                                  setStoreData({
                                    ...storeData,
                                    confirmPassword: e.target.value,
                                  })
                                }
                                placeholder="تکرار رمز عبور"
                                className="w-full px-4 py-2.5 bg-background border rounded-xl text-sm text-primary text-left focus:outline-none focus:ring-2 focus:ring-success"
                                style={{
                                  direction: "ltr",
                                }}
                              />{" "}
                            </div>{" "}
                          </div>{" "}
                          {storeErrors.password && (
                            <p className="text-[10px] text-danger font-semibold">
                              {storeErrors.password}
                            </p>
                          )}
                          {storeErrors.confirmPassword && (
                            <p className="text-[10px] text-danger font-semibold">
                              {storeErrors.confirmPassword}
                            </p>
                          )}
                          {/* Password Strength Meter */}
                          {storeData.password && (
                            <div className="space-y-2 mt-2 bg-background p-3.5 rounded-xl border animate-fade-in">
                              {" "}
                              <div className="flex justify-between items-center text-xs">
                                {" "}
                                <span className="text-muted">
                                  قدرت رمز عبور:
                                </span>{" "}
                                <span
                                  className={`font-bold ${getPasswordStrength(storeData.password).score <= 1 ? "text-danger" : getPasswordStrength(storeData.password).score === 2 ? "text-warning" : "text-success"}`}
                                >
                                  {" "}
                                  {
                                    getPasswordStrength(storeData.password)
                                      .label
                                  }
                                </span>{" "}
                              </div>{" "}
                              {/* Progress Bar */}
                              <div className="h-1.5 w-full bg-surface rounded-full overflow-hidden flex flex-row-reverse">
                                {" "}
                                <div
                                  className={`h-full rounded-full transition-all duration-300 ${getPasswordStrength(storeData.password).color} ${getPasswordStrength(storeData.password).width}`}
                                />{" "}
                              </div>{" "}
                              {/* Requirements Checklist */}
                              <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-1">
                                {" "}
                                <div className="flex items-center gap-1.5 text-[10px]">
                                  {" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasMinLength
                                        ? "text-success"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    {getPasswordStrength(storeData.password)
                                      .hasMinLength
                                      ? "✓"
                                      : "•"}
                                  </span>{" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasMinLength
                                        ? "text-secondary"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    حداقل ۸ کاراکتر{" "}
                                  </span>{" "}
                                </div>{" "}
                                <div className="flex items-center gap-1.5 text-[10px]">
                                  {" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasUpperLower
                                        ? "text-success"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    {getPasswordStrength(storeData.password)
                                      .hasUpperLower
                                      ? "✓"
                                      : "•"}
                                  </span>{" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasUpperLower
                                        ? "text-secondary"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    حروف کوچک و بزرگ{" "}
                                  </span>{" "}
                                </div>{" "}
                                <div className="flex items-center gap-1.5 text-[10px]">
                                  {" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasNumber
                                        ? "text-success"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    {getPasswordStrength(storeData.password)
                                      .hasNumber
                                      ? "✓"
                                      : "•"}
                                  </span>{" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasNumber
                                        ? "text-secondary"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    حداقل یک عدد{" "}
                                  </span>{" "}
                                </div>{" "}
                                <div className="flex items-center gap-1.5 text-[10px]">
                                  {" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasSpecial
                                        ? "text-success"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    {getPasswordStrength(storeData.password)
                                      .hasSpecial
                                      ? "✓"
                                      : "•"}
                                  </span>{" "}
                                  <span
                                    className={
                                      getPasswordStrength(storeData.password)
                                        .hasSpecial
                                        ? "text-secondary"
                                        : "text-muted"
                                    }
                                  >
                                    {" "}
                                    کاراکتر خاص (@$!%*?&){" "}
                                  </span>{" "}
                                </div>{" "}
                              </div>{" "}
                            </div>
                          )}
                          <div className="flex gap-3 justify-between items-center mt-6">
                            {" "}
                            <button
                              type="button"
                              onClick={() => setStoreStep(3)}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all text-xs cursor-pointer font-bold"
                            >
                              {" "}
                              مرحله قبل{" "}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={handleStoreManagerRegister}
                              disabled={loading}
                              className="flex-1 bg-success hover:bg-emerald-700 text-inverse font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm shadow-md cursor-pointer"
                            >
                              {" "}
                              {loading ? (
                                <span className="flex items-center gap-2">
                                  {" "}
                                  <RefreshCw className="w-4 h-4 animate-spin" />{" "}
                                  در حال ایجاد حساب کاربری...{" "}
                                </span>
                              ) : (
                                "اتمام ثبت‌نام و ورود مستقیم"
                              )}
                            </button>{" "}
                            <button
                              type="button"
                              onClick={saveStoreDraft}
                              className="px-4 py-3 border hover:bg-surface text-secondary font-medium rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs cursor-pointer"
                            >
                              {" "}
                              <Database className="w-4 h-4" /> ذخیره
                              پیش‌نویس{" "}
                            </button>{" "}
                          </div>{" "}
                        </div>
                      )}
                    </div>{" "}
                  </div>{" "}
                </div>
              )}
              <div className="mt-8 text-center text-sm text-muted bg-background p-4 rounded-2xl border border-subtle">
                {" "}
                نیاز به راهنمایی دارید؟ برای هرگونه سوال یا مشکل با{" "}
                <a
                  href="tel:09180088358"
                  className="text-primary-default font-bold font-mono px-1"
                  dir="ltr"
                >
                  0918 008 8358
                </a>{" "}
                تماس بگیرید.{" "}
              </div>{" "}
            </div>{" "}
          </main>
        )}
        {/* Footer */}
        <footer className="text-center py-4 text-xs text-muted bg-background border-t border-subtle">
          {" "}
          سامانه بازارگاه تامین و توزیع • طراحی RTL و بهینه‌سازی واکنش‌گرا
          (Mobile-First) • کلیه حقوق امنیتی محفوظ است.{" "}
        </footer>{" "}
        {/* RULES AND TERMS MODAL */}
        {showTermsModal && (
          <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            {" "}
            <div className="bg-card rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-scale-in max-h-[85vh] flex flex-col">
              {" "}
              <div className="p-6 bg-background text-inverse flex justify-between items-center">
                {" "}
                <h3 className="font-bold text-lg">
                  شرایط و قوانین فعالیت تأمین‌کنندگان در پلتفرم بانک کالا
                </h3>{" "}
                <button
                  onClick={() => setShowTermsModal(false)}
                  className="w-8 h-8 rounded-full bg-card/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  {" "}
                  ✕{" "}
                </button>{" "}
              </div>{" "}
              <div className="p-6 overflow-y-auto space-y-6 text-sm text-secondary leading-relaxed font-light text-right">
                {" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    مقدمه
                  </h4>{" "}
                  <p>
                    {" "}
                    عضویت در پلتفرم <strong>بانک کالا</strong> و ثبت هرگونه کالا
                    در سامانه، به منزله مطالعه دقیق، آگاهی کامل و پذیرش تمامی
                    شرایط و قوانین زیر است. تأیید این شرایط از طریق انتخاب گزینه
                    «می‌پذیرم» در زمان ثبت‌نام، به منزله موافقت تأمین‌کننده با
                    مفاد این قوانین خواهد بود. بانک کالا یک بستر هوشمند برای
                    ایجاد ارتباط میان تأمین‌کنندگان و شبکه فروشگاه‌های همکار است
                    و نقش آن تسهیل فرآیند عرضه، فروش، مدیریت سفارش و تسویه‌حساب
                    می‌باشد.{" "}
                  </p>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۱. نحوه فعالیت و قیمت‌گذاری
                  </h4>{" "}
                  <ul className="list-disc pr-5 space-y-1">
                    {" "}
                    <li>
                      تأمین‌کننده موظف است مشخصات کامل، موجودی و{" "}
                      <strong>قیمت پایه موردنظر</strong> خود را برای هر کالا در
                      سامانه ثبت نماید.
                    </li>{" "}
                    <li>
                      بانک کالا کالاهای ثبت‌شده را با احتساب حاشیه سود مربوط به
                      هزینه‌های زیرساخت، خدمات سامانه و شبکه فروشگاه‌های همکار
                      در کانال‌های فروش عرضه می‌کند.
                    </li>{" "}
                    <li>
                      مبلغ قابل پرداخت به تأمین‌کننده همان{" "}
                      <strong>قیمت پایه ثبت‌شده توسط وی</strong> خواهد بود و پس
                      از نهایی شدن فروش، پایان مهلت بررسی سفارش و کسر سهم
                      پلتفرم، مطابق برنامه مالی سامانه به کیف پول یا حساب بانکی
                      معرفی‌شده واریز می‌شود.
                    </li>{" "}
                    <li>
                      تأمین‌کننده مسئول به‌روزرسانی قیمت پایه و موجودی کالاهای
                      خود است.
                    </li>{" "}
                  </ul>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۲. مدیریت سفارش و ارسال کالا
                  </h4>{" "}
                  <ul className="list-disc pr-5 space-y-1">
                    {" "}
                    <li>
                      پس از ثبت سفارش، تأمین‌کننده متعهد است حداکثر ظرف{" "}
                      <strong>۲۴ ساعت کاری</strong> وضعیت سفارش را بررسی، تأیید
                      و کالا را برای ارسال آماده نماید.
                    </li>{" "}
                    <li>
                      ارسال کالا ترجیحاً از طریق سرویس‌های حمل‌ونقل متصل به بانک
                      کالا انجام می‌شود.
                    </li>{" "}
                    <li>
                      در صورتی که ارسال توسط تأمین‌کننده انجام شود، ثبت کد
                      رهگیری معتبر در سامانه الزامی است.
                    </li>{" "}
                    <li>
                      تأخیرهای مکرر در تأیید سفارش، ارسال کالا یا لغو سفارش بدون
                      دلیل موجه، ممکن است منجر به محدود شدن یا تعلیق دسترسی
                      تأمین‌کننده به خدمات سامانه شود.
                    </li>{" "}
                  </ul>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۳. کیفیت کالا و رسیدگی به سفارش
                  </h4>{" "}
                  <ul className="list-disc pr-5 space-y-1">
                    {" "}
                    <li>
                      تأمین‌کننده اصالت، سلامت فیزیکی، کیفیت و مطابقت کامل کالای
                      ارسالی با اطلاعات ثبت‌شده در سامانه را تضمین می‌کند.
                    </li>{" "}
                    <li>
                      مشتری نهایی تا <strong>۴۸ ساعت پس از تحویل کالا</strong>{" "}
                      فرصت دارد مغایرت، نقص یا آسیب‌دیدگی کالا را گزارش نماید.
                    </li>{" "}
                    <li>
                      در صورت تأیید ایراد، تأمین‌کننده متعهد به همکاری در فرآیند
                      تعویض، مرجوعی یا جبران خسارت مطابق سیاست‌های بانک کالا
                      خواهد بود.
                    </li>{" "}
                    <li>
                      تا پایان مهلت بررسی سفارش و تعیین تکلیف احتمالی مرجوعی،
                      تسویه‌حساب آن سفارش ممکن است به تعویق بیفتد.
                    </li>{" "}
                  </ul>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۴. مسئولیت‌ها
                  </h4>{" "}
                  <ul className="list-disc pr-5 space-y-1">
                    {" "}
                    <li>
                      بانک کالا صرفاً ارائه‌دهنده بستر نرم‌افزاری، مدیریت شبکه
                      فروش، تسهیل فرآیند سفارش و امور مالی میان طرفین است.
                    </li>{" "}
                    <li>
                      مسئولیت قانونی کیفیت، اصالت، موجودی، مجوزهای لازم، اطلاعات
                      درج‌شده و قابلیت فروش کالا بر عهده تأمین‌کننده است.
                    </li>{" "}
                    <li>
                      ثبت کالاهای غیرقانونی، قاچاق، تقلبی، ناقض حقوق مالکیت فکری
                      یا مغایر با قوانین جمهوری اسلامی ایران ممنوع بوده و
                      مسئولیت کامل آن بر عهده تأمین‌کننده خواهد بود.
                    </li>{" "}
                    <li>
                      در صورت وارد شدن هرگونه خسارت به مشتری، فروشگاه همکار یا
                      بانک کالا ناشی از اطلاعات نادرست، کیفیت نامناسب یا عدم
                      انجام تعهدات، مسئولیت جبران خسارت بر عهده تأمین‌کننده
                      خواهد بود.
                    </li>{" "}
                    <li>
                      تأمین‌کننده موظف است در صورت اتمام موجودی، وضعیت کالا را
                      بلافاصله در سامانه به‌روزرسانی نماید.
                    </li>{" "}
                  </ul>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۵. محرمانگی اطلاعات
                  </h4>{" "}
                  <p>
                    تأمین‌کننده متعهد است اطلاعات مربوط به سفارش‌ها، مشتریان،
                    فروشگاه‌های همکار، قیمت‌ها، گزارش‌ها و سایر اطلاعات تجاری
                    بانک کالا را محرمانه تلقی کرده و از استفاده از این اطلاعات
                    برای ارتباط مستقیم با مشتریان یا فروشگاه‌های همکار خارج از
                    بستر بانک کالا خودداری نماید.
                  </p>{" "}
                </div>{" "}
                <div>
                  {" "}
                  <h4 className="font-bold text-primary text-sm mb-2">
                    ۶. اصلاح قوانین
                  </h4>{" "}
                  <p>
                    بانک کالا در صورت نیاز، حق اصلاح یا به‌روزرسانی این شرایط و
                    قوانین را مطابق تغییرات خدمات یا الزامات قانونی برای خود
                    محفوظ می‌داند. ادامه استفاده از سامانه پس از اعمال تغییرات،
                    به منزله پذیرش نسخه جدید قوانین خواهد بود.
                  </p>{" "}
                </div>{" "}
              </div>{" "}
              <div className="p-6 border-t border-subtle bg-background flex justify-end">
                {" "}
                <button
                  onClick={() => {
                    setSupplierData({
                      ...supplierData,
                      termsAccepted: true,
                      agreementVersion: "1.0",
                      agreementAcceptedAt: new Date().toISOString(),
                    });
                    setShowTermsModal(false);
                    showNotification(
                      "قوانین با موفقیت تایید و امضا شد.",
                      "success",
                    );
                  }}
                  className="bg-background text-inverse font-bold px-6 py-2.5 rounded-xl hover:bg-surface transition-all text-sm"
                >
                  {" "}
                  مطالعه کردم و قوانین را می‌پذیرم{" "}
                </button>{" "}
              </div>{" "}
            </div>{" "}
          </div>
        )}
      </div>{" "}
      {/* Print-only registration copy */}
      <div
        className="hidden print:block p-10 bg-card text-primary font-sans min-h-screen text-right"
        style={{
          direction: "rtl",
        }}
      >
        {" "}
        <div className="border-4 border-subtle p-8 rounded-3xl space-y-8 max-w-4xl mx-auto">
          {" "}
          {/* Logo & Header */}
          <div className="flex justify-between items-center border-b-2 border-subtle pb-6">
            {" "}
            <div>
              {" "}
              <h1 className="text-3xl font-black text-primary">
                بانک کالا
              </h1>{" "}
              <p className="text-sm text-muted font-semibold mt-1">
                پلتفرم هوشمند مدیریت زنجیره تامین کالا (B2B)
              </p>{" "}
            </div>{" "}
            <div
              className="text-left"
              style={{
                direction: "ltr",
              }}
            >
              {" "}
              <p className="text-sm font-bold text-primary">
                تاریخ چاپ:{" "}
                <span className="font-mono">
                  {new Date().toLocaleDateString("fa-IR")}
                </span>
              </p>{" "}
              <p className="text-xs text-muted mt-1">
                پیش‌نویس ثبت‌نام رسمی
              </p>{" "}
            </div>{" "}
          </div>{" "}
          <div className="text-center">
            {" "}
            <h2 className="text-2xl font-extrabold text-primary bg-surface py-2 rounded-xl">
              {" "}
              فرم پیش‌نویس مشخصات و اطلاعات ثبت‌نام{" "}
              {view === "supplier_form"
                ? "تامین‌کننده / عمده‌فروش"
                : "مدیر فروشگاه (خرده‌فروش)"}
            </h2>{" "}
          </div>{" "}
          {view === "supplier_form" && (
            <div className="space-y-6">
              {" "}
              {/* Personal Info */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-primary-hover border-r-4 border-primary-default pr-2 mb-3 text-right">
                  ۱. مشخصات فردی
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام و نام خانوادگی:</strong>{" "}
                    {supplierData.firstName}
                    {supplierData.lastName}
                  </div>{" "}
                  <div>
                    <strong>کد ملی:</strong>{" "}
                    <span className="font-mono">
                      {supplierData.nationalCode}
                    </span>
                  </div>{" "}
                  <div>
                    <strong>شماره موبایل:</strong>{" "}
                    <span className="font-mono">{supplierData.mobile}</span>
                  </div>{" "}
                  <div>
                    <strong>ایمیل:</strong>{" "}
                    <span className="font-mono">
                      {supplierData.email || "ثبت نشده"}
                    </span>
                  </div>{" "}
                </div>{" "}
              </div>{" "}
              {/* Business Info */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-primary-hover border-r-4 border-primary-default pr-2 mb-3 text-right">
                  ۲. اطلاعات کسب‌وکار
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام تجاری / برند:</strong> {supplierData.brandName}
                  </div>{" "}
                  <div>
                    <strong>نوع فعالیت:</strong>{" "}
                    {supplierData.activityType === "PRODUCER"
                      ? "تولیدکننده"
                      : supplierData.activityType === "WHOLESALER"
                        ? "عمده‌فروش / بنکدار"
                        : supplierData.activityType === "IMPORTER"
                          ? "واردکننده مستقیم"
                          : "سایر"}
                  </div>{" "}
                  <div>
                    <strong>استان و شهر:</strong> {supplierData.province}-{" "}
                    {supplierData.city}
                  </div>{" "}
                  <div>
                    <strong>کد پستی:</strong>{" "}
                    <span className="font-mono">{supplierData.postalCode}</span>
                  </div>{" "}
                  <div>
                    <strong>تلفن تماس ثابت:</strong>{" "}
                    <span className="font-mono">{supplierData.telephone}</span>
                  </div>{" "}
                  <div>
                    <strong>وب‌سایت / کانال فروش:</strong>{" "}
                    <span className="font-mono">
                      {supplierData.website || "ثبت نشده"}
                    </span>
                  </div>{" "}
                  <div className="col-span-2">
                    <strong>نشانی دقیق:</strong> {supplierData.address}
                  </div>{" "}
                </div>{" "}
              </div>{" "}
              {/* Financial Info */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-primary-hover border-r-4 border-primary-default pr-2 mb-3 text-right">
                  ۳. اطلاعات مالی و تسویه حساب
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام صاحب حساب:</strong>{" "}
                    {supplierData.accountHolderName}
                  </div>{" "}
                  <div>
                    <strong>نام بانک صادرکننده:</strong> {supplierData.bankName}
                  </div>{" "}
                  <div className="col-span-2">
                    <strong>شماره شبا (IBAN):</strong>{" "}
                    <span className="font-mono">{supplierData.shaba}</span>
                  </div>{" "}
                </div>{" "}
              </div>{" "}
              {/* Credentials Summary */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-primary-hover border-r-4 border-primary-default pr-2 mb-3 text-right">
                  ۴. اطلاعات حساب کاربری
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام کاربری انتخابی:</strong>{" "}
                    <span className="font-mono font-bold text-primary-default">
                      {supplierData.username}
                    </span>
                  </div>{" "}
                  <div>
                    <strong>وضعیت قوانین:</strong> تایید شده و امضا شده
                    الکترونیکی
                  </div>{" "}
                </div>{" "}
              </div>{" "}
            </div>
          )}
          {view === "store_manager_form" && (
            <div className="space-y-6">
              {" "}
              {/* Personal Info */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-emerald-900 border-r-4 border-success pr-2 mb-3 text-right">
                  ۱. مشخصات فردی مدیر
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام و نام خانوادگی:</strong> {storeData.firstName}
                    {storeData.lastName}
                  </div>{" "}
                  <div>
                    <strong>شماره موبایل:</strong>{" "}
                    <span className="font-mono">{storeData.mobile}</span>
                  </div>{" "}
                  <div className="col-span-2">
                    <strong>ایمیل:</strong>{" "}
                    <span className="font-mono">{storeData.email}</span>
                  </div>{" "}
                  <div className="col-span-2">
                    <strong>آدرس دقیق:</strong> {storeData.storeAddress}
                  </div>{" "}
                </div>{" "}
              </div>{" "}
              {/* Store Details */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-emerald-900 border-r-4 border-success pr-2 mb-3 text-right">
                  ۲. اطلاعات فروشگاه
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام فروشگاه:</strong> {storeData.storeName}
                  </div>{" "}
                  <div>
                    <strong>آدرس اینترنتی وب‌سایت:</strong>{" "}
                    <span className="font-mono">
                      {storeData.storeUrl || "ثبت نشده"}
                    </span>
                  </div>{" "}
                  <div>
                    <strong>پلتفرم مدیریت فروشگاه:</strong>{" "}
                    {storeData.platformType === "WOOCOMMERCE"
                      ? "ووکامرس"
                      : storeData.platformType === "SHOPIFY"
                        ? "شاپیفای"
                        : "سایر"}
                  </div>{" "}
                  <div>
                    <strong>حوزه فعالیت اصلی:</strong>{" "}
                    {storeData.fieldOfActivity}
                  </div>{" "}
                  <div>
                    <strong>تعداد محصولات فعلی:</strong>{" "}
                    <span className="font-mono">{storeData.productCount}</span>{" "}
                    کالا
                  </div>{" "}
                </div>{" "}
              </div>{" "}
              {/* Credentials Summary */}
              <div>
                {" "}
                <h3 className="text-lg font-black text-emerald-900 border-r-4 border-success pr-2 mb-3 text-right">
                  ۳. اطلاعات حساب کاربری
                </h3>{" "}
                <div className="grid grid-cols-2 gap-4 text-sm bg-background p-4 rounded-xl text-right">
                  {" "}
                  <div>
                    <strong>نام کاربری انتخابی:</strong>{" "}
                    <span className="font-mono font-bold text-success">
                      {storeData.username}
                    </span>
                  </div>{" "}
                  <div>
                    <strong>وضعیت حساب:</strong> آماده برای فعال‌سازی نهایی
                  </div>{" "}
                </div>{" "}
              </div>{" "}
            </div>
          )}
          {/* Footer Security Stamp */}
          <div className="pt-8 border-t-2 border-subtle flex justify-between items-center text-xs text-muted text-right">
            {" "}
            <p>
              این سند جنبه رسمی در فرآیند ثبت‌نام اولیه سامانه بانک کالا دارد.
              محفوظ بودن اطلاعات شما بر اساس منشور محرمانگی بانک کالا تضمین
              می‌شود.
            </p>{" "}
            <div className="text-left font-mono">
              {" "}
              <span className="border border-subtle px-3 py-1 font-bold rounded-lg text-primary">
                B2B-VERIFIED
              </span>{" "}
            </div>{" "}
          </div>{" "}
        </div>{" "}
      </div>{" "}

      <ThemeToggleFloating />
    </>
  );
}
