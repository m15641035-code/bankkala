import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const auth = {
  authenticateToken: (req: any, res: Response, next: NextFunction) => {
    const authHeader = req.headers["authorization"];
    const headerToken = authHeader && authHeader.split(" ")[1];
    const token = req.cookies?.token || headerToken;
    console.log("Cookies:", req.cookies, "Auth Header:", authHeader, "Token:", token);
    if (!token) return res.status(401).json({ error: "عدم دسترسی" });
    jwt.verify(token, process.env.JWT_SECRET!, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: "توکن نامعتبر است" });
      req.user = user;
      next();
    });
  },
  requireAdmin: (req: any, res: Response, next: NextFunction) => {
    if (req.user?.role !== "SUPER_ADMIN") {
      return res
        .status(403)
        .json({ error: "دسترسی فقط برای مدیر کل مجاز است" });
    }
    next();
  },
  requireSupplier: (req: any, res: Response, next: NextFunction) => {
    if (req.user?.role !== "SUPPLIER") {
      return res.status(403).json({ error: "فقط تامینکنندگان دسترسی دارند" });
    }
    next();
  },
  requireStoreManager: (req: any, res: Response, next: NextFunction) => {
    if (req.user?.role !== "STORE_MANAGER") {
      return res
        .status(403)
        .json({ error: "دسترسی فقط برای مدیر فروشگاه مجاز است" });
    }
    next();
  },
  requireReferrer: (req: any, res: Response, next: NextFunction) => {
    if (req.user?.role !== "REFERRER") {
      return res.status(403).json({ error: "دسترسی فقط برای معرف‌ها مجاز است" });
    }
    next();
  },
};
export default auth;
