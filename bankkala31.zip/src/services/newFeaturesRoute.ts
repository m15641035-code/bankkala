import { Express } from "express";
import auth from "./authMiddleware.js";
const { authenticateToken, requireAdmin } = auth;

export default function registerNewFeatures(app: any, prisma: any) {
  app.get("/api/info-pages", async (req: any, res: any) => {
    try {
      const pages = await prisma.infoPage.findMany();
      res.json(pages);
    } catch (error) {
      res.status(500).json({ error: "خطا در دریافت صفحات اطلاعاتی" });
    }
  });

  app.get("/api/public-messages", async (req: any, res: any) => {
    try {
      const messages = await prisma.publicMessage.findMany({
        where: { isActive: true },
      });
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "خطا در دریافت پیام‌های عمومی" });
    }
  });

  app.get("/api/admin/public-messages", async (req: any, res: any) => {
    try {
      const messages = await prisma.publicMessage.findMany();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "خطا در دریافت پیام‌های عمومی" });
    }
  });

  app.post("/api/admin/public-messages", async (req: any, res: any) => {
    try {
      const { content, icon, color, expiryDate, isActive } = req.body;
      const message = await prisma.publicMessage.create({
        data: {
          content,
          icon,
          color,
          expiryDate: expiryDate ? new Date(expiryDate) : null,
          isActive,
        },
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "خطا در ثبت پیام عمومی جدید" });
    }
  });

  app.put("/api/admin/public-messages/:id", async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const { content, icon, color, expiryDate, isActive } = req.body;
      const message = await prisma.publicMessage.update({
        where: { id },
        data: {
          content,
          icon,
          color,
          expiryDate: expiryDate ? new Date(expiryDate) : null,
          isActive,
        },
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "خطا در ویرایش پیام عمومی" });
    }
  });

  app.delete("/api/admin/public-messages/:id", async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      await prisma.publicMessage.delete({ where: { id } });
      res.json({ message: "پیام عمومی با موفقیت حذف شد" });
    } catch (error) {
      res.status(500).json({ error: "خطا در حذف پیام عمومی" });
    }
  });

  app.get("/api/dashboard-messages", async (req: any, res: any) => {
    try {
      const now = new Date();
      const messages = await prisma.dashboardMessage.findMany({
        where: {
          publishDate: { lte: now },
          OR: [{ expiryDate: null }, { expiryDate: { gte: now } }],
        },
        orderBy: { createdAt: "desc" },
      });
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "خطا در دریافت پیام‌های داشبورد" });
    }
  });

  app.get("/api/admin/dashboard-messages", async (req: any, res: any) => {
    try {
      const messages = await prisma.dashboardMessage.findMany({
        orderBy: { createdAt: "desc" },
      });
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "خطا در دریافت پیام‌های داشبورد مدیریت" });
    }
  });

  app.post("/api/admin/dashboard-messages", async (req: any, res: any) => {
    try {
      const {
        title,
        content,
        targetRole,
        priority,
        expiryDate,
        publishDate,
        attachments,
      } = req.body;
      const message = await prisma.dashboardMessage.create({
        data: {
          title,
          content,
          targetRole: targetRole || "ALL",
          priority: priority || "MEDIUM",
          expiryDate: expiryDate ? new Date(expiryDate) : null,
          publishDate: publishDate ? new Date(publishDate) : new Date(),
          attachments,
        },
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "خطا در ثبت پیام جدید" });
    }
  });

  app.put("/api/admin/dashboard-messages/:id", async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const {
        title,
        content,
        targetRole,
        priority,
        expiryDate,
        publishDate,
        attachments,
      } = req.body;
      const message = await prisma.dashboardMessage.update({
        where: { id },
        data: {
          title,
          content,
          targetRole,
          priority,
          expiryDate: expiryDate ? new Date(expiryDate) : null,
          publishDate: publishDate ? new Date(publishDate) : new Date(),
          attachments,
        },
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "خطا در ویرایش پیام داشبورد" });
    }
  });

  app.delete(
    "/api/admin/dashboard-messages/:id",
    async (req: any, res: any) => {
      try {
        const id = parseInt(req.params.id);
        await prisma.dashboardMessage.delete({ where: { id } });
        res.json({ message: "پیام داشبورد با موفقیت حذف شد" });
      } catch (error) {
        res.status(500).json({ error: "خطا در حذف پیام داشبورد" });
      }
    },
  );

  app.post("/api/orders/:id/generate-label", async (req: any, res: any) => {
    try {
      const orderId = parseInt(req.params.id);
      const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { items: true, store: true },
      });
      if (!order) {
        return res.status(404).json({ error: "سفارش یافت نشد" });
      }
      const trackingCode = `POST-${Date.now()}-${Math.floor(Math.random() * 9000 + 1000)}`;
      const mockLabelUrl = `data:text/html;charset=utf-8,MockLabel`;
      const updatedOrder = await prisma.order.update({
        where: { id: orderId },
        data: { postalLabel: mockLabelUrl, status: "PREPARING" },
      });
      await prisma.orderItem.updateMany({
        where: { orderId: order.id },
        data: { status: "PREPARING", trackingCode: trackingCode },
      });
      res.json({
        success: true,
        order: updatedOrder,
        trackingCode,
        labelUrl: mockLabelUrl,
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "خطا در صدور لیبل پستی" });
    }
  });

  app.patch("/api/orders/:id/tracking", async (req: any, res: any) => {
    try {
      const orderId = parseInt(req.params.id);
      const { trackingCode, status } = req.body;
      const order = await prisma.order.update({
        where: { id: orderId },
        data: { status: status || "COMPLETED" },
      });
      await prisma.orderItem.updateMany({
        where: { orderId: orderId },
        data: { trackingCode, status: status || "COMPLETED" },
      });
      res.json({ success: true, order });
    } catch (error) {
      res.status(500).json({ error: "خطا در ثبت اطلاعات پستی و کد رهگیری" });
    }
  });

  app.get("/api/menus/:role", async (req: any, res: any) => {
    try {
      const { role } = req.params;
      const menu = await prisma.dynamicMenu.findUnique({ where: { role } });
      if (menu && menu.items) {
        return res.json(JSON.parse(menu.items));
      }
      res.json([]);
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get(
    "/api/admin/menus/:role",
    authenticateToken,
    requireAdmin,
    async (req: any, res: any) => {
      try {
        const { role } = req.params;
        const menu = await prisma.dynamicMenu.findUnique({ where: { role } });
        if (menu && menu.items) {
          return res.json(JSON.parse(menu.items));
        }
        res.json([]);
      } catch (err: any) {
        console.error(err);
        res.status(500).json({ error: err.message });
      }
    },
  );

  app.put(
    "/api/admin/menus/:role",
    authenticateToken,
    requireAdmin,
    async (req: any, res: any) => {
      try {
        const { role } = req.params;
        const items = req.body;
        const menu = await prisma.dynamicMenu.upsert({
          where: { role },
          update: { items: JSON.stringify(items) },
          create: { role, items: JSON.stringify(items) },
        });
        res.json(JSON.parse(menu.items));
      } catch (err: any) {
        console.error(err);
        res.status(500).json({ error: err.message });
      }
    },
  );
}
