import { PrismaClient, PaymentStatus } from"@prisma/client";
import { PaymentServiceFactory } from"../payment/PaymentServiceFactory.js"; const prisma = new PrismaClient(); export class PaymentLifecycleService { async initiatePayment(userId: number, amount: number, callbackUrl: string) { const idempotencyKey =`PAY_${userId}_${Date.now()}`; const payment = await prisma.payment.create({ data: { userId, amount, idempotencyKey, status: PaymentStatus.PENDING, }, }); try { const paymentGateway = PaymentServiceFactory.getService(); const gatewayResponse = await paymentGateway.createPayment( amount,"Payment for order", callbackUrl, ); const updatedPayment = await prisma.$transaction(async (tx) => { const p = await tx.payment.update({ where: { id: payment.id }, data: { gatewayReference: gatewayResponse.authority }, }); await tx.transactionLog.create({ data: { paymentId: payment.id, action:"INIT", payload: JSON.stringify(gatewayResponse), responseCode:"200", }, }); await tx.auditTrail.create({ data: { actorId: userId, action:"PAYMENT_INITIATE", resource:"Payment", metadata: JSON.stringify({ paymentId: p.id, amount }), }, }); return p; }); return { payment: updatedPayment, payLink: gatewayResponse.payLink }; } catch (err: any) { await prisma.payment.update({ where: { id: payment.id }, data: { status: PaymentStatus.FAILED }, }); throw new Error(`Failed to initiate payment: ${err.message}`); } } async verifyPayment(authority: string, userId: number, ipAddress: string) { 
    const result = await prisma.$transaction(async (tx) => {
      const updated = await tx.payment.updateMany({
        where: { gatewayReference: authority, status: PaymentStatus.PENDING },
        data: { status: PaymentStatus.VERIFYING }
      });
      if (updated.count === 0) {
        const existing = await tx.payment.findFirst({ where: { gatewayReference: authority } });
        return { existing };
      }
      return { payment: await tx.payment.findFirst({ where: { gatewayReference: authority } }) };
    });

    if (result.existing) {
      if (result.existing.status === PaymentStatus.PAID) {
        return { payment: result.existing, message: "Payment already verified" };
      }
      throw new Error("Payment already processed or invalid state.");
    }
    const payment = result.payment!;
    const paymentGateway = PaymentServiceFactory.getService(); const verification = await paymentGateway.verifyPayment( authority, Number(payment.amount), ); return await prisma.$transaction(async (tx) => { const newStatus = verification.success ? PaymentStatus.PAID : PaymentStatus.FAILED; const updatedPayment = await tx.payment.update({ where: { id: payment.id }, data: { status: newStatus }, }); await tx.transactionLog.create({ data: { paymentId: payment.id, action:"VERIFY", payload: JSON.stringify(verification), responseCode: verification.success ?"100" :"FAILED", ipAddress, }, }); await tx.auditTrail.create({ data: { actorId: userId, action:"PAYMENT_VERIFY", resource:"Payment", metadata: JSON.stringify({ paymentId: payment.id, status: newStatus, }), }, }); if (newStatus === PaymentStatus.PAID) { console.log(`[Invoice Job] Queued invoice generation for payment ${payment.id}`, ); } return { payment: updatedPayment, verification }; }); } async refundPayment(paymentId: string, adminId: number) { const payment = await prisma.payment.findUnique({ where: { id: paymentId }, }); if (!payment) throw new Error("Payment not found"); if (payment.status !== PaymentStatus.PAID) throw new Error("Can only refund PAID payments"); return await prisma.$transaction(async (tx) => { const updated = await tx.payment.update({ where: { id: paymentId }, data: { status: PaymentStatus.REFUNDED }, }); await tx.transactionLog.create({ data: { paymentId, action:"REFUND", responseCode:"200", }, }); await tx.auditTrail.create({ data: { actorId: adminId, action:"PAYMENT_REFUND", resource:"Payment", metadata: JSON.stringify({ paymentId }), }, }); return updated; }); }
}
