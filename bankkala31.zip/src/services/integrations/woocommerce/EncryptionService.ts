import crypto from"crypto";
const algorithm ="aes-256-cbc";
// Ensure we have a 32 byte key. In production, read from process.env.ENCRYPTION_KEY
function getKey() { 
    const raw = process.env.ENCRYPTION_KEY;
    if (!raw) throw new Error('ENCRYPTION_KEY environment variable is required');
    return crypto.createHash('sha256').update(raw).digest();
  }
export class EncryptionService { static encrypt(text: string): string { const iv = crypto.randomBytes(16); const cipher = crypto.createCipheriv(algorithm, getKey(), iv); let encrypted = cipher.update(text,"utf8","hex"); encrypted += cipher.final("hex"); return`${iv.toString("hex")}:${encrypted}`; } static decrypt(text: string): string { const textParts = text.split(":"); const iv = Buffer.from(textParts.shift()!,"hex"); const encryptedText = Buffer.from(textParts.join(":"),"hex"); const decipher = crypto.createDecipheriv(algorithm, getKey(), iv); let decrypted = decipher.update(encryptedText); decrypted = Buffer.concat([decrypted, decipher.final()]); return decrypted.toString("utf8"); }
}
