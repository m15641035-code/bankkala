import { PrismaClient } from"@prisma/client";
import { EncryptionService } from"./EncryptionService.js";
let prisma: any;
try { prisma = new PrismaClient();
} catch { const noOp: any = { findMany: async () => [], findFirst: async () => null, findUnique: async () => null, create: async (d: any) => d?.data ?? {}, update: async (d: any) => d?.data ?? {}, delete: async () => ({}), }; prisma = new Proxy({}, { get: () => noOp });
}

function validateStoreUrl(urlStr: string): void {
  let parsed: URL;
  try { parsed = new URL(urlStr); } catch { throw new Error('Invalid URL'); }
  if (parsed.protocol !== 'https:') throw new Error('Only HTTPS allowed');
  const hostname = parsed.hostname.toLowerCase();
  const blocked = ['localhost', '127.0.0.1', '0.0.0.0', '::1'];
  if (blocked.includes(hostname) || hostname.endsWith('.local') ||
      /^10\.|^172\.(1[6-9]|2\d|3[01])\.|^192\.168\./.test(hostname))
    throw new Error('Internal addresses not allowed');
}

export class ConnectionService { static async testConnection(
    storeUrl: string,
    consumerKey: string,
    consumerSecret: string,
  ) {
    try {
      validateStoreUrl(storeUrl); const url = new URL("/wp-json/wc/v3/system_status", storeUrl); const auth = Buffer.from(`${consumerKey}:${consumerSecret}`).toString("base64", ); const response = await fetch(url.toString(), { credentials: "include", signal: AbortSignal.timeout(10000), headers: { Authorization:`Basic ${auth}`, Accept:"application/json" }, }); if (!response.ok) { return { success: false, error:"Connection failed. Please check credentials and URL.", }; } const data = (await response.json()) as any; return { success: true, data: { wooVersion: data.environment?.version, wpVersion: data.environment?.wp_version, }, }; } catch (error: any) { return { success: false, error: error.message ||"Network error" }; } } static async connect(
    storeId: number,
    storeUrl: string,
    consumerKey: string,
    consumerSecret: string,
  ) {
    validateStoreUrl(storeUrl); const encKey = EncryptionService.encrypt(consumerKey); const encSecret = EncryptionService.encrypt(consumerSecret); return await prisma.storeConnection.upsert({ where: { storeId }, update: { storeUrl, consumerKey: encKey, consumerSecret: encSecret, status:"CONNECTED", }, create: { storeId, storeUrl, consumerKey: encKey, consumerSecret: encSecret, status:"CONNECTED", }, }); } static async disconnect(storeId: number) { return await prisma.storeConnection.update({ where: { storeId }, data: { status:"DISCONNECTED", consumerKey:"", consumerSecret:"" }, }); } static async getConnection(storeId: number) { const conn = await prisma.storeConnection.findUnique({ where: { storeId }, }); if (!conn) return null; return { ...conn, consumerKey: conn.consumerKey ? EncryptionService.decrypt(conn.consumerKey) :"", consumerSecret: conn.consumerSecret ? EncryptionService.decrypt(conn.consumerSecret) :"", }; }
}
