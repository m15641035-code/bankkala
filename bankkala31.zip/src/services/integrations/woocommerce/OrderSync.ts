import WooCommerceRestApi from"@woocommerce/woocommerce-rest-api";
import { processOrderPayload } from"./WebhookService";
import { PrismaClient } from"@prisma/client";
const prisma = new PrismaClient();

async function fetchWithRetry(fn: () => Promise<any>, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (e: any) {
      if (i === maxRetries - 1 || (e.response && e.response.status >= 400 && e.response.status < 500)) throw e;
      await new Promise(r => setTimeout(r, Math.pow(2, i) * 1000));
    }
  }
}

export async function syncSingleOrder(storeId: number, orderId: string) { const connection = await prisma.storeConnection.findUnique({ where: { storeId }, }); if (!connection) { throw new Error("Store connection not found"); } const api = new (WooCommerceRestApi as any).default({ url: connection.storeUrl, consumerKey: connection.consumerKey, consumerSecret: connection.consumerSecret, version:"wc/v3", }); const response = await fetchWithRetry(() => api.get(`orders/${orderId}`)); if (response.status === 200 && response.data) { await processOrderPayload(response.data, storeId); return { success: true, order: response.data }; } else { throw new Error(`Failed to fetch order ${orderId} from WooCommerce`); }
}
