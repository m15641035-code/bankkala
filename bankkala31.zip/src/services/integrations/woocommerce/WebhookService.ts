import { PrismaClient, LedgerType } from "@prisma/client";
import crypto from "crypto";
import { WalletService } from "../../WalletService.js";

const prisma = new PrismaClient();
const walletService = new WalletService();


async function processOrderQueue() {
  try {
    const tasks = await prisma.webhookRetry.findMany({
      where: {
        status: "PENDING",
        nextRetryAt: { lte: new Date() }
      },
      take: 10
    });
    
    for (const task of tasks) {
      try {
        await processOrderPayload(JSON.parse(task.payload), task.storeId || 0);
        await prisma.webhookRetry.update({
          where: { id: task.id },
          data: { status: "COMPLETED" }
        });
      } catch (err: any) {
        if (task.attempts + 1 >= task.maxAttempts) {
          await prisma.webhookRetry.update({
            where: { id: task.id },
            data: { status: "FAILED", attempts: task.attempts + 1 }
          });
        } else {
          await prisma.webhookRetry.update({
            where: { id: task.id },
            data: { 
              attempts: task.attempts + 1,
              nextRetryAt: new Date(Date.now() + Math.pow(2, task.attempts) * 60000)
            }
          });
        }
      }
    }
  } catch (e) {
    console.error("Error processing retry queue", e);
  }
}

setInterval(processOrderQueue, 60000);


export class WebhookService {
  static async handleWebhook(
    payload: any,
    signature: string | undefined,
    storeId: number,
  ) {
    const connection = await prisma.storeConnection.findUnique({
      where: { storeId },
    });

    if (!connection) {
      throw new Error("Store connection not found");
    }

    if (connection.webhookSecret && signature) {
      const payloadString = JSON.stringify(payload);
      const expectedSignature = crypto
        .createHmac("sha256", connection.webhookSecret)
        .update(payloadString, "utf8")
        .digest("base64");

      if (expectedSignature !== signature) {
        console.warn(
          "Webhook signature mismatch. Expected:",
          expectedSignature,
          "Got:",
          signature,
        );
      }
    }

    if (payload && payload.id) {
      try {
        await processOrderPayload(payload, storeId);
      } catch (err: any) {
        console.error(
          `Error processing order webhook (id: ${payload.id}): ${err.message}. Adding to retry queue.`,
        );
        await prisma.webhookRetry.create({
          data: {
            payload: JSON.stringify(payload),
            storeId,
            attempts: 1,
            nextRetryAt: new Date(Date.now() + 60000)
          }
        });
      }
    }

    return { success: true };
  }
}

export async function processOrderPayload(payload: any, storeId: number) {
  if (payload.status !== "completed") {
    return;
  }
  const orderId = payload.id.toString();

  const existingLedger = await prisma.ledgerEntry.findFirst({
    where: {
      referenceId: orderId,
      type: LedgerType.ORDER_REVENUE,
    },
  });

  if (existingLedger) {
    console.log(`Order ${orderId} already processed. Skipping.`);
    return;
  }

  for (const item of payload.line_items) {
    const wcProductId = item.product_id;
    const itemTotal = parseFloat(item.total);

    const storeProduct = await prisma.storeProductSelection.findUnique({
      where: { wc_product_id: wcProductId },
      include: { product: true },
    });

    if (storeProduct && storeProduct.product) {
      const product = storeProduct.product;
      const supplierId = product.supplierId;

      let commissionRate = 0;
      let commissionAmount = 0;

      if (product.marginType === "PERCENTAGE" && product.marginValue) {
        commissionRate = product.marginValue / 100;
        commissionAmount = itemTotal * commissionRate;
      } else if (product.marginType === "FIXED" && product.marginValue) {
        commissionAmount = product.marginValue * item.quantity;
      }

      const supplierRevenue = itemTotal - commissionAmount;

      if (supplierRevenue > 0) {
        const wallet = await prisma.wallet.findUnique({
          where: { supplierId },
        });

        if (wallet) {
          await walletService.creditWallet(
            wallet.id,
            supplierRevenue,
            LedgerType.ORDER_REVENUE,
            orderId,
            `Revenue for order #${orderId} (Item: ${item.name})`,
          );
          console.log(
            `Credited wallet ${wallet.id} with ${supplierRevenue} for order ${orderId}`,
          );
        } else {
          console.error(`Wallet not found for supplier ${supplierId}`);
        }
      }
    } else {
      console.warn(
        `Product mapping not found for WC Product ID: ${wcProductId}`,
      );
    }
  }
}
