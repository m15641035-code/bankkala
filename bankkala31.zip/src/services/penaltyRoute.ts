import { Request, Response, NextFunction } from "express";
import auth from "./authMiddleware.js";

const { authenticateToken, requireAdmin, requireSupplier } = auth;

export default function registerPenaltyRoutes(app: any, prisma: any) {
  // Seed default data on startup
  seedInitialData(prisma).catch(err => {
    console.error("Error seeding penalty data:", err);
  });

  // 1. GET penalty rules (Admin only) - supports search and filter
  app.get("/api/admin/penalty-rules", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const { search, isActive } = req.query;
      
      const where: any = {};
      
      if (search) {
        where.OR = [
          { title: { contains: String(search) } },
          { description: { contains: String(search) } },
        ];
      }
      
      if (isActive !== undefined) {
        where.isActive = isActive === "true";
      }

      const rules = await prisma.penaltyRule.findMany({
        where,
        orderBy: { createdAt: "desc" },
      });

      res.json(rules);
    } catch (error) {
      console.error("Error fetching penalty rules:", error);
      res.status(500).json({ error: "خطا در دریافت قوانین جریمه" });
    }
  });

  // 2. POST create penalty rule (Admin only)
  app.post("/api/admin/penalty-rules", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const { title, description, negativePoints, autoNotification, isActive, extraData } = req.body;
      
      if (!title || negativePoints === undefined) {
        return res.status(400).json({ error: "عنوان و امتیاز منفی الزامی هستند" });
      }

      const rule = await prisma.penaltyRule.create({
        data: {
          title,
          description: description || "",
          negativePoints: parseInt(negativePoints),
          autoNotification: autoNotification !== false,
          isActive: isActive !== false,
          extraData: extraData || null,
        },
      });

      // Log to Audit Log
      await prisma.auditTrail.create({
        data: {
          actorId: req.user?.id,
          action: "CREATE_PENALTY_RULE",
          resource: `PenaltyRule:${rule.id}`,
          metadata: JSON.stringify({ title, negativePoints }),
        },
      });

      res.status(201).json(rule);
    } catch (error) {
      console.error("Error creating penalty rule:", error);
      res.status(500).json({ error: "خطا در ایجاد قانون جریمه جدید" });
    }
  });

  // 3. PUT edit penalty rule (Admin only)
  app.put("/api/admin/penalty-rules/:id", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const { title, description, negativePoints, autoNotification, isActive, extraData } = req.body;

      const existingRule = await prisma.penaltyRule.findUnique({ where: { id } });
      if (!existingRule) {
        return res.status(404).json({ error: "قانون جریمه پیدا نشد" });
      }

      const rule = await prisma.penaltyRule.update({
        where: { id },
        data: {
          title: title !== undefined ? title : existingRule.title,
          description: description !== undefined ? description : existingRule.description,
          negativePoints: negativePoints !== undefined ? parseInt(negativePoints) : existingRule.negativePoints,
          autoNotification: autoNotification !== undefined ? autoNotification : existingRule.autoNotification,
          isActive: isActive !== undefined ? isActive : existingRule.isActive,
          extraData: extraData !== undefined ? extraData : existingRule.extraData,
        },
      });

      // Log to Audit Log
      await prisma.auditTrail.create({
        data: {
          actorId: req.user?.id,
          action: "UPDATE_PENALTY_RULE",
          resource: `PenaltyRule:${id}`,
          metadata: JSON.stringify({ title: rule.title, negativePoints: rule.negativePoints }),
        },
      });

      res.json(rule);
    } catch (error) {
      console.error("Error updating penalty rule:", error);
      res.status(500).json({ error: "خطا در ویرایش قانون جریمه" });
    }
  });

  // 4. DELETE penalty rule (Admin only)
  app.delete("/api/admin/penalty-rules/:id", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);

      const existingRule = await prisma.penaltyRule.findUnique({ where: { id } });
      if (!existingRule) {
        return res.status(404).json({ error: "قانون جریمه پیدا نشد" });
      }

      await prisma.penaltyRule.delete({ where: { id } });

      // Log to Audit Log
      await prisma.auditTrail.create({
        data: {
          actorId: req.user?.id,
          action: "DELETE_PENALTY_RULE",
          resource: `PenaltyRule:${id}`,
          metadata: JSON.stringify({ title: existingRule.title }),
        },
      });

      res.json({ message: "قانون جریمه با موفقیت حذف شد" });
    } catch (error) {
      console.error("Error deleting penalty rule:", error);
      res.status(500).json({ error: "خطا در حذف قانون جریمه" });
    }
  });

  // 5. GET penalty config (Admin only)
  app.get("/api/admin/penalty-config", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const config = await getOrCreateConfig(prisma);
      res.json(config);
    } catch (error) {
      console.error("Error fetching config:", error);
      res.status(500).json({ error: "خطا در دریافت تنظیمات جرایم" });
    }
  });

  // 6. PUT update penalty config (Admin only)
  app.put("/api/admin/penalty-config", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const { underReviewThreshold, temporarySuspensionThreshold, blockedThreshold, autoSuspensionEnabled } = req.body;

      const config = await prisma.penaltyConfig.upsert({
        where: { id: 1 },
        update: {
          underReviewThreshold: parseInt(underReviewThreshold),
          temporarySuspensionThreshold: parseInt(temporarySuspensionThreshold),
          blockedThreshold: parseInt(blockedThreshold),
          autoSuspensionEnabled: autoSuspensionEnabled === true,
        },
        create: {
          id: 1,
          underReviewThreshold: parseInt(underReviewThreshold),
          temporarySuspensionThreshold: parseInt(temporarySuspensionThreshold),
          blockedThreshold: parseInt(blockedThreshold),
          autoSuspensionEnabled: autoSuspensionEnabled === true,
        },
      });

      // Log to Audit Log
      await prisma.auditTrail.create({
        data: {
          actorId: req.user?.id,
          action: "UPDATE_PENALTY_CONFIG",
          resource: "PenaltyConfig:1",
          metadata: JSON.stringify(config),
        },
      });

      // Recalculate status of all suppliers with new thresholds
      await syncAllSuppliersStatuses(prisma);

      res.json({ message: "تنظیمات آستانه با موفقیت ویرایش و اعمال شد", config });
    } catch (error) {
      console.error("Error updating penalty config:", error);
      res.status(500).json({ error: "خطا در ثبت تنظیمات آستانه جرایم" });
    }
  });

  // 7. POST apply penalty to supplier (Admin only)
  app.post("/api/admin/suppliers/:id/penalties", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const supplierId = parseInt(req.params.id);
      const { reason, description, points, orderNumber } = req.body;

      if (!reason || points === undefined) {
        return res.status(400).json({ error: "علت جریمه و امتیاز منفی الزامی است" });
      }

      // Fetch admin user name
      const admin = await prisma.user.findUnique({ where: { id: req.user?.id } });
      const adminName = admin ? `${admin.firstName || ""} ${admin.lastName || ""}`.trim() || admin.username : "مدیر";

      const result = await applyPenaltyToSupplier(prisma, supplierId, {
        reason,
        points: parseInt(points),
        description: description || "",
        orderNumber: orderNumber || null,
        adminId: req.user?.id,
        adminName,
      });

      res.status(201).json(result);
    } catch (error: any) {
      console.error("Error applying penalty:", error);
      res.status(500).json({ error: error.message || "خطا در اعمال جریمه به تامین‌کننده" });
    }
  });

  // 8. GET supplier penalties history (Admin and Supplier check)
  app.get("/api/admin/suppliers/:id/penalties", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const supplierId = parseInt(req.params.id);
      const history = await prisma.supplierPenalty.findMany({
        where: { supplierId },
        orderBy: { createdAt: "desc" },
      });
      res.json(history);
    } catch (error) {
      console.error("Error fetching supplier penalty history:", error);
      res.status(500).json({ error: "خطا در دریافت تاریخچه جرایم" });
    }
  });

  // 9. GET overall stats (Admin only)
  app.get("/api/admin/penalties/stats", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      // Average Supplier Score
      const avgScoreResult = await prisma.user.aggregate({
        where: { role: "SUPPLIER" },
        _avg: { performanceScore: true },
        _count: { id: true },
      });

      const avgScore = avgScoreResult._avg.performanceScore !== null ? Math.round(avgScoreResult._avg.performanceScore) : 100;
      const totalSuppliers = avgScoreResult._count.id;

      // Penalty statistics counts
      const totalPenalties = await prisma.supplierPenalty.count();

      // Top Violating Suppliers
      const topViolators = await prisma.user.findMany({
        where: { role: "SUPPLIER", penaltyPoints: { gt: 0 } },
        orderBy: { penaltyPoints: "desc" },
        take: 5,
        select: {
          id: true,
          username: true,
          brandName: true,
          performanceScore: true,
          penaltyPoints: true,
          status: true,
          warningLevel: true,
        },
      });

      // Recent Penalties (take 10)
      const recentPenalties = await prisma.supplierPenalty.findMany({
        orderBy: { createdAt: "desc" },
        take: 10,
        include: {
          supplier: {
            select: {
              id: true,
              brandName: true,
              username: true,
            }
          }
        }
      });

      // Count suppliers under different statuses
      const statusCounts = await prisma.user.groupBy({
        by: ["status"],
        where: { role: "SUPPLIER" },
        _count: { id: true },
      });

      res.json({
        averageScore: avgScore,
        totalSuppliers,
        totalPenalties,
        topViolators,
        recentPenalties,
        statusCounts: statusCounts.reduce((acc: any, curr: any) => {
          acc[curr.status || "ACTIVE"] = curr._count.id;
          return acc;
        }, {}),
      });
    } catch (error) {
      console.error("Error fetching dashboard statistics:", error);
      res.status(500).json({ error: "خطا در دریافت آمار مدیریت جرایم" });
    }
  });

  // 10. GET performance list of all suppliers (Admin only)
  app.get("/api/admin/suppliers/performance", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const suppliers = await prisma.user.findMany({
        where: { role: "SUPPLIER" },
        orderBy: { performanceScore: "asc" }, // Show poorest performers first
        select: {
          id: true,
          username: true,
          brandName: true,
          firstName: true,
          lastName: true,
          performanceScore: true,
          penaltyPoints: true,
          status: true,
          warningLevel: true,
          email: true,
          mobile: true,
        },
      });
      res.json(suppliers);
    } catch (error) {
      console.error("Error fetching supplier performance list:", error);
      res.status(500).json({ error: "خطا در دریافت لیست عملکرد تامین‌کنندگان" });
    }
  });

  // 11. GET single supplier profile details (Admin view of any supplier or Supplier view of self)
  app.get("/api/admin/suppliers/:id/performance", authenticateToken, requireAdmin, async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const data = await getSupplierPerformanceProfile(prisma, id);
      res.json(data);
    } catch (error: any) {
      res.status(404).json({ error: error.message || "تامین‌کننده یافت نشد" });
    }
  });

  // 12. GET supplier self performance stats
  app.get("/api/supplier/performance", authenticateToken, requireSupplier, async (req: any, res: any) => {
    try {
      const id = req.user?.id;
      const data = await getSupplierPerformanceProfile(prisma, id);
      res.json(data);
    } catch (error: any) {
      res.status(404).json({ error: error.message || "تامین‌کننده یافت نشد" });
    }
  });
}

// Helper: Get supplier performance profile with all timelines and statistics
async function getSupplierPerformanceProfile(prisma: any, supplierId: number) {
  const supplier = await prisma.user.findUnique({
    where: { id: supplierId },
    select: {
      id: true,
      username: true,
      brandName: true,
      firstName: true,
      lastName: true,
      performanceScore: true,
      penaltyPoints: true,
      status: true,
      warningLevel: true,
      createdAt: true,
    }
  });

  if (!supplier) throw new Error("تامین‌کننده یافت نشد.");

  // Penalty history timeline
  const penalties = await prisma.supplierPenalty.findMany({
    where: { supplierId },
    orderBy: { createdAt: "desc" },
  });

  // Find orders affected
  // Retrieve distinct order numbers from supplier's penalty history
  const affectedOrders = penalties
    .map((p: any) => p.orderNumber)
    .filter((orderNo: any) => orderNo !== null && orderNo !== undefined && orderNo !== "");
  
  const distinctAffectedOrders = [...new Set(affectedOrders)];

  return {
    supplier,
    penalties,
    distinctAffectedOrders,
    affectedOrdersCount: distinctAffectedOrders.length,
    recentViolations: penalties.slice(0, 5),
  };
}

// Helper: Apply penalty to supplier and update stats & warning level
async function applyPenaltyToSupplier(prisma: any, supplierId: number, ruleData: { reason: string, points: number, description: string, orderNumber?: string, adminId?: number, adminName?: string }) {
  const supplier = await prisma.user.findUnique({ where: { id: supplierId } });
  if (!supplier) throw new Error("تامین‌کننده پیدا نشد.");

  const penalty = await prisma.supplierPenalty.create({
    data: {
      supplierId,
      adminId: ruleData.adminId || null,
      adminName: ruleData.adminName || "سیستم",
      reason: ruleData.reason,
      points: ruleData.points,
      description: ruleData.description,
      orderNumber: ruleData.orderNumber || null,
    }
  });

  const config = await getOrCreateConfig(prisma);

  // New score calculations
  const newPenaltyPoints = (supplier.penaltyPoints || 0) + ruleData.points;
  const newPerformanceScore = Math.max(0, 100 - newPenaltyPoints);

  // Warning Level
  let newWarningLevel = "NONE";
  if (newPenaltyPoints >= config.blockedThreshold) {
    newWarningLevel = "CRITICAL";
  } else if (newPenaltyPoints >= config.temporarySuspensionThreshold) {
    newWarningLevel = "HIGH";
  } else if (newPenaltyPoints >= config.underReviewThreshold) {
    newWarningLevel = "MEDIUM";
  } else if (newPenaltyPoints > 0) {
    newWarningLevel = "LOW";
  }

  // Auto Status Change
  let newStatus = supplier.status;
  if (config.autoSuspensionEnabled) {
    if (newPenaltyPoints >= config.blockedThreshold) {
      newStatus = "BLOCKED";
    } else if (newPenaltyPoints >= config.temporarySuspensionThreshold) {
      newStatus = "TEMPORARILY_SUSPENDED";
    } else if (newPenaltyPoints >= config.underReviewThreshold) {
      newStatus = "UNDER_REVIEW";
    }
  }

  // Update supplier details
  await prisma.user.update({
    where: { id: supplierId },
    data: {
      penaltyPoints: newPenaltyPoints,
      performanceScore: newPerformanceScore,
      warningLevel: newWarningLevel,
      status: newStatus,
    }
  });

  // Send Notification to supplier
  try {
    await prisma.notification.create({
      data: {
        userId: supplierId,
        title: "ثبت امتیاز منفی جدید",
        message: `یک جریمه با عنوان "${ruleData.reason}" به علت "${ruleData.description || "نقض قوانین"}" و ارزش ${ruleData.points} امتیاز منفی برای شما اعمال شد. امتیاز عملکرد جدید شما: ${newPerformanceScore}.`,
      }
    });
  } catch (err) {
    console.error("Failed to create notification:", err);
  }

  // Log in Audit Log
  try {
    await prisma.auditTrail.create({
      data: {
        actorId: ruleData.adminId || null,
        action: "APPLY_PENALTY",
        resource: `User:${supplierId}`,
        metadata: JSON.stringify({
          penaltyId: penalty.id,
          points: ruleData.points,
          reason: ruleData.reason,
          newPenaltyPoints,
          newPerformanceScore,
          newStatus,
        }),
      }
    });
  } catch (err) {
    console.error("Failed to write to audit trail:", err);
  }

  return { penalty, newPenaltyPoints, newPerformanceScore, newStatus };
}

// Helper: Sync all suppliers' statuses with the current configuration thresholds
async function syncAllSuppliersStatuses(prisma: any) {
  const config = await getOrCreateConfig(prisma);
  const suppliers = await prisma.user.findMany({
    where: { role: "SUPPLIER" },
  });

  for (const supplier of suppliers) {
    const points = supplier.penaltyPoints || 0;
    const score = Math.max(0, 100 - points);

    let warningLevel = "NONE";
    if (points >= config.blockedThreshold) {
      warningLevel = "CRITICAL";
    } else if (points >= config.temporarySuspensionThreshold) {
      warningLevel = "HIGH";
    } else if (points >= config.underReviewThreshold) {
      warningLevel = "MEDIUM";
    } else if (points > 0) {
      warningLevel = "LOW";
    }

    let status = supplier.status;
    if (config.autoSuspensionEnabled) {
      if (points >= config.blockedThreshold) {
        status = "BLOCKED";
      } else if (points >= config.temporarySuspensionThreshold) {
        status = "TEMPORARILY_SUSPENDED";
      } else if (points >= config.underReviewThreshold) {
        status = "UNDER_REVIEW";
      } else {
        if (["UNDER_REVIEW", "TEMPORARILY_SUSPENDED", "BLOCKED"].includes(supplier.status || "")) {
          status = "ACTIVE";
        }
      }
    }

    if (supplier.performanceScore !== score || supplier.warningLevel !== warningLevel || supplier.status !== status) {
      await prisma.user.update({
        where: { id: supplier.id },
        data: {
          performanceScore: score,
          warningLevel,
          status,
        }
      });
    }
  }
}

// Helper: Retrieve or create default PenaltyConfig
async function getOrCreateConfig(prisma: any) {
  let config = await prisma.penaltyConfig.findUnique({ where: { id: 1 } });
  if (!config) {
    config = await prisma.penaltyConfig.create({
      data: {
        id: 1,
        underReviewThreshold: 20,
        temporarySuspensionThreshold: 40,
        blockedThreshold: 60,
        autoSuspensionEnabled: true,
      }
    });
  }
  return config;
}

// Helper: Seed initial configuration and standard penalty rules on boot
async function seedInitialData(prisma: any) {
  await getOrCreateConfig(prisma);

  // Seed default penalty rules
  const rulesCount = await prisma.penaltyRule.count();
  if (rulesCount === 0) {
    const defaultRules = [
      { title: "Late shipment (24h)", description: "ارسال دیرهنگام کالا با تاخیر ۲۴ ساعت", negativePoints: 10, autoNotification: true, isActive: true },
      { title: "Late shipment (48h)", description: "ارسال دیرهنگام کالا با تاخیر ۴۸ ساعت", negativePoints: 20, autoNotification: true, isActive: true },
      { title: "Missing shipping label", description: "عدم الصاق لیبل آدرس یا بارنامه روی مرسوله", negativePoints: 5, autoNotification: true, isActive: true },
      { title: "Incorrect packaging", description: "بسته‌بندی غیراستاندارد یا آسیب‌دیده", negativePoints: 8, autoNotification: true, isActive: true },
      { title: "Wrong product sent", description: "ارسال کالای مغایر با سفارش مشتری", negativePoints: 15, autoNotification: true, isActive: true },
      { title: "Customer complaint confirmed", description: "شکایت تایید شده مشتری از کیفیت یا اصالت کالا", negativePoints: 10, autoNotification: true, isActive: true },
      { title: "Repeated cancellation", description: "لغو مکرر سفارشات به دلیل عدم موجودی یا عدم تامین", negativePoints: 20, autoNotification: true, isActive: true },
    ];

    for (const rule of defaultRules) {
      await prisma.penaltyRule.create({ data: rule });
    }
    console.log("[Penalty System] Seeded default penalty rules.");
  }

  // Seed sample supplier penalties if none exist
  const suppliers = await prisma.user.findMany({ where: { role: "SUPPLIER" } });
  if (suppliers.length > 0) {
    const penaltiesCount = await prisma.supplierPenalty.count();
    if (penaltiesCount === 0) {
      const firstSupplier = suppliers[0];
      await applyPenaltyToSupplier(prisma, firstSupplier.id, {
        reason: "Incorrect packaging",
        points: 8,
        description: "بسته‌بندی غیراستاندارد محصول و آسیب‌دیدگی جزئی کارتن بیرونی در سفارش ORD-2026-904",
        orderNumber: "ORD-2026-904",
        adminName: "مدیر سیستم",
      });

      if (suppliers.length > 1) {
        const secondSupplier = suppliers[1];
        await applyPenaltyToSupplier(prisma, secondSupplier.id, {
          reason: "Late shipment (24h)",
          points: 10,
          description: "تاخیر ۲۴ ساعته در تامین لپ‌تاپ سفارش مشتری به شماره ORD-2026-815",
          orderNumber: "ORD-2026-815",
          adminName: "پشتیبانی فنی",
        });

        await applyPenaltyToSupplier(prisma, secondSupplier.id, {
          reason: "Wrong product sent",
          points: 15,
          description: "ارسال اشتباه رنگ گوشی موبایل در سفارش ORD-2026-832",
          orderNumber: "ORD-2026-832",
          adminName: "مدیر ناظر",
        });
      }
      console.log("[Penalty System] Seeded sample historical supplier penalties.");
    }
  }
}
