import { PaymentGateway } from "../../interfaces/payment-gateway.interface";

const ZIBAL_MERCHANT = process.env.ZIBAL_MERCHANT || "zibal";
const ZIBAL_GATEWAY_URL = "https://gateway.zibal.ir/v1";
const ZIBAL_API_URL = "https://api.zibal.ir/v1"; // Used for payout/settlement usually

export class ZibalService implements PaymentGateway {
  async createPayment(
    amount: number | string,
    description: string,
    callbackUrl: string,
  ): Promise<{ payLink: string; authority: string }> {
    try {
      const amountInRials = Number(amount) * 10;
      const response = await fetch(`${ZIBAL_GATEWAY_URL}/request`, { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          merchant: ZIBAL_MERCHANT,
          amount: amountInRials,
          callbackUrl,
          description,
        }),
      });
      const data = await response.json();
      if (data.result === 100 && data.trackId) {
        return {
          payLink: `https://gateway.zibal.ir/start/${data.trackId}`,
          authority: data.trackId.toString(),
        };
      } else {
        throw new Error(
          `Zibal Payment Request Failed: ${data.message || data.result}`,
        );
      }
    } catch (error: any) {
      console.error("Zibal createPayment error:", error);
      throw new Error(`Failed to create payment: ${error.message}`);
    }
  }

  async verifyPayment(
    authority: string,
    amount: number | string,
  ): Promise<{ success: boolean; trackId: string; refId: string }> {
    try {
      const response = await fetch(`${ZIBAL_GATEWAY_URL}/verify`, { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          merchant: ZIBAL_MERCHANT,
          trackId: authority,
        }),
      });
      const data = await response.json();
      if (data.result === 100 || data.result === 201) {
        return {
          success: true,
          trackId: authority,
          refId:
            data.refNumber?.toString() || data.refId?.toString() || authority,
        };
      } else {
        return { success: false, trackId: authority, refId: "" };
      }
    } catch (error: any) {
      console.error("Zibal verifyPayment error:", error);
      return { success: false, trackId: authority, refId: "" };
    }
  }

  async requestPayout(
    amount: number | string,
    shaba: string,
    description: string,
  ): Promise<{ success: boolean; trackId: string }> {
    try {
      const response = await fetch(`${ZIBAL_API_URL}/checkout`, { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ZIBAL_MERCHANT}`,
        },
        body: JSON.stringify({
          merchant: ZIBAL_MERCHANT,
          amount: Number(amount),
          iban: shaba.replace(/^IR/i, ""),
          description,
        }),
      });
      const data = await response.json();
      if (data.result === 1 || data.result === 100 || data.success) {
        return {
          success: true,
          trackId:
            data.trackId?.toString() ||
            data.id?.toString() ||
            `ZIBAL_PAYOUT_${Date.now()}`,
        };
      } else {
        throw new Error(
          `Zibal Payout Request Failed: ${data.message || data.result}`,
        );
      }
    } catch (error: any) {
      console.error("Zibal requestPayout error:", error);
      throw new Error(`Failed to request payout: ${error.message}`);
    }
  }

  async getPayoutStatus(
    trackId: string,
  ): Promise<{ status: string; detail: string }> {
    try {
      const response = await fetch(`${ZIBAL_API_URL}/checkout/status`, { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ZIBAL_MERCHANT}`,
        },
        body: JSON.stringify({
          merchant: ZIBAL_MERCHANT,
          trackId: trackId,
        }),
      });
      const data = await response.json();
      let mappedStatus = "PENDING";

      if (data.status === "done" || data.result === 100 || data.status === 3)
        mappedStatus = "SUCCESS";
      else if (
        data.status === "failed" ||
        data.status === "rejected" ||
        data.status === 4
      )
        mappedStatus = "FAILED";
      else if (data.status === "processing" || data.status === 2)
        mappedStatus = "PROCESSING";

      return {
        status: mappedStatus,
        detail:
          data.message || data.description || "Status retrieved successfully",
      };
    } catch (error: any) {
      console.error("Zibal getPayoutStatus error:", error);
      throw new Error(`Failed to get payout status: ${error.message}`);
    }
  }
}
