import { PaymentGateway } from "../../interfaces/payment-gateway.interface";
import { ZibalService } from "./ZibalService";
import { MockZibalService } from "./MockZibalService";
export class PaymentServiceFactory {
  static getService(): PaymentGateway {
    if (process.env.USE_MOCK_GATEWAY === "true") {
      console.log("Using Mock Zibal Payment Gateway Simulator");
      return new MockZibalService();
    }
    console.log("Using Official Zibal Production Payment Gateway");
    return new ZibalService();
  }
}
