import React, { useState, useEffect } from "react";
import {
  DollarSign,
  X,
  Calendar,
  Pin,
  AlertCircle,
  Plus,
  Edit,
  Trash2,
  Package,
  Tag,
  Users,
  Layers,
  Shield,
  Image as ImageIcon,
} from "lucide-react";
export default function ProductsList() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  // Modals state
  const [showMarginModal, setShowMarginModal] = useState(false);
  const [showAddEditModal, setShowAddEditModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formError, setFormError] = useState("");
  /* Pricing margin state */ const [publishData, setPublishData] = useState({
    marginType: "PERCENTAGE",
    marginValue: 10,
    publishStartDate: "",
    publishEndDate: "",
    isPinned: false,
  });
  /* Create/Edit product state */ const [productForm, setProductForm] =
    useState({
      id: "",
      name: "",
      categoryId: "",
      supplierId: "",
      shortDescription: "",
      longDescription: "",
      supplierBasePrice: "",
      finalPrice: "",
      sku: "",
      brand: "",
      inventory: "0",
      imageUrl: "",
    });
  const fetchProducts = () => {
    const token = localStorage.getItem("token") || "";
    fetch("/api/admin/products", { credentials: "include",
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setProducts(data);
        else setProducts([]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };
  const fetchMetadata = async () => {
    try {
      const token = localStorage.getItem("token") || "";
      const [catRes, supRes] = await Promise.all([
        fetch("/api/admin/categories", { credentials: "include",
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch("/api/admin/suppliers", { credentials: "include",
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);
      if (catRes.ok) {
        const cats = await catRes.json();
        setCategories(cats);
      }
      if (supRes.ok) {
        const sups = await supRes.json();
        setSuppliers(sups);
      }
    } catch (err) {
      console.error("Error fetching admin metadata:", err);
    }
  };
  useEffect(() => {
    fetchProducts();
    fetchMetadata();
  }, []);
  const handlePublish = () => {
    if (!selectedProduct) return;
    /* calculate final price */ let finalPrice =
      selectedProduct.supplierBasePrice;
    if (publishData.marginType === "PERCENTAGE") {
      finalPrice =
        selectedProduct.supplierBasePrice * (1 + publishData.marginValue / 100);
    } else {
      finalPrice = selectedProduct.supplierBasePrice + publishData.marginValue;
    }
    fetch(`/api/admin/products/${selectedProduct.id}/publish`, { credentials: "include",
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      },
      body: JSON.stringify({
        ...publishData,
        finalPrice,
        publishStartDate: publishData.publishStartDate || null,
        publishEndDate: publishData.publishEndDate || null,
      }),
    })
      .then(async (res) => {
        if (!res.ok) {
          const error = await res.json();
          alert(error.error || "خطا در انتشار محصول");
          return;
        }
        setShowMarginModal(false);
        fetchProducts();
      })
      .catch((err) => {
        console.error(err);
        alert("خطا در ارتباط با سرور");
      });
  };
  const handleChangeStatus = (id: number, status: string) => {
    fetch(`/api/admin/products/${id}/status`, { credentials: "include",
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      },
      body: JSON.stringify({ status }),
    })
      .then((res) => res.json())
      .then(() => fetchProducts());
  };
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    if (
      !productForm.name ||
      !productForm.categoryId ||
      !productForm.supplierBasePrice
    ) {
      setFormError(
        "نام محصول، دسته‌بندی و قیمت پایه تامین‌کننده الزامی هستند.",
      );
      return;
    }
    try {
      const token = localStorage.getItem("token") || "";
      const url = isEditing
        ? `/api/admin/products/${productForm.id}`
        : "/api/admin/products";
      const method = isEditing ? "PUT" : "POST";
      const res = await fetch(url, { credentials: "include",
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: productForm.name,
          categoryId: parseInt(productForm.categoryId),
          supplierId: productForm.supplierId
            ? parseInt(productForm.supplierId)
            : undefined,
          shortDescription: productForm.shortDescription || null,
          longDescription: productForm.longDescription || null,
          supplierBasePrice: parseFloat(productForm.supplierBasePrice),
          finalPrice: productForm.finalPrice
            ? parseFloat(productForm.finalPrice)
            : null,
          sku: productForm.sku || null,
          brand: productForm.brand || null,
          inventory: parseInt(productForm.inventory) || 0,
          imageUrl: productForm.imageUrl || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || "خطا در ثبت اطلاعات محصول.");
        return;
      }
      setShowAddEditModal(false);
      fetchProducts();
    } catch (err) {
      setFormError("خطا در ارتباط با سرور.");
    }
  };
  const handleDeleteProduct = async (id: number) => {
    if (
      !confirm(
        "آیا از حذف کامل این محصول اطمینان دارید؟ تمامی ارتباطات و کالاهای انتخابی مرتبط نیز حذف خواهند شد.",
      )
    )
      return;
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch(`/api/admin/products/${id}`, { credentials: "include",
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchProducts();
      } else {
        const data = await res.json();
        alert(data.error || "خطا در حذف محصول.");
      }
    } catch (err) {
      alert("خطا در ارتباط با سرور.");
    }
  };
  const openAddModal = () => {
    setIsEditing(false);
    setFormError("");
    const randomSkuNum = Math.floor(100000 + Math.random() * 900000);
    setProductForm({
      id: "",
      name: "",
      categoryId: categories[0]?.id?.toString() || "",
      supplierId: suppliers[0]?.id?.toString() || "",
      shortDescription: "",
      longDescription: "",
      supplierBasePrice: "",
      finalPrice: "",
      sku: `BK-${randomSkuNum}`,
      brand: "",
      inventory: "0",
      imageUrl: "",
    });
    setShowAddEditModal(true);
  };
  const openEditModal = (product: any) => {
    setIsEditing(true);
    setFormError("");
    const randomSkuNum = Math.floor(100000 + Math.random() * 900000);
    setProductForm({
      id: product.id,
      name: product.name || "",
      categoryId: product.categoryId?.toString() || "",
      supplierId: product.supplierId?.toString() || "",
      shortDescription: product.shortDescription || "",
      longDescription: product.longDescription || "",
      supplierBasePrice: product.supplierBasePrice?.toString() || "",
      finalPrice: product.finalPrice?.toString() || "",
      sku: product.sku || `BK-${randomSkuNum}`,
      brand: product.brand || "",
      inventory: product.inventory?.toString() || "0",
      imageUrl: product.images?.[0]?.url || "",
    });
    setShowAddEditModal(true);
  };
  const getStatusLabel = (status: string) => {
    const map: Record<string, string> = {
      DRAFT: "پیش‌نویس",
      PENDING_APPROVAL: "در انتظار تایید",
      ACTIVE: "فعال",
      PUBLISHED: "منتشر شده",
      REJECTED: "رد شده",
      OUT_OF_STOCK: "ناموجود",
      EXPIRED: "منقضی شده",
    };
    return map[status] || status;
  };
  const getStatusColor = (status: string) => {
    switch (status) {
      case "PUBLISHED":
        return "bg-success/20 text-success";
      case "PENDING_APPROVAL":
        return "bg-warning/20 text-warning";
      case "REJECTED":
        return "bg-danger/20 text-danger";
      case "OUT_OF_STOCK":
        return "bg-surface text-secondary";
      default:
        return "bg-surface text-secondary";
    }
  };
  return (
    <div className="p-8 space-y-6 animate-fade-in text-right">
      
      <div className="flex justify-between items-center bg-card p-6 rounded-2xl border border-subtle shadow-sm">
        
        <div>
          
          <h2 className="text-2xl font-bold text-primary">
            مدیریت محصولات و قیمت‌گذاری
          </h2>
          <p className="text-muted mt-1 text-sm">
            بررسی کالاها، قیمت‌گذاری سود، مدیریت کدهای SKU و افزودن مستقیم کالا
            توسط مدیر کل
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-5 py-3 bg-primary-default text-inverse rounded-xl text-sm font-bold hover:bg-primary-hover transition-colors cursor-pointer shadow-lg shadow-primary-default/10"
        >
          
          <Plus className="w-5 h-5" /> افزودن محصول جدید
        </button>
      </div>
      {loading ? (
        <div className="text-center p-12 text-muted bg-card rounded-2xl border border-subtle shadow-sm">
          در حال بارگذاری کالاها...
        </div>
      ) : (
        <div className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden">
          
          <div className="overflow-x-auto">
            
            <table className="w-full text-right text-sm min-w-[1200px]">
              
              <thead className="bg-background border-b border-subtle text-muted font-bold">
                
                <tr>
                  
                  <th className="px-6 py-4">شناسه / پین</th>
                  <th className="px-6 py-4">نام محصول</th>
                  <th className="px-6 py-4 text-xs font-mono">کد (SKU)</th>
                  <th className="px-6 py-4">تامین کننده</th>
                  <th className="px-6 py-4">قیمت پایه (تومان)</th>
                  <th className="px-6 py-4">قیمت نهایی فروش (تومان)</th>
                  <th className="px-6 py-4">وضعیت</th>
                  <th className="px-6 py-4">تغییر وضعیت سریع</th>
                  <th className="px-6 py-4 text-center">عملیات مدیریت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                
                {products.map((product) => (
                  <tr
                    key={product.id}
                    className="hover:bg-background/50 transition-colors"
                  >
                    
                    <td className="px-6 py-4 font-mono text-muted flex items-center gap-1.5">
                      
                      <span>#{product.id}</span>
                      {product.isPinned && (
                        <Pin className="w-4 h-4 text-warning fill-amber-500 inline-block" />
                      )}
                    </td>
                    <td className="px-6 py-4 font-semibold text-primary">
                      
                      <div className="flex items-center gap-3">
                        
                        {product.images?.[0]?.url ? (
                          <img
                            src={product.images[0].url}
                            className="w-10 h-10 object-cover rounded-lg border border-subtle"
                            alt=""
                          />
                        ) : (
                          <div className="w-10 h-10 bg-surface rounded-lg border border-subtle flex items-center justify-center text-muted">
                            
                            <ImageIcon className="w-5 h-5" />
                          </div>
                        )}
                        <div>
                          
                          <div>{product.name}</div>
                          <div className="text-xs text-muted font-normal mt-0.5">
                            موجودی: {product.inventory} عدد
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-mono text-muted bg-background/50 text-xs">
                      
                      {product.sku || (
                        <span className="text-muted">بدون کد</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-muted">
                      
                      {product.supplier?.brandName ||
                        `${product.supplier?.firstName || ""} ${product.supplier?.lastName || ""}` ||
                        "مدیر سیستم"}
                    </td>
                    <td className="px-6 py-4 font-bold text-secondary">
                      {product.supplierBasePrice.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 font-extrabold text-primary-default">
                      
                      {product.finalPrice ? (
                        product.finalPrice.toLocaleString()
                      ) : (
                        <span className="text-muted font-normal text-xs">
                          تعیین نشده
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      
                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getStatusColor(product.status)}`}
                      >
                        
                        {getStatusLabel(product.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      
                      <select
                        className="border border-subtle rounded-lg px-2 py-1 text-xs text-secondary bg-card"
                        value={product.status}
                        onChange={(e) =>
                          handleChangeStatus(product.id, e.target.value)
                        }
                      >
                        
                        <option value="DRAFT">پیش‌نویس</option>
                        <option value="PENDING_APPROVAL">
                          در انتظار تایید
                        </option>
                        <option value="APPROVED">تایید شده</option>
                        <option value="REJECTED">رد شده</option>
                        <option value="PUBLISHED">منتشر شده</option>
                        <option value="OUT_OF_STOCK">ناموجود</option>
                        <option value="EXPIRED">منقضی شده</option>
                      </select>
                    </td>
                    <td className="px-6 py-4">
                      
                      <div className="flex gap-2 justify-center">
                        
                        <button
                          onClick={() => {
                            setSelectedProduct(product);
                            setPublishData({
                              marginType: product.marginType || "PERCENTAGE",
                              marginValue: product.marginValue || 10,
                              publishStartDate: product.publishStartDate
                                ? new Date(product.publishStartDate)
                                    .toISOString()
                                    .slice(0, 16)
                                : "",
                              publishEndDate: product.publishEndDate
                                ? new Date(product.publishEndDate)
                                    .toISOString()
                                    .slice(0, 16)
                                : "",
                              isPinned: product.isPinned || false,
                            });
                            setShowMarginModal(true);
                          }}
                          className="text-success bg-success/10 hover:bg-success/20 px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          
                          <DollarSign className="w-3.5 h-3.5" /> تعیین سود
                        </button>
                        <button
                          onClick={() => openEditModal(product)}
                          className="text-primary-default bg-primary-default/10 hover:bg-primary-default/20 px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          
                          <Edit className="w-3.5 h-3.5" /> ویرایش
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product.id)}
                          className="text-danger bg-danger/10 hover:bg-danger/20 p-1.5 rounded-lg transition-colors"
                          title="حذف کامل محصول"
                        >
                          
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {products.length === 0 && (
                  <tr>
                    
                    <td colSpan={9} className="text-center py-12 text-muted">
                      هیچ محصولی در سیستم یافت نشد.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {/* Pricing and margin setting modal */}
      {showMarginModal && selectedProduct && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          
          <div className="bg-card rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto">
            
            <div className="p-5 border-b border-subtle flex justify-between items-center sticky top-0 bg-card">
              
              <h3 className="font-bold text-lg text-primary">
                تعیین سود و انتشار
              </h3>
              <button
                onClick={() => setShowMarginModal(false)}
                className="text-muted hover:text-muted bg-surface hover:bg-surface p-2 rounded-full transition-colors"
              >
                
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              
              <div className="bg-background p-4 rounded-xl border border-subtle mb-4">
                
                <p className="text-sm font-semibold text-primary">
                  {selectedProduct.name}
                </p>
                <p className="text-xs text-muted mt-1">
                  قیمت پایه تامین‌کننده:
                  {selectedProduct.supplierBasePrice.toLocaleString()} تومان
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-semibold text-secondary mb-1.5">
                    روش قیمت‌گذاری
                  </label>
                  <select
                    value={publishData.marginType}
                    onChange={(e) =>
                      setPublishData({
                        ...publishData,
                        marginType: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                  >
                    
                    <option value="PERCENTAGE">درصد افزایش (٪)</option>
                    <option value="FIXED">افزایش مبلغ ثابت (تومان)</option>
                  </select>
                </div>
                <div>
                  
                  <label className="block text-xs font-semibold text-secondary mb-1.5">
                    
                    {publishData.marginType === "PERCENTAGE"
                      ? "درصد سود"
                      : "مبلغ سود"}
                  </label>
                  <input
                    type="number"
                    value={publishData.marginValue}
                    onChange={(e) =>
                      setPublishData({
                        ...publishData,
                        marginValue: Number(e.target.value),
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-semibold text-secondary mb-1.5">
                    زمان شروع انتشار (اختیاری)
                  </label>
                  <input
                    type="datetime-local"
                    value={publishData.publishStartDate}
                    onChange={(e) =>
                      setPublishData({
                        ...publishData,
                        publishStartDate: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-semibold text-secondary mb-1.5">
                    زمان پایان انتشار (اختیاری)
                  </label>
                  <input
                    type="datetime-local"
                    value={publishData.publishEndDate}
                    onChange={(e) =>
                      setPublishData({
                        ...publishData,
                        publishEndDate: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4">
                
                <input
                  type="checkbox"
                  id="pinProduct"
                  checked={publishData.isPinned}
                  onChange={(e) =>
                    setPublishData({
                      ...publishData,
                      isPinned: e.target.checked,
                    })
                  }
                  className="rounded text-primary-default focus:ring-primary-default"
                />
                <label
                  htmlFor="pinProduct"
                  className="text-sm font-semibold text-secondary"
                >
                  پین کردن محصول (حداکثر 10 کالا)
                </label>
              </div>
              <div className="p-4 bg-success/10 border border-emerald-100 rounded-xl mt-4">
                
                <p className="text-sm text-emerald-800 font-semibold text-center">
                  
                  قیمت نهایی فروش:
                  {(publishData.marginType === "PERCENTAGE"
                    ? selectedProduct.supplierBasePrice *
                      (1 + publishData.marginValue / 100)
                    : selectedProduct.supplierBasePrice +
                      publishData.marginValue
                  ).toLocaleString()}
                  تومان
                </p>
              </div>
              <div className="pt-4 flex gap-3">
                
                <button
                  onClick={() => setShowMarginModal(false)}
                  className="flex-1 px-4 py-3 bg-surface text-secondary rounded-xl font-medium text-sm hover:bg-surface transition-colors cursor-pointer"
                >
                  
                  انصراف
                </button>
                <button
                  onClick={handlePublish}
                  className="flex-1 px-4 py-3 bg-primary-default text-inverse rounded-xl font-medium text-sm hover:bg-primary-hover transition-colors cursor-pointer"
                >
                  
                  ذخیره و انتشار محصول
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Direct Add or Edit product modal (Form Modal) */}
      {showAddEditModal && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          
          <div className="bg-card rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
            
            <div className="p-5 border-b border-subtle flex justify-between items-center sticky top-0 bg-card">
              
              <h3 className="font-bold text-lg text-primary">
                {isEditing ? "ویرایش کالا" : "افزودن مستقیم کالا"}
              </h3>
              <button
                onClick={() => setShowAddEditModal(false)}
                className="text-muted hover:text-muted bg-surface hover:bg-surface p-2 rounded-full transition-colors"
              >
                
                <X className="w-5 h-5" />
              </button>
            </div>
            <form
              onSubmit={handleSaveProduct}
              className="flex-1 overflow-y-auto p-6 space-y-4"
            >
              
              {formError && (
                <div className="bg-danger/10 border border-rose-100 text-danger p-4 rounded-xl flex items-start gap-2.5 text-sm">
                  
                  <AlertCircle className="w-5 h-5 text-danger flex-shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    نام محصول *
                  </label>
                  <input
                    type="text"
                    required
                    value={productForm.name}
                    onChange={(e) =>
                      setProductForm({ ...productForm, name: e.target.value })
                    }
                    placeholder="مثال: گوشی آیفون ۱۵ پرو"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    دسته‌بندی محصول *
                  </label>
                  <select
                    required
                    value={productForm.categoryId}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        categoryId: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                  >
                    
                    <option value="">انتخاب دسته‌بندی...</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    تامین کننده (اختیاری)
                  </label>
                  <select
                    value={productForm.supplierId}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        supplierId: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                  >
                    
                    <option value="">
                      مدیر سیستم (تامین‌کننده پیش‌فرض)
                    </option>
                    {suppliers.map((sup) => (
                      <option key={sup.id} value={sup.id}>
                        {sup.brandName ||
                          `${sup.firstName || ""} ${sup.lastName || ""}`}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    برند محصول
                  </label>
                  <input
                    type="text"
                    value={productForm.brand}
                    onChange={(e) =>
                      setProductForm({ ...productForm, brand: e.target.value })
                    }
                    placeholder="مثال: Apple"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    قیمت پایه تامین‌کننده (تومان) *
                  </label>
                  <input
                    type="number"
                    required
                    value={productForm.supplierBasePrice}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        supplierBasePrice: e.target.value,
                      })
                    }
                    placeholder="قیمت تسویه با تامین‌کننده"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    قیمت نهایی فروش (تومان) (اختیاری)
                  </label>
                  <input
                    type="number"
                    value={productForm.finalPrice}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        finalPrice: e.target.value,
                      })
                    }
                    placeholder="خالی بگذارید تا بعداً تعیین سود کنید"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    موجودی انبار *
                  </label>
                  <input
                    type="number"
                    required
                    value={productForm.inventory}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        inventory: e.target.value,
                      })
                    }
                    placeholder="تعداد موجودی"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    کد محصول (SKU) (مدیر کل)
                  </label>
                  <input
                    type="text"
                    value={productForm.sku}
                    onChange={(e) =>
                      setProductForm({ ...productForm, sku: e.target.value })
                    }
                    placeholder="مثال: APP-IPH15-PRO"
                    className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default font-mono"
                    dir="ltr"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1.5">
                    تصویر کالا
                  </label>
                  <div className="flex gap-2">
                    
                    <input
                      type="text"
                      value={productForm.imageUrl}
                      onChange={(e) =>
                        setProductForm({
                          ...productForm,
                          imageUrl: e.target.value,
                        })
                      }
                      placeholder="https://example.com/image.png"
                      className="flex-1 px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
                      dir="ltr"
                    />
                    <label className="cursor-pointer bg-surface hover:bg-surface border border-subtle text-muted px-4 py-2.5 rounded-xl text-sm font-medium transition-colors flex items-center justify-center whitespace-nowrap">
                      
                      <span>انتخاب فایل</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            if (file.size > 2 * 1024 * 1024) {
                              alert("حجم تصویر نباید بیشتر از 2 مگابایت باشد.");
                              return;
                            }
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              setProductForm({
                                ...productForm,
                                imageUrl: reader.result as string,
                              });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>
                  {productForm.imageUrl &&
                    productForm.imageUrl.startsWith("data:image") && (
                      <div className="mt-2 text-xs text-success font-medium">
                        تصویر با موفقیت بارگذاری شد
                      </div>
                    )}
                </div>
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-1.5">
                  معرفی کوتاه کالا
                </label>
                <textarea
                  value={productForm.shortDescription}
                  onChange={(e) =>
                    setProductForm({
                      ...productForm,
                      shortDescription: e.target.value,
                    })
                  }
                  placeholder="یک خلاصه کوتاه چند کلمه‌ای..."
                  className="w-full px-4 py-2 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default h-16 resize-none"
                />
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-1.5">
                  توضیحات و مشخصات کامل فنی
                </label>
                <textarea
                  value={productForm.longDescription}
                  onChange={(e) =>
                    setProductForm({
                      ...productForm,
                      longDescription: e.target.value,
                    })
                  }
                  placeholder="مشخصات کامل کالا را در این قسمت وارد نمایید..."
                  className="w-full px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default h-28 resize-none"
                />
              </div>
              <div className="pt-4 border-t border-subtle flex gap-3 sticky bottom-0 bg-card">
                
                <button
                  type="button"
                  onClick={() => setShowAddEditModal(false)}
                  className="flex-1 px-4 py-3 bg-surface text-secondary rounded-xl font-medium text-sm hover:bg-surface transition-colors cursor-pointer"
                >
                  
                  انصراف
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-primary-default text-inverse rounded-xl font-medium text-sm hover:bg-primary-hover transition-colors cursor-pointer"
                >
                  
                  {isEditing ? "ذخیره تغییرات" : "ثبت و انتشار فوری کالا"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
