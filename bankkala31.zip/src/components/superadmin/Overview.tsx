import React, { useState, useEffect } from "react";
import {
  Users,
  Store,
  Package,
  ShoppingCart,
  Wallet,
  TrendingUp,
  AlertCircle,
  Ban,
  FileText,
  CheckCircle,
  XCircle,
  PlusCircle,
  ArrowUpRight,
  Activity,
  Clock,
  ShieldCheck,
  Check,
  X,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";
export default function Overview(): React.ReactElement {
  const [stats, setStats] = useState<any>(null);
  const [stores, setStores] = useState<any[]>([]);
  const [pendingInvoices, setPendingInvoices] = useState<any[]>([]);
  const [pendingSettlements, setPendingSettlements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  // Pro-forma form state
  const [selectedStore, setSelectedStore] = useState("");
  const [invoiceAmount, setInvoiceAmount] = useState("");
  const [invoiceNotes, setInvoiceNotes] = useState("");
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState("");
  const [formError, setFormError] = useState("");
  /* Action submitting state */ const [actioningId, setActioningId] = useState<
    string | null
  >(null);
  const fetchStats = () => {
    return fetch("/api/admin/stats", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => setStats(data));
  };
  const fetchStores = () => {
    return fetch("/api/admin/stores", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => setStores(Array.isArray(data) ? data : []));
  };
  const fetchPendingInvoices = () => {
    return fetch("/api/admin/manual-invoices", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        const list = Array.isArray(data) ? data : [];
        // filter only pending ones
        setPendingInvoices(
          list.filter(
            (inv: any) =>
              inv.receiptStatus === "PENDING" && inv.status !== "PAID",
          ),
        );
      });
  };
  const fetchPendingSettlements = () => {
    return fetch("/api/admin/settlements", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        const list = Array.isArray(data) ? data : [];
        setPendingSettlements(list.filter((s: any) => s.status === "PENDING"));
      });
  };
  useEffect(() => {
    Promise.all([
      fetchStats(),
      fetchStores(),
      fetchPendingInvoices(),
      fetchPendingSettlements(),
    ])
      .catch((err) => console.error("Error fetching admin overview data:", err))
      .finally(() => setLoading(false));
  }, []);
  const handleCreateProforma = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStore || !invoiceAmount) {
      setFormError("لطفاً فروشگاه و مبلغ پیش‌فاکتور را مشخص کنید.");
      return;
    }
    setFormSubmitting(true);
    setFormError("");
    setFormSuccess("");
    try {
      const res = await fetch("/api/admin/create-proforma", { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          
        },
        body: JSON.stringify({
          storeManagerId: selectedStore,
          totalAmount: parseFloat(invoiceAmount),
          notes: invoiceNotes,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setFormSuccess(
          "پیش‌فاکتور با موفقیت صادر و در بخش تایید فیش‌ها ثبت شد.",
        );
        setInvoiceAmount("");
        setInvoiceNotes("");
        setSelectedStore("");
        fetchStats();
        fetchPendingInvoices();
      } else {
        setFormError(data.error || "خطا در صدور پیش‌فاکتور");
      }
    } catch (err) {
      setFormError("خطای شبکه در ارتباط با سرور");
    } finally {
      setFormSubmitting(false);
    }
  };
  const handleInvoiceAction = async (
    invoiceId: number,
    action: "approve" | "reject",
  ) => {
    setActioningId(`invoice-${invoiceId}`);
    try {
      const res = await fetch(
        `/api/admin/manual-invoices/${invoiceId}/${action}`, { credentials: "include",
          method: "POST",
          headers: { /* Auth Header Removed */ },
        },
      );
      if (res.ok) {
        await Promise.all([fetchStats(), fetchPendingInvoices()]);
      } else {
        alert("خطا در انجام عملیات روی فیش");
      }
    } catch (err) {
      alert("خطای شبکه در انجام عملیات");
    } finally {
      setActioningId(null);
    }
  };
  const handleSettlementAction = async (
    id: number,
    action: "approve" | "reject",
  ) => {
    setActioningId(`settlement-${id}`);
    try {
      const url = `/api/admin/settlements/${id}/${action}`;
      const res = await fetch(url, { credentials: "include",
        method: "POST",
        headers: { /* Auth Header Removed */ },
      });
      if (res.ok) {
        await Promise.all([fetchStats(), fetchPendingSettlements()]);
      } else {
        alert("خطا در انجام عملیات روی درخواست تسویه");
      }
    } catch (err) {
      alert("خطای شبکه در انجام عملیات");
    } finally {
      setActioningId(null);
    }
  };
  if (loading) {
    return (
      <div className="p-8 space-y-6">
        
        <div className="h-10 w-48 bg-surface rounded-lg animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="h-28 bg-surface rounded-2xl animate-pulse"
            ></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          <div className="h-80 bg-surface rounded-2xl animate-pulse"></div>
          <div className="h-80 bg-surface rounded-2xl animate-pulse"></div>
        </div>
      </div>
    );
  }
  const statCards = [
    {
      label: "تامین کنندگان فعال",
      value: stats?.suppliers || 0,
      icon: Users,
      color: "text-primary-default",
      bg: "bg-primary-default/10/70",
      border: "border-primary-default/20",
    },
    {
      label: "فروشگاه‌های همکار",
      value: stats?.stores || 0,
      icon: Store,
      color: "text-success",
      bg: "bg-success/10/70",
      border: "border-emerald-100",
    },
    {
      label: "محصولات سامانه",
      value: stats?.activeProducts || 0,
      icon: Package,
      color: "text-blue-600",
      bg: "bg-surface/70",
      border: "border-blue-100",
    },
    {
      label: "کل سفارشات ثبت‌شده",
      value: stats?.orders || 0,
      icon: ShoppingCart,
      color: "text-warning",
      bg: "bg-warning/10/70",
      border: "border-amber-100",
    },
    {
      label: "درآمد کل پلتفرم",
      value: (stats?.totalRevenue || 0).toLocaleString() + " تومان",
      icon: Wallet,
      color: "text-danger",
      bg: "bg-danger/10/70",
      border: "border-rose-100",
    },
  ];
  /* Mock data for charts */ const revenueData = [
    { name: "فروردین", درآمد: 4000000 },
    { name: "اردیبهشت", درآمد: 3000000 },
    { name: "خرداد", درآمد: 5000000 },
    { name: "تیر", درآمد: 2780000 },
    { name: "مرداد", درآمد: 8900000 },
    { name: "شهریور", درآمد: 4390000 },
  ];
  const salesData = [
    { name: "شنبه", سفارشات: 120 },
    { name: "یکشنبه", سفارشات: 200 },
    { name: "دوشنبه", سفارشات: 150 },
    { name: "سه شنبه", سفارشات: 280 },
    { name: "چهارشنبه", سفارشات: 210 },
    { name: "پنجشنبه", سفارشات: 390 },
    { name: "جمعه", سفارشات: 450 },
  ];
  return (
    <div className="p-6 lg:p-8 space-y-8 animate-fade-in" dir="rtl">
      
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-6 bg-gradient-to-r from-indigo-700 to-purple-800 rounded-3xl text-white shadow-xl shadow-indigo-900/20 relative overflow-hidden">
        
        <div className="absolute top-0 right-0 w-80 h-80 bg-primary-default/25 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          
          <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight">
            به مرکز فرماندهی خوش آمدید 👋
          </h2>
          <p className="text-purple-100/90 mt-1.5 text-sm lg:text-base font-medium">
            نمای یکپارچه، ابزارهای کنترلی پیشرفته و مدیریت مالی کل زنجیره تامین
          </p>
        </div>
        <div className="flex gap-3 relative z-10">
          
          <div className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/15 rounded-xl text-xs font-semibold backdrop-blur-sm border border-white/10 transition-colors text-white">
            
            <Activity className="w-4 h-4 text-success animate-pulse" />
            سیستم آنلاین است
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-primary-default hover:bg-primary-hover rounded-xl text-xs font-bold shadow-lg shadow-primary-default/30 transition-all cursor-pointer text-white">
            
            <ShieldCheck className="w-4 h-4 text-purple-200" /> سطح دسترسی: مدیر
            کل
          </div>
        </div>
      </div>
      {/* Stats Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
        
        {statCards.map((stat, i) => (
          <div
            key={i}
            className="bg-gradient-to-br from-card to-background p-6 rounded-2xl shadow-sm border border-subtle flex items-center justify-between hover:shadow-lg hover:border-primary-default/30 transition-all duration-300 group hover:-translate-y-1 relative overflow-hidden cursor-pointer"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-primary-default/5 to-transparent rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            
            <div className="space-y-1.5 relative z-10">
              
              <p className="text-xs text-muted font-extrabold tracking-wide uppercase block">
                {stat.label}
              </p>
              <p className="text-2xl font-black text-primary font-mono tracking-tight group-hover:text-primary-hover transition-colors">
                
                {stat.value}
              </p>
            </div>
            <div
              className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:shadow-md relative z-10`}
            >
              
              <stat.icon className="w-5.5 h-5.5" />
            </div>
          </div>
        ))}
      </div>
      {/* Main Grid: Interactive Form & Supplier Requests Oversight */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Pro-forma Invoice Form */}
        <div className="lg:col-span-5 bg-gradient-to-br from-card via-card to-background p-8 rounded-3xl shadow-md border border-subtle flex flex-col justify-between">
          
          <div>
            
            <div className="flex items-center gap-3 mb-4">
              
              <div className="p-2.5 bg-primary-default/10 text-primary-default rounded-xl">
                
                <FileText className="w-5 h-5" />
              </div>
              <div>
                
                <h3 className="text-lg font-bold text-primary">
                  تعریف و صدور پیش‌فاکتور جدید
                </h3>
                <p className="text-xs text-muted">
                  ثبت مستقیم پیش‌فاکتور دستی برای مدیران فروشگاه جهت تسویه
                </p>
              </div>
            </div>
            <form onSubmit={handleCreateProforma} className="space-y-4.5 mt-6">
              
              <div>
                
                <label className="block text-xs font-bold text-muted mb-2">
                  انتخاب فروشگاه مقصد
                </label>
                <select
                  value={selectedStore}
                  onChange={(e) => setSelectedStore(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none"
                >
                  
                  <option value="">-- انتخاب فروشگاه --</option>
                  {stores.map((store: any) => (
                    <option key={store.id} value={store.id}>
                      
                      {store.storeName ||
                        store.brandName ||
                        `${store.firstName} ${store.lastName}`}
                      (ID: {store.id})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                
                <label className="block text-xs font-bold text-muted mb-2">
                  مبلغ پیش‌فاکتور (تومان)
                </label>
                <div className="relative">
                  
                  <input
                    type="number"
                    placeholder="مثال: 4500000"
                    value={invoiceAmount}
                    onChange={(e) => setInvoiceAmount(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-background border border-subtle rounded-xl text-sm font-mono font-bold focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none"
                  />
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-bold text-muted">
                    تومان
                  </span>
                </div>
              </div>
              <div>
                
                <label className="block text-xs font-bold text-muted mb-2">
                  توضیحات و بابت (یادداشت پیش‌فاکتور)
                </label>
                <textarea
                  placeholder="توضیحات پیش‌فاکتور مانند بابت پیش‌خرید کالا..."
                  rows={3}
                  value={invoiceNotes}
                  onChange={(e) => setInvoiceNotes(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none resize-none"
                ></textarea>
              </div>
              {formError && (
                <div className="p-3 bg-danger/10 text-danger rounded-xl text-xs font-bold flex items-center gap-2 border border-rose-100">
                  
                  <AlertCircle className="w-4 h-4 shrink-0" /> {formError}
                </div>
              )}
              {formSuccess && (
                <div className="p-3 bg-success/10 text-success rounded-xl text-xs font-bold flex items-center gap-2 border border-emerald-100">
                  
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  {formSuccess}
                </div>
              )}
              <button
                type="submit"
                disabled={formSubmitting}
                className="w-full py-3.5 bg-primary-default hover:bg-primary-hover disabled:bg-surface text-white font-bold text-sm rounded-xl shadow-lg shadow-primary-default/10 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01]"
              >
                
                <PlusCircle className="w-5 h-5" />
                {formSubmitting
                  ? "در حال صدور..."
                  : "تایید و صدور پیش‌فاکتور"}
              </button>
            </form>
          </div>
        </div>
        {/* Supplier Requests / Action Items */}
        <div className="lg:col-span-7 bg-card p-6 rounded-3xl shadow-sm border border-subtle flex flex-col justify-between">
          
          <div>
            
            <div className="flex items-center justify-between mb-6">
              
              <div className="flex items-center gap-3">
                
                <div className="p-2.5 bg-warning/10 text-warning rounded-xl">
                  
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  
                  <h3 className="text-lg font-bold text-primary">
                    درخواست‌های تامین‌کنندگان و تایید فیش‌ها
                  </h3>
                  <p className="text-xs text-muted">
                    بررسی و اقدام سریع روی درخواست‌های مالی معلق سیستم
                  </p>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-surface text-muted rounded-full text-xs font-bold font-mono">
                
                {pendingInvoices.length + pendingSettlements.length} معلق
              </span>
            </div>
            <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1">
              
              {pendingInvoices.length === 0 &&
              pendingSettlements.length === 0 ? (
                <div className="py-12 text-center flex flex-col items-center justify-center text-muted">
                  
                  <CheckCircle className="w-12 h-12 text-success mb-3" />
                  <p className="font-bold text-sm">
                    هیچ درخواست معلقی وجود ندارد!
                  </p>
                  <p className="text-xs text-muted mt-1">
                    کلیه فیش‌ها و درخواست‌های تسویه حساب بررسی شده‌اند.
                  </p>
                </div>
              ) : (
                <>
                  
                  {/* Pending Receipts */}
                  {pendingInvoices.map((inv) => (
                    <div
                      key={`inv-${inv.id}`}
                      className="p-4 rounded-2xl border border-subtle bg-background/50 hover:bg-background transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      
                      <div className="space-y-1">
                        
                        <div className="flex items-center gap-2">
                          
                          <span className="px-2 py-0.5 bg-primary-default/20 text-primary-hover text-[10px] font-bold rounded-md">
                            تایید فیش بانکی
                          </span>
                          <span className="text-xs font-mono font-bold text-muted">
                            INV-{inv.id}
                          </span>
                        </div>
                        <p className="text-sm font-bold text-primary">
                          
                          مبلغ: {inv.totalAmount.toLocaleString()} تومان
                        </p>
                        <p className="text-xs text-muted">
                          
                          فروشگاه:
                          <span className="font-semibold text-secondary">
                            {inv.storeManager?.storeName || "نامشخص"}
                          </span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        
                        {inv.receiptUrl && (
                          <a
                            href={inv.receiptUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 bg-surface hover:bg-surface text-secondary font-bold text-xs rounded-xl transition-colors"
                          >
                            
                            مشاهده فیش
                          </a>
                        )}
                        <button
                          disabled={actioningId !== null}
                          onClick={() => handleInvoiceAction(inv.id, "approve")}
                          className="w-8 h-8 rounded-xl bg-success hover:bg-success disabled:bg-surface text-white flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                          title="تایید فیش"
                        >
                          
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          disabled={actioningId !== null}
                          onClick={() => handleInvoiceAction(inv.id, "reject")}
                          className="w-8 h-8 rounded-xl bg-danger hover:bg-danger disabled:bg-surface text-white flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                          title="رد فیش"
                        >
                          
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                  {/* Pending Settlements */}
                  {pendingSettlements.map((settle) => (
                    <div
                      key={`settle-${settle.id}`}
                      className="p-4 rounded-2xl border border-subtle bg-background/50 hover:bg-background transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      
                      <div className="space-y-1">
                        
                        <div className="flex items-center gap-2">
                          
                          <span className="px-2 py-0.5 bg-warning/20 text-warning text-[10px] font-bold rounded-md">
                            درخواست تسویه تامین‌کننده
                          </span>
                          <span className="text-xs font-mono font-bold text-muted">
                            SET-{settle.id}
                          </span>
                        </div>
                        <p className="text-sm font-bold text-primary">
                          
                          مبلغ تسویه: {settle.amount.toLocaleString()}
                          تومان
                        </p>
                        <p className="text-xs text-muted">
                          
                          تامین‌کننده:
                          <span className="font-semibold text-secondary">
                            {settle.supplier?.brandName ||
                              settle.supplier?.firstName +
                                "" +
                                settle.supplier?.lastName}
                          </span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        
                        <button
                          disabled={actioningId !== null}
                          onClick={() =>
                            handleSettlementAction(settle.id, "approve")
                          }
                          className="w-8 h-8 rounded-xl bg-success hover:bg-success disabled:bg-surface text-white flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                          title="تایید تسویه"
                        >
                          
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          disabled={actioningId !== null}
                          onClick={() =>
                            handleSettlementAction(settle.id, "reject")
                          }
                          className="w-8 h-8 rounded-xl bg-danger hover:bg-danger disabled:bg-surface text-white flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                          title="رد تسویه"
                        >
                          
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <div className="bg-card p-6 rounded-3xl shadow-sm border border-subtle flex flex-col">
          
          <h3 className="text-lg font-bold text-primary mb-6">
            روند درآمد پلتفرم (۶ ماه اخیر)
          </h3>
          <div className="flex-1 w-full h-72">
            
            <ResponsiveContainer width="100%" height="100%">
              
              <AreaChart
                data={revenueData}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                
                <defs>
                  
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    
                    <stop
                      offset="5%"
                      stopColor="#4f46e5"
                      stopOpacity={0.3}
                    />
                    <stop
                      offset="95%"
                      stopColor="#4f46e5"
                      stopOpacity={0}
                    />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="name"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12 }}
                  tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
                />
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#e2e8f0"
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                  }}
                  formatter={(value: number) => [
                    value.toLocaleString() + " تومان",
                    "درآمد",
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="درآمد"
                  stroke="#4f46e5"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-card p-6 rounded-3xl shadow-sm border border-subtle flex flex-col">
          
          <h3 className="text-lg font-bold text-primary mb-6">
            تعداد سفارشات در هفته جاری
          </h3>
          <div className="flex-1 w-full h-72">
            
            <ResponsiveContainer width="100%" height="100%">
              
              <BarChart
                data={salesData}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                barSize={32}
              >
                
                <XAxis
                  dataKey="name"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#64748b", fontSize: 12 }}
                />
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#e2e8f0"
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: "12px",
                    border: "none",
                    boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                  }}
                  cursor={{ fill: "#f1f5f9" }}
                />
                <Bar
                  dataKey="سفارشات"
                  fill="#0ea5e9"
                  radius={[6, 6, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
