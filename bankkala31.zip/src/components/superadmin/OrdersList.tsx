import React, { useState, useEffect } from "react";
import {
  Download,
  Search,
  Upload,
  MapPin,
  Truck,
  Check,
  X,
  AlertCircle,
  FileText,
} from "lucide-react";
export default function OrdersList() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"all" | "platform" | "personal">(
    "all",
  );
  const [searchQuery, setSearchQuery] = useState("");
  // Postal Label modal
  const [labelOrderId, setLabelOrderId] = useState<number | null>(null);
  const [labelValue, setLabelValue] = useState("");
  const [submittingLabel, setSubmittingLabel] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fetchOrders = () => {
    setLoading(true);
    fetch("/api/admin/orders", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setOrders(data);
        else setOrders([]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };
  useEffect(() => {
    fetchOrders();
  }, []);
  const handleUploadLabelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!labelOrderId || !labelValue.trim()) return;
    setSubmittingLabel(true);
    setSuccessMsg(null);
    setErrorMsg(null);
    try {
      const res = await fetch(
        `/api/admin/orders/${labelOrderId}/postal-label`, { credentials: "include",
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            
          },
          body: JSON.stringify({ postalLabel: labelValue }),
        },
      );
      const data = await res.json();
      if (res.ok) {
        setSuccessMsg("لیبل پستی با موفقیت برای این سفارش ثبت شد.");
        setLabelValue("");
        setTimeout(() => {
          setLabelOrderId(null);
          setSuccessMsg(null);
        }, 1500);
        fetchOrders();
      } else {
        setErrorMsg(data.error || "خطا در ثبت لیبل پستی");
      }
    } catch (err) {
      setErrorMsg("خطای شبکه در ارتباط با سرور.");
    } finally {
      setSubmittingLabel(false);
    }
  };
  const handleExportCSV = () => {
    if (orders.length === 0) {
      alert("هیچ سفارشی برای خروجی گرفتن وجود ندارد.");
      return;
    }
    const headers = [
      "شناسه سفارش",
      "نام محصول",
      "تعداد",
      "مبلغ کل (تومان)",
      "وضعیت",
      "نوع پنل پستی",
      "آدرس گیرنده",
      "برند تامین‌کننده",
      "آدرس مبدأ تامین‌کننده",
    ];
    const rows = orders.map((o) => {
      const item = o.items?.[0];
      return [
        o.id,
        item?.product?.name || "محصول حذف شده",
        item?.quantity || 1,
        o.totalAmount || 0,
        o.status,
        o.shippingMethod === "PERSONAL_PANEL" ? "پنل شخصی" : "پنل مجموعه",
        o.shippingAddress || "آدرس پیشفرض فروشگاه",
        item?.product?.supplier?.brandName || "نامشخص",
        item?.product?.supplier?.address || "ثبت نشده",
      ];
    });
    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(","),
      ),
    ].join("\n");
    const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `کل_سفارشات_مجموعه.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  // Filter orders based on active tab and search query
  const filteredOrders = orders.filter((o) => {
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "platform" && o.shippingMethod === "PLATFORM_PANEL") ||
      (activeTab === "personal" && o.shippingMethod === "PERSONAL_PANEL");
    const searchLower = searchQuery.toLowerCase();
    const orderItem = o.items?.[0];
    const productName = orderItem?.product?.name || "";
    const supplierBrand = orderItem?.product?.supplier?.brandName || "";
    const storeName = o.store?.storeName || "";
    const matchesSearch =
      searchQuery === "" ||
      o.id.toString().includes(searchLower) ||
      productName.toLowerCase().includes(searchLower) ||
      supplierBrand.toLowerCase().includes(searchLower) ||
      storeName.toLowerCase().includes(searchLower);
    return matchesTab && matchesSearch;
  });
  return (
    <div className="p-8 space-y-6 animate-fade-in" dir="rtl">
      
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        
        <div>
          
          <h2 className="text-2xl font-black text-primary">
            مدیریت سفارشات کل سیستم
          </h2>
          <p className="text-muted mt-1.5 text-sm">
            پیگیری، تعیین و بارگذاری لیبل‌های پستی و آدرس‌های مبدأ/مقصد
            مرسوله‌ها
          </p>
        </div>
        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 bg-primary-default hover:bg-primary-hover text-inverse px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-primary-default/15 transition-all cursor-pointer"
        >
          
          <Download className="w-4.5 h-4.5" /> خروجی جامع سفارشات
        </button>
      </div>
      {/* Tabs and Search Bar row */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center bg-card p-4 rounded-2xl border border-subtle shadow-sm">
        
        {/* Tab filters */}
        <div className="flex gap-1.5 bg-background p-1 rounded-xl border border-subtle/50">
          
          <button
            onClick={() => setActiveTab("all")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeTab === "all" ? "bg-card text-primary-hover shadow-sm" : "text-muted hover:text-primary"}`}
          >
            
            همه سفارشات ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab("platform")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeTab === "platform" ? "bg-card text-primary-hover shadow-sm border border-subtle" : "text-muted hover:text-primary"}`}
          >
            
            پنل پستی مجموعه (
            {orders.filter((o) => o.shippingMethod === "PLATFORM_PANEL").length}
            )
          </button>
          <button
            onClick={() => setActiveTab("personal")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeTab === "personal" ? "bg-card text-primary-hover shadow-sm border border-subtle" : "text-muted hover:text-primary"}`}
          >
            
            پنل اختصاصی (
            {orders.filter((o) => o.shippingMethod === "PERSONAL_PANEL").length}
            )
          </button>
        </div>
        {/* Search */}
        <div className="relative min-w-[280px]">
          
          <input
            type="text"
            className="w-full bg-background border border-subtle rounded-xl pl-4 pr-10 py-2.5 text-xs focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none font-bold"
            placeholder="جستجو بر اساس سفارش، کالا، تامین‌کننده یا فروشگاه..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="w-4 h-4 text-muted absolute right-3.5 top-3.5" />
        </div>
      </div>
      {/* Main orders list table */}
      {loading ? (
        <div className="text-center py-20 bg-card rounded-3xl border border-subtle shadow-sm text-muted font-bold">
          
          <div className="animate-spin inline-block w-8 h-8 border-4 border-primary-default border-t-transparent rounded-full mb-3"></div>
          <div>در حال بارگذاری لیست سفارشات...</div>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="text-center py-16 bg-card rounded-3xl border border-subtle shadow-sm text-muted">
          
          <Truck className="w-16 h-16 mx-auto text-inverse mb-4" />
          <p className="text-lg font-bold text-primary">هیچ سفارشی یافت نشد</p>
          <p className="text-sm text-muted mt-1">
            سفارشی مطابق با فیلتر انتخاب شده وجود ندارد.
          </p>
        </div>
      ) : (
        <div className="bg-card rounded-3xl shadow-sm border border-subtle overflow-hidden">
          
          <div className="overflow-x-auto">
            
            <table className="w-full text-right text-sm">
              
              <thead className="bg-background border-b border-subtle text-muted font-bold">
                
                <tr>
                  
                  <th className="px-6 py-4">کد سفارش</th>
                  <th className="px-6 py-4">جزئیات مرسوله</th>
                  <th className="px-6 py-4">مبدأ (تامین‌کننده)</th>
                  <th className="px-6 py-4">مقصد (فروشگاه)</th>
                  <th className="px-6 py-4">پنل پستی</th>
                  <th className="px-6 py-4">وضعیت</th>
                  <th className="px-6 py-4 text-center">عملیات لیبل</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                
                {filteredOrders.map((o) => {
                  const item = o.items?.[0];
                  const product = item?.product;
                  const supplier = product?.supplier;
                  return (
                    <tr
                      key={o.id}
                      className="hover:bg-background/50 transition-colors"
                    >
                      
                      {/* ID */}
                      <td className="px-6 py-4 font-mono font-bold text-primary-default">
                        #{o.id}
                      </td>
                      {/* Product details */}
                      <td className="px-6 py-4">
                        
                        <div className="font-extrabold text-primary">
                          {product?.name || "محصول حذف شده"}
                        </div>
                        <div className="text-xs text-muted font-medium mt-1 flex gap-2">
                          
                          <span>تعداد: {item?.quantity || 1}</span>
                          <span>|</span>
                          <span>SKU: {product?.sku || "-"}</span>
                        </div>
                        <div className="text-xs text-primary-hover font-extrabold mt-1">
                          
                          {o.totalAmount?.toLocaleString()} تومان
                        </div>
                      </td>
                      {/* Origin (Supplier) */}
                      <td className="px-6 py-4">
                        
                        <div className="font-bold text-primary">
                          {supplier?.brandName || "نامشخص"}
                        </div>
                        <div className="text-xs text-muted mt-1.5 flex flex-col gap-0.5 max-w-[200px]">
                          
                          <span className="font-semibold text-secondary">
                            نام:
                            {supplier
                              ? `${supplier.firstName} ${supplier.lastName}`
                              : "نامشخص"}
                          </span>
                          <span
                            className="text-[11px] leading-relaxed truncate"
                            title={supplier?.address}
                          >
                            
                            آدرس:
                            {supplier?.address || "بدون آدرس ثبت شده"}
                          </span>
                        </div>
                      </td>
                      {/* Destination (Store Manager) */}
                      <td className="px-6 py-4">
                        
                        <div className="font-bold text-primary">
                          {o.store?.storeName || "نامشخص"}
                        </div>
                        <div className="text-xs text-muted mt-1.5 flex flex-col gap-0.5 max-w-[200px]">
                          
                          <span className="font-semibold text-secondary">
                            نام:
                            {o.store
                              ? `${o.store.firstName} ${o.store.lastName}`
                              : "نامشخص"}
                          </span>
                          <span
                            className="text-[11px] leading-relaxed truncate"
                            title={o.shippingAddress}
                          >
                            
                            آدرس:
                            {o.shippingAddress || "آدرس رسمی فروشگاه"}
                          </span>
                        </div>
                      </td>
                      {/* Postage Method */}
                      <td className="px-6 py-4">
                        
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-bold ${o.shippingMethod === "PERSONAL_PANEL" ? "bg-warning/10 text-warning border border-amber-100" : "bg-primary-default/10 text-primary-hover border border-primary-default/20"}`}
                        >
                          
                          {o.shippingMethod === "PERSONAL_PANEL"
                            ? "پنل شخصی"
                            : "پنل مجموعه"}
                        </span>
                      </td>
                      {/* Status */}
                      <td className="px-6 py-4">
                        
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-bold ${o.status === "REQUESTED" ? "bg-warning/20 text-warning" : o.status === "PAID" ? "bg-success/20 text-success" : o.status === "PREPARING" ? "bg-blue-100 text-blue-700" : o.status === "COMPLETED" ? "bg-success/20 text-success" : "bg-surface text-secondary"}`}
                        >
                          
                          {o.status === "REQUESTED"
                            ? "در انتظار بررسی"
                            : o.status === "PAID"
                              ? "پرداخت شده"
                              : o.status === "PREPARING"
                                ? "آماده‌سازی"
                                : o.status === "COMPLETED"
                                  ? "تحویل شده"
                                  : o.status}
                        </span>
                      </td>
                      {/* Action (Postal Label Upload) */}
                      <td className="px-6 py-4 text-center">
                        
                        <div className="flex flex-col items-center gap-1.5 justify-center">
                          
                          {o.postalLabel ? (
                            <div className="flex flex-col items-center gap-1">
                              
                              <span className="text-[10px] text-success font-bold">
                                ✓ لیبل ثبت شده
                              </span>
                              <a
                                href={o.postalLabel}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-primary-default hover:underline font-bold"
                              >
                                
                                مشاهده لیبل
                              </a>
                              <button
                                onClick={() => {
                                  setLabelOrderId(o.id);
                                  setLabelValue(o.postalLabel || "");
                                }}
                                className="text-[10px] text-muted hover:text-muted underline"
                              >
                                
                                ویرایش لیبل
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setLabelOrderId(o.id);
                                setLabelValue("");
                              }}
                              className="flex items-center gap-1 text-xs bg-primary-default/10 hover:bg-primary-default/20 text-primary-hover px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer"
                            >
                              
                              <Upload className="w-3.5 h-3.5" /> بارگذاری لیبل
                              پستی
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {/* Upload Postal Label Modal */}
      {labelOrderId && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          
          <div
            className="bg-card rounded-3xl w-full max-w-md shadow-2xl p-6 lg:p-8 relative"
            onClick={(e) => e.stopPropagation()}
          >
            
            <div className="flex justify-between items-center mb-6">
              
              <h3 className="text-lg font-bold text-primary">
                بارگذاری لیبل پستی برای سفارش #{labelOrderId}
              </h3>
              <button
                onClick={() => setLabelOrderId(null)}
                className="text-muted hover:bg-surface p-2 rounded-full cursor-pointer"
              >
                
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUploadLabelSubmit} className="space-y-4">
              
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  لینک فایل یا کد پیگیری لیبل پستی
                </label>
                <input
                  type="text"
                  required
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none font-medium"
                  placeholder="https://example.com/labels/123.pdf یا بارگذاری لینک فایل"
                  value={labelValue}
                  onChange={(e) => setLabelValue(e.target.value)}
                />
                <p className="text-[10px] text-muted mt-1.5 leading-relaxed">
                  
                  کارشناس گرامی، لطفاً لینک مستقیم فایل پی‌دی‌اف یا تصویر لیبل
                  پستی صادر شده را در این قسمت وارد نمایید تا به تامین‌کننده
                  کالا ارائه گردد.
                </p>
              </div>
              {successMsg && (
                <div className="bg-success/10 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs font-bold flex items-center gap-2">
                  
                  <Check className="w-4.5 h-4.5 text-success flex-shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}
              {errorMsg && (
                <div className="bg-danger/10 border border-rose-200 text-rose-800 p-3 rounded-xl text-xs font-bold flex items-center gap-2">
                  
                  <AlertCircle className="w-4.5 h-4.5 text-danger flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
              <div className="pt-4 flex gap-3">
                
                <button
                  type="button"
                  onClick={() => setLabelOrderId(null)}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-muted bg-surface hover:bg-surface transition-colors cursor-pointer"
                >
                  
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={submittingLabel || !labelValue.trim()}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-inverse bg-primary-default hover:bg-primary-hover transition-colors disabled:opacity-50 cursor-pointer"
                >
                  
                  {submittingLabel ? "در حال ثبت..." : "ثبت لیبل پستی"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
