import React, { useState, useEffect } from "react";
import {
  Megaphone,
  Trash2,
  Edit,
  Plus,
  X,
  Check,
  Eye,
  EyeOff,
  AlertCircle,
} from "lucide-react";
export default function AdminAnnouncements() {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [target, setTarget] = useState("ALL");
  const [loading, setLoading] = useState(false);
  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editTarget, setEditTarget] = useState("ALL");
  const [editIsActive, setEditIsActive] = useState(true);
  const fetchAnnouncements = async () => {
    try {
      const res = await fetch("/api/announcements?all=true");
      const data = await res.json();
      setAnnouncements(data);
    } catch (e) {
      console.error(e);
    }
  };
  useEffect(() => {
    fetchAnnouncements();
  }, []);
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/announcements", { credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, target }),
      });
      if (res.ok) {
        setTitle("");
        setContent("");
        setTarget("ALL");
        fetchAnnouncements();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };
  const handleEditInit = (ann: any) => {
    setEditingId(ann.id);
    setEditTitle(ann.title);
    setEditContent(ann.content);
    setEditTarget(ann.target);
    setEditIsActive(ann.isActive);
  };
  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/announcements/${editingId}`, { credentials: "include",
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: editTitle,
          content: editContent,
          target: editTarget,
          isActive: editIsActive,
        }),
      });
      if (res.ok) {
        setEditingId(null);
        fetchAnnouncements();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };
  const handleDelete = async (id: string) => {
    if (!window.confirm("آیا از حذف این اطلاعیه اطمینان دارید؟")) return;
    try {
      const res = await fetch(`/api/announcements/${id}`, { credentials: "include", method: "DELETE" });
      if (res.ok) {
        fetchAnnouncements();
      }
    } catch (e) {
      console.error(e);
    }
  };
  const toggleStatus = async (id: string, currentStatus: boolean) => {
    try {
      await fetch(`/api/announcements/${id}`, { credentials: "include",
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !currentStatus }),
      });
      fetchAnnouncements();
    } catch (e) {
      console.error(e);
    }
  };
  const getTargetLabel = (tgt: string) => {
    switch (tgt) {
      case "ALL":
        return "همه کاربران";
      case "STORE_MANAGER":
        return "مدیران فروشگاه";
      case "SUPPLIER":
        return "تامین‌کنندگان";
      default:
        return tgt;
    }
  };
  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      
      {/* Create Section */}
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-subtle">
        
        <h3 className="text-lg font-bold text-primary mb-4 flex items-center gap-2">
          
          <Megaphone className="w-5 h-5 text-primary-default" /> ثبت پیام /
          اطلاع‌رسانی جدید
        </h3>
        <form onSubmit={handleCreate} className="space-y-4">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div className="md:col-span-2">
              
              <label className="block text-xs font-bold text-secondary mb-1">
                عنوان پیام
              </label>
              <input
                required
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
                placeholder="مثال: به‌روزرسانی سیستم پرداخت"
              />
            </div>
            <div>
              
              <label className="block text-xs font-bold text-secondary mb-1">
                مخاطبین هدف
              </label>
              <select
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
              >
                
                <option value="ALL">همه (صفحه ورود + پنل‌ها)</option>
                <option value="STORE_MANAGER">مدیران فروشگاه</option>
                <option value="SUPPLIER">تامین‌کنندگان</option>
              </select>
            </div>
          </div>
          <div>
            
            <label className="block text-xs font-bold text-secondary mb-1">
              متن پیام
            </label>
            <textarea
              required
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={4}
              className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
              placeholder="متن کامل اطلاعیه یا راهنمای جدید را وارد کنید..."
            />
          </div>
          <div className="flex justify-end">
            
            <button
              type="submit"
              disabled={loading}
              className="bg-primary-default hover:bg-primary-hover active:scale-95 text-inverse px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-md shadow-primary-default/10 cursor-pointer"
            >
              
              <Plus className="w-4 h-4" /> ثبت و انتشار
            </button>
          </div>
        </form>
      </div>
      {/* List Section */}
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-subtle">
        
        <h3 className="text-lg font-bold text-primary mb-4">
          اطلاعیه‌ها و صفحات راهنما
        </h3>
        {announcements.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted bg-background rounded-xl border border-dashed border-subtle">
            
            <AlertCircle className="w-12 h-12 text-inverse mb-2 animate-pulse" />
            <p className="text-sm font-medium">
              هیچ اطلاعیه‌ای ثبت نشده است
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className={`p-5 rounded-2xl border transition-all ${ann.isActive ? "border-primary-default/20 bg-primary-default/10/30" : "border-slate-150 bg-background/50"}`}
              >
                
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-3">
                  
                  <div>
                    
                    <h4 className="font-bold text-primary text-base">
                      {ann.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      
                      <span className="text-[10px] font-bold bg-surface text-muted px-2.5 py-1 rounded-full">
                        
                        مخاطب: {getTargetLabel(ann.target)}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${ann.isActive ? "bg-success/20 text-success" : "bg-warning/20 text-warning"}`}
                      >
                        
                        {ann.isActive ? "فعال" : "غیرفعال"}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    
                    <button
                      onClick={() => toggleStatus(ann.id, ann.isActive)}
                      className={`p-2 rounded-xl transition-all ${ann.isActive ? "bg-warning/10 text-warning hover:bg-warning/20" : "bg-success/10 text-success hover:bg-success/20"}`}
                      title={ann.isActive ? "غیرفعال‌سازی" : "فعال‌سازی"}
                    >
                      
                      {ann.isActive ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                    <button
                      onClick={() => handleEditInit(ann)}
                      className="p-2 bg-primary-default/10 text-primary-default hover:bg-primary-default/20 rounded-xl transition-all"
                      title="ویرایش"
                    >
                      
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(ann.id)}
                      className="p-2 bg-danger/10 text-danger hover:bg-danger/20 rounded-xl transition-all"
                      title="حذف کامل"
                    >
                      
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="text-sm text-muted whitespace-pre-wrap leading-relaxed">
                  {ann.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Edit Modal */}
      {editingId && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center p-4 z-[100] animate-fade-in">
          
          <div
            className="bg-card rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-subtle"
            dir="rtl"
          >
            
            <div className="p-6 border-b border-subtle flex items-center justify-between bg-background">
              
              <h3 className="text-lg font-bold text-primary flex items-center gap-2">
                
                <Edit className="w-5 h-5 text-primary-default" /> ویرایش اطلاعیه
                / صفحه راهنما
              </h3>
              <button
                onClick={() => setEditingId(null)}
                className="p-2 text-muted hover:text-muted hover:bg-surface rounded-xl transition-all"
              >
                
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdate} className="p-6 space-y-4">
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                <div className="md:col-span-2">
                  
                  <label className="block text-xs font-bold text-secondary mb-1">
                    عنوان پیام
                  </label>
                  <input
                    required
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
                  />
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-secondary mb-1">
                    مخاطبین هدف
                  </label>
                  <select
                    value={editTarget}
                    onChange={(e) => setEditTarget(e.target.value)}
                    className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
                  >
                    
                    <option value="ALL">همه (صفحه ورود + پنل‌ها)</option>
                    <option value="STORE_MANAGER">مدیران فروشگاه</option>
                    <option value="SUPPLIER">تامین‌کنندگان</option>
                  </select>
                </div>
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-1">
                  متن پیام
                </label>
                <textarea
                  required
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  rows={6}
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-sm focus:bg-card focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all outline-none"
                />
              </div>
              <div className="flex items-center gap-2 bg-background p-3 rounded-xl border border-subtle">
                
                <input
                  type="checkbox"
                  id="editIsActive"
                  checked={editIsActive}
                  onChange={(e) => setEditIsActive(e.target.checked)}
                  className="w-4 h-4 text-primary-default border-default rounded focus:ring-primary-default cursor-pointer"
                />
                <label
                  htmlFor="editIsActive"
                  className="text-sm text-secondary font-medium cursor-pointer select-none"
                >
                  
                  این اطلاعیه به صورت فعال نمایش داده شود.
                </label>
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t border-subtle">
                
                <button
                  type="button"
                  onClick={() => setEditingId(null)}
                  className="px-5 py-2.5 bg-surface hover:bg-surface active:scale-95 text-secondary rounded-xl text-sm font-bold transition-all cursor-pointer"
                >
                  
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2.5 bg-primary-default hover:bg-primary-hover active:scale-95 text-inverse rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-md shadow-primary-default/10 cursor-pointer"
                >
                  
                  <Check className="w-4 h-4" /> ذخیره تغییرات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
