import React, { useEffect, useState } from "react";
import { 
  Users, 
  Search, 
  UserCheck, 
  UserX, 
  Wallet, 
  TrendingUp, 
  Plus, 
  Minus, 
  Calendar, 
  Phone, 
  Mail, 
  Shield, 
  Info, 
  X,
  RefreshCw,
  Award,
  Filter
} from "lucide-react";

interface Referrer {
  id: number;
  firstName: string;
  lastName: string;
  username: string;
  mobile: string;
  email: string | null;
  status: "ACTIVE" | "BLOCKED" | "SUSPENDED";
  referralCode: string;
  walletBalance: number;
  referralCount: number;
  createdAt: string;
}

export default function ReferrersList() {
  const [referrers, setReferrers] = useState<Referrer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [selectedReferrer, setSelectedReferrer] = useState<Referrer | null>(null);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  
  // Wallet adjustment state
  const [walletAmount, setWalletAmount] = useState("");
  const [walletType, setWalletType] = useState<"DEPOSIT" | "WITHDRAWAL">("DEPOSIT");
  const [walletDesc, setWalletDesc] = useState("");
  const [walletSubmitting, setWalletSubmitting] = useState(false);

  const fetchReferrers = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/api/admin/referrers", {
        headers: {
          Authorization: `Bearer ${token || ""}`,
        },
      });
      if (!res.ok) {
        throw new Error("خطا در دریافت اطلاعات معرف‌ها");
      }
      const data = await res.json();
      setReferrers(data);
    } catch (err: any) {
      setError(err.message || "خطایی رخ داده است.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferrers();
  }, []);

  const handleUpdateStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === "ACTIVE" ? "BLOCKED" : "ACTIVE";
    if (!window.confirm(`آیا مطمئن هستید که می‌خواهید وضعیت این معرف را تغییر دهید؟`)) {
      return;
    }
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`/api/admin/referrers/${id}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token || ""}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطا در تغییر وضعیت");
      }
      
      setReferrers(prev => prev.map(r => r.id === id ? { ...r, status: newStatus as any } : r));
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleAdjustWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReferrer) return;
    const amount = parseFloat(walletAmount);
    if (isNaN(amount) || amount <= 0) {
      alert("لطفاً مبلغ معتبری وارد کنید.");
      return;
    }

    setWalletSubmitting(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`/api/admin/referrers/${selectedReferrer.id}/wallet`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token || ""}`,
        },
        body: JSON.stringify({
          amount,
          type: walletType,
          description: walletDesc || (walletType === "DEPOSIT" ? "شارژ دستی توسط مدیریت" : "برداشت دستی توسط مدیریت"),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطا در تراکنش کیف پول");
      }

      // Update local state
      setReferrers(prev => prev.map(r => {
        if (r.id === selectedReferrer.id) {
          const change = walletType === "DEPOSIT" ? amount : -amount;
          return { ...r, walletBalance: r.walletBalance + change };
        }
        return r;
      }));

      setIsWalletModalOpen(false);
      setSelectedReferrer(null);
      setWalletAmount("");
      setWalletDesc("");
      
      alert("کیف پول معرف با موفقیت به روزرسانی شد.");
    } catch (err: any) {
      alert(err.message);
    } finally {
      setWalletSubmitting(false);
    }
  };

  // Filter list
  const filteredReferrers = referrers.filter(r => {
    const matchesSearch = 
      `${r.firstName} ${r.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.referralCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.mobile.includes(searchQuery);

    const matchesStatus = 
      statusFilter === "ALL" || 
      r.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const totalReferrals = referrers.reduce((acc, curr) => acc + curr.referralCount, 0);
  const totalWalletBalances = referrers.reduce((acc, curr) => acc + curr.walletBalance, 0);

  return (
    <div className="space-y-6">
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-indigo-500/10 to-purple-500/5 border border-indigo-500/20 rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-text-secondary">کل معرف‌های سیستم</p>
              <h3 className="text-3xl font-black text-primary mt-2">{referrers.length} نفر</h3>
            </div>
            <div className="w-12 h-12 bg-indigo-500/10 text-indigo-500 rounded-2xl flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/5 border border-emerald-500/20 rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-text-secondary">زیرمجموعه‌های معرفی شده (تامین‌کنندگان)</p>
              <h3 className="text-3xl font-black text-primary mt-2">{totalReferrals} تامین‌کننده</h3>
            </div>
            <div className="w-12 h-12 bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20 rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-text-secondary">کل اعتبار کیف پول معرف‌ها</p>
              <h3 className="text-3xl font-black text-primary mt-2">{totalWalletBalances.toLocaleString()} ریال</h3>
            </div>
            <div className="w-12 h-12 bg-amber-500/10 text-amber-500 rounded-2xl flex items-center justify-center">
              <Wallet className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-card border rounded-3xl p-5 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex flex-1 flex-col md:flex-row gap-3 w-full">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted w-4 h-4" />
            <input
              type="text"
              placeholder="جستجو بر اساس نام، نام کاربری، کد دعوت یا موبایل..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-11 py-2.5 bg-background border rounded-2xl text-xs text-primary focus:outline-none focus:ring-2 focus:ring-primary-default border-border-default transition-all"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <Filter className="text-text-muted w-4 h-4" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2.5 bg-background border rounded-2xl text-xs text-primary focus:outline-none focus:ring-2 focus:ring-primary-default border-border-default transition-all cursor-pointer font-bold"
            >
              <option value="ALL">همه وضعیت‌ها</option>
              <option value="ACTIVE">فعال</option>
              <option value="BLOCKED">مسدود شده</option>
            </select>
          </div>
        </div>

        <button
          onClick={fetchReferrers}
          className="flex items-center gap-2 px-4 py-2.5 bg-surface hover:bg-surface/80 border text-primary rounded-2xl text-xs font-bold transition-all cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          به‌روزرسانی لیست
        </button>
      </div>

      {/* Main content table */}
      <div className="bg-card border rounded-[2rem] overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center gap-3">
            <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
            <span className="text-sm font-bold text-text-secondary">در حال دریافت لیست معرف‌ها...</span>
          </div>
        ) : error ? (
          <div className="p-12 text-center">
            <div className="text-danger font-bold text-sm mb-2">خطا در بارگذاری داده‌ها</div>
            <p className="text-xs text-text-muted">{error}</p>
          </div>
        ) : filteredReferrers.length === 0 ? (
          <div className="p-16 flex flex-col items-center justify-center text-center gap-3">
            <Users className="w-16 h-16 text-text-muted/40" />
            <h4 className="text-base font-bold text-primary">هیچ معرفی پیدا نشد</h4>
            <p className="text-xs text-text-muted max-w-md">
              معرفی با فیلترهای جستجوی شما مطابقت ندارد یا هنوز کاربری به عنوان معرف در سیستم ثبت‌نام نکرده است.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-surface border-b border-border-subtle text-text-secondary text-xs font-black">
                  <th className="px-6 py-4">مشخصات معرف</th>
                  <th className="px-6 py-4">نام کاربری / تماس</th>
                  <th className="px-6 py-4">کد دعوت (Referral Code)</th>
                  <th className="px-6 py-4">تعداد معرفی‌ها</th>
                  <th className="px-6 py-4">موجودی کیف پول (ریال)</th>
                  <th className="px-6 py-4">تاریخ ثبت‌نام</th>
                  <th className="px-6 py-4">وضعیت</th>
                  <th className="px-6 py-4 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-subtle">
                {filteredReferrers.map((ref) => (
                  <tr key={ref.id} className="hover:bg-surface/50 transition-all text-xs font-medium">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center font-bold">
                          {ref.firstName[0]}
                        </div>
                        <div>
                          <div className="font-bold text-primary text-sm">{ref.firstName} {ref.lastName}</div>
                          <div className="text-[10px] text-text-muted">شناسه: {ref.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 space-y-1">
                      <div className="font-bold text-primary font-mono">{ref.username}</div>
                      <div className="text-[10px] text-text-secondary flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-text-muted" /> {ref.mobile}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-3 py-1 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-mono font-bold rounded-lg border border-indigo-500/20 text-xs">
                        {ref.referralCode}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-bold text-primary text-sm">{ref.referralCount}</span> تامین‌کننده
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-bold text-primary text-sm">{ref.walletBalance.toLocaleString()}</span> ریال
                    </td>
                    <td className="px-6 py-4 text-text-secondary font-mono">
                      {new Date(ref.createdAt).toLocaleDateString("fa-IR")}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black ${
                        ref.status === "ACTIVE" 
                          ? "bg-success/10 text-success border border-success/20" 
                          : "bg-danger/10 text-danger border border-danger/20"
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${ref.status === "ACTIVE" ? "bg-success" : "bg-danger"}`} />
                        {ref.status === "ACTIVE" ? "فعال" : "غیرفعال/مسدود"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-2">
                        {/* Status Toggle */}
                        <button
                          onClick={() => handleUpdateStatus(ref.id, ref.status)}
                          className={`p-2 rounded-xl border transition-all cursor-pointer ${
                            ref.status === "ACTIVE" 
                              ? "bg-danger/5 border-danger/10 text-danger hover:bg-danger/10" 
                              : "bg-success/5 border-success/10 text-success hover:bg-success/10"
                          }`}
                          title={ref.status === "ACTIVE" ? "مسدود کردن معرف" : "فعال‌سازی معرف"}
                        >
                          {ref.status === "ACTIVE" ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>

                        {/* Adjust Wallet */}
                        <button
                          onClick={() => {
                            setSelectedReferrer(ref);
                            setIsWalletModalOpen(true);
                          }}
                          className="p-2 bg-amber-500/5 border border-amber-500/10 hover:bg-amber-500/10 text-amber-600 rounded-xl transition-all cursor-pointer"
                          title="شارژ یا کسر از کیف پول"
                        >
                          <Wallet className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Wallet Adjustment Modal */}
      {isWalletModalOpen && selectedReferrer && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-card border shadow-2xl rounded-[2rem] max-w-md w-full overflow-hidden animate-scale-up">
            <div className="p-6 border-b border-subtle flex items-center justify-between">
              <div className="flex items-center gap-2 text-primary font-black">
                <Wallet className="w-5 h-5 text-indigo-500" />
                <h3>تغییر موجودی کیف پول معرف</h3>
              </div>
              <button
                onClick={() => {
                  setIsWalletModalOpen(false);
                  setSelectedReferrer(null);
                }}
                className="p-1.5 bg-surface border hover:bg-surface/80 rounded-xl text-text-muted hover:text-text-primary transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAdjustWallet} className="p-6 space-y-4 text-right">
              <div className="bg-surface rounded-2xl p-4 border space-y-1">
                <div className="text-[10px] text-text-muted font-bold">معرف انتخاب شده</div>
                <div className="font-bold text-primary text-sm">{selectedReferrer.firstName} {selectedReferrer.lastName}</div>
                <div className="text-[11px] text-text-secondary font-mono flex items-center justify-between mt-2 pt-2 border-t border-dashed">
                  <span>موجودی فعلی:</span>
                  <span className="font-bold text-indigo-500">{selectedReferrer.walletBalance.toLocaleString()} ریال</span>
                </div>
              </div>

              {/* Adjustment Type */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-text-secondary">نوع تراکنش</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setWalletType("DEPOSIT")}
                    className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      walletType === "DEPOSIT" 
                        ? "bg-success/10 border-success/30 text-success shadow-sm" 
                        : "bg-background border-border-default hover:bg-surface text-text-muted"
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    واریز (افزایش موجودی)
                  </button>
                  <button
                    type="button"
                    onClick={() => setWalletType("WITHDRAWAL")}
                    className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      walletType === "WITHDRAWAL" 
                        ? "bg-danger/10 border-danger/30 text-danger shadow-sm" 
                        : "bg-background border-border-default hover:bg-surface text-text-muted"
                    }`}
                  >
                    <Minus className="w-3.5 h-3.5" />
                    برداشت (کاهش موجودی)
                  </button>
                </div>
              </div>

              {/* Amount */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-text-secondary">مبلغ تراکنش (ریال)</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={walletAmount}
                  onChange={(e) => setWalletAmount(e.target.value)}
                  placeholder="مثال: ۵۰۰۰۰۰۰"
                  className="w-full px-4 py-2.5 bg-background border rounded-xl text-xs text-primary focus:outline-none focus:ring-2 focus:ring-primary-default border-border-default text-left font-mono"
                  style={{ direction: "ltr" }}
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-text-secondary">توضیحات تراکنش (اختیاری)</label>
                <textarea
                  value={walletDesc}
                  onChange={(e) => setWalletDesc(e.target.value)}
                  placeholder="بابت تسویه هفتگی، پاداش ثبت‌نام، و..."
                  className="w-full px-4 py-2.5 bg-background border rounded-xl text-xs text-primary focus:outline-none focus:ring-2 focus:ring-primary-default border-border-default min-h-[80px]"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsWalletModalOpen(false);
                    setSelectedReferrer(null);
                  }}
                  className="flex-1 py-3 border hover:bg-surface text-secondary font-bold rounded-xl transition-all text-xs cursor-pointer text-center"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={walletSubmitting}
                  className="flex-1 bg-primary-default hover:bg-primary-hover text-inverse font-black py-3 rounded-xl transition-all flex items-center justify-center gap-2 text-xs cursor-pointer"
                >
                  {walletSubmitting ? (
                    <span className="flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      در حال ثبت تراکنش...
                    </span>
                  ) : (
                    "ثبت تراکنش"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Static Commission Policy Rules Banner */}
      <div className="bg-gradient-to-r from-indigo-600/5 to-purple-600/10 border border-indigo-600/10 rounded-3xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-3.5 text-right">
          <div className="w-10 h-10 bg-indigo-600/10 text-indigo-600 rounded-2xl flex items-center justify-center flex-shrink-0 mt-0.5">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-black text-sm text-primary">قوانین کمیسیون همکاران معرف</h4>
            <p className="text-xs text-text-muted mt-1 leading-relaxed max-w-2xl font-medium">
              در حال حاضر نرخ کمیسیون معرف‌ها به صورت پیش‌فرض **۱۰٪ از فروش خالص** تمامی تامین‌کنندگان معرفی شده توسط آن‌ها می‌باشد. پس از تایید فاکتورهای سفارشات توسط مدیریت، مبالغ کمیسیون به صورت خودکار به کیف پول معرف‌ها واریز می‌گردد. تسویه حساب معرف‌ها هفتگی یا به صورت درخواست تسویه انجام می‌شود.
            </p>
          </div>
        </div>
        <div className="text-xs font-black px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-600 whitespace-nowrap">
          کمیسیون پیش‌فرض سیستم: ۱۰٪
        </div>
      </div>

    </div>
  );
}
