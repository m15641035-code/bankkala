import React, { useState, useEffect } from "react";
import {
  Settings,
  Shield,
  Bell,
  Power,
  AlertTriangle,
  Scale,
  Percent,
  Clock,
  RotateCcw,
  TrendingDown,
  DollarSign,
  Briefcase,
  Play,
  CheckCircle,
  HelpCircle,
  Activity,
  Plus,
  Trash2,
  GitCommit,
  Bot
} from "lucide-react";

export default function SystemSettings() {
  const [config, setConfig] = useState<Record<string, any>>({
    // Defaults
    STORE_CATALOG_ENABLED: true,
    STORE_ORDERS_ENABLED: true,
    STORE_FINANCIAL_ENABLED: true,
    SUPPLIER_CATALOG_ENABLED: true,
    SUPPLIER_ORDERS_ENABLED: true,
    SUPPLIER_FINANCIAL_ENABLED: true,
    COMMISSION_PERCENTAGE: 10,
    TAX_RATE: 9,
    MAX_DELIVERY_HOURS: 48,
    RETURN_PERIOD_DAYS: 7,
    DAILY_DELAY_PENALTY: 2,
    CRITICAL_SUSPENSION_THRESHOLD: 70,
    MIN_PAYOUT_AMOUNT: 1000000,
    ORDER_WORKFLOW_STEPS: "ثبت سفارش,پرداخت نهایی,چاپ برچسب ارسال,تحویل به پست,توزیع و تحویل کالا,تسویه تامین‌کننده",
    AUTO_NOTIFY_ON_WARNING: true,
    AUTO_PENALIZE_ON_DELAY: true,
    ORDER_PROCESSING_HOURS: 24,
    SLA_CRITICAL_HOURS: 12,
    SUPPLIER_AUTO_VERIFY: false,
    REFUND_RULES_AUTO_APPROVE: false,
    CANCEL_SCORE_DEDUCTION: 4,
    RETURN_SCORE_DEDUCTION: 3,
    DELAY_SCORE_DEDUCTION: 2
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newStepName, setNewStepName] = useState("");

  const fetchConfig = () => {
    setLoading(true);
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data && !data.error) {
          // Merge defaults with actual DB data
          setConfig((prev) => ({ ...prev, ...data }));
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching config:", err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  const saveSingleConfig = (key: string, value: any) => {
    fetch("/api/config", { credentials: "include",
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value: String(value) }),
    })
      .then((res) => res.json())
      .then(() => {
        setConfig((prev) => ({ ...prev, [key]: value }));
      })
      .catch((err) => console.error(`Error saving config key ${key}:`, err));
  };

  const toggleConfig = (key: string) => {
    const newValue = !config[key];
    saveSingleConfig(key, newValue);
  };

  const handleRuleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    // Save all business rule fields sequentially
    const keysToSave = [
      "COMMISSION_PERCENTAGE",
      "TAX_RATE",
      "MAX_DELIVERY_HOURS",
      "RETURN_PERIOD_DAYS",
      "DAILY_DELAY_PENALTY",
      "CRITICAL_SUSPENSION_THRESHOLD",
      "MIN_PAYOUT_AMOUNT",
      "ORDER_WORKFLOW_STEPS",
      "AUTO_NOTIFY_ON_WARNING",
      "AUTO_PENALIZE_ON_DELAY",
      "ORDER_PROCESSING_HOURS",
      "SLA_CRITICAL_HOURS",
      "SUPPLIER_AUTO_VERIFY",
      "REFUND_RULES_AUTO_APPROVE",
      "CANCEL_SCORE_DEDUCTION",
      "RETURN_SCORE_DEDUCTION",
      "DELAY_SCORE_DEDUCTION"
    ];

    const promises = keysToSave.map((key) => {
      return fetch("/api/config", { credentials: "include",
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value: String(config[key]) }),
      });
    });

    Promise.all(promises)
      .then(() => {
        setSaving(false);
        alert("✅ قوانین جدید کسب‌وکار با موفقیت در سراسر سیستم اعمال گردید!");
      })
      .catch((err) => {
        console.error("Error saving rules:", err);
        setSaving(false);
        alert("❌ خطا در ذخیره اطلاعات. لطفا دوباره تلاش نمایید.");
      });
  };

  const handleInputChange = (key: string, value: any) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
  };

  // Workflow steps array derived from comma separated string
  const workflowSteps = config.ORDER_WORKFLOW_STEPS
    ? config.ORDER_WORKFLOW_STEPS.split(",").filter((s: string) => s.trim() !== "")
    : [];

  const handleAddStep = () => {
    if (!newStepName.trim()) return;
    const updatedSteps = [...workflowSteps, newStepName.trim()];
    const stepsString = updatedSteps.join(",");
    handleInputChange("ORDER_WORKFLOW_STEPS", stepsString);
    saveSingleConfig("ORDER_WORKFLOW_STEPS", stepsString);
    setNewStepName("");
  };

  const handleRemoveStep = (index: number) => {
    const updatedSteps = workflowSteps.filter((_: any, i: number) => i !== index);
    const stepsString = updatedSteps.join(",");
    handleInputChange("ORDER_WORKFLOW_STEPS", stepsString);
    saveSingleConfig("ORDER_WORKFLOW_STEPS", stepsString);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-default mr-2"></div>
        در حال دریافت اطلاعات قوانین و تنظیمات سیستم...
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in" dir="rtl">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-surface p-6 rounded-2xl border border-subtle">
        <div>
          <h2 className="text-xl font-bold text-inverse flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary-default animate-spin-slow" />
            موتور قوانین کسب‌وکار و پیکربندی سیستم
          </h2>
          <p className="text-xs text-muted mt-1 leading-relaxed">
            تنظیم بدون نیاز به برنامه‌نویسی برای تغییر درصد کمیسیون، آستانه تعلیق تامین‌کنندگان، گام‌های سفارش و دسترسی ماژول‌ها.
          </p>
        </div>
        <div className="bg-primary-default/10 text-primary-default border border-primary-default/20 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
          <Shield className="w-4 h-4" /> وضعیت امنیتی: کاملاً محافظت شده
        </div>
      </div>

      {/* 1. MAIN SYSTEM ACCESS & MAINTENANCE MODULE */}
      <div className="bg-surface p-6 rounded-2xl shadow-sm border border-subtle space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-subtle">
          <Power className="w-5 h-5 text-primary-default animate-pulse" />
          <div>
            <h3 className="font-bold text-inverse">تنظیمات اضطراری و دسترسی سراسری به پنل‌ها</h3>
            <p className="text-[10px] text-muted mt-0.5">غیرفعال‌سازی موقت بخش‌ها در مواقع بروزرسانی یا تعمیرات</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Store Manager Access */}
          <div className="space-y-4">
            <h4 className="font-bold text-inverse bg-background p-3 rounded-xl border border-subtle text-center text-xs">
              دسترسی‌های پنل مدیر فروشگاه
            </h4>
            <div className="space-y-3">
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">مشاهده کاتالوگ و محصولات کل تامین‌کنندگان</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.STORE_CATALOG_ENABLED !== false}
                  onChange={() => toggleConfig("STORE_CATALOG_ENABLED")}
                />
              </label>
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">امکان ثبت و پیگیری سفارشات عمده</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.STORE_ORDERS_ENABLED !== false}
                  onChange={() => toggleConfig("STORE_ORDERS_ENABLED")}
                />
              </label>
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">دسترسی به بخش مالی و ثبت فیش پرداخت</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.STORE_FINANCIAL_ENABLED !== false}
                  onChange={() => toggleConfig("STORE_FINANCIAL_ENABLED")}
                />
              </label>
            </div>
          </div>

          {/* Supplier Access */}
          <div className="space-y-4">
            <h4 className="font-bold text-inverse bg-background p-3 rounded-xl border border-subtle text-center text-xs">
              دسترسی‌های پنل تامین‌کنندگان کالا
            </h4>
            <div className="space-y-3">
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">ایجاد کالا، ویرایش قیمت و مدیریت تنوع‌ها</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.SUPPLIER_CATALOG_ENABLED !== false}
                  onChange={() => toggleConfig("SUPPLIER_CATALOG_ENABLED")}
                />
              </label>
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">مدیریت سفارشات دریافتی و تغییر وضعیت ارسال</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.SUPPLIER_ORDERS_ENABLED !== false}
                  onChange={() => toggleConfig("SUPPLIER_ORDERS_ENABLED")}
                />
              </label>
              <label className="flex items-center justify-between p-3.5 border border-subtle rounded-xl hover:bg-background/50 cursor-pointer transition-all">
                <span className="text-xs font-semibold text-inverse">مشاهده کیف‌پول و ارسال درخواست تسویه حساب</span>
                <input
                  type="checkbox"
                  className="w-5 h-5 rounded border-default text-primary-default focus:ring-primary-default"
                  checked={config.SUPPLIER_FINANCIAL_ENABLED !== false}
                  onChange={() => toggleConfig("SUPPLIER_FINANCIAL_ENABLED")}
                />
              </label>
            </div>
          </div>
        </div>

        <div className="bg-warning/5 p-4 rounded-xl border border-warning/20 flex gap-3 text-warning text-xs">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <p className="leading-relaxed font-semibold">
            نکته بسیار مهم: با غیرفعال‌سازی هر یک از این دسترسی‌ها، کاربران در حین ورود به ماژول مربوطه با یک صفحه زیبای "🚧 در حال بروزرسانی و تعمیر موقت" مواجه می‌شوند تا از بروز تداخل اطلاعاتی جلوگیری شود.
          </p>
        </div>
      </div>

      {/* 2. BUSINESS RULE ENGINE */}
      <form onSubmit={handleRuleSubmit} className="bg-surface p-6 rounded-2xl shadow-sm border border-subtle space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-subtle">
          <div className="flex items-center gap-3">
            <Scale className="w-5 h-5 text-success" />
            <div>
              <h3 className="font-bold text-inverse">موتور قوانین و کارمزدها (Business Rules Core)</h3>
              <p className="text-[10px] text-muted mt-0.5">تنظیم ضرایب فرمول‌های مالی و انضباطی کل پلتفرم</p>
            </div>
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2 bg-success hover:bg-success disabled:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/10 cursor-pointer transition-colors"
          >
            {saving ? "در حال ذخیره‌سازی..." : "ثبت و اعمال تغییرات قوانین"}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Commission rate */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Percent className="w-4 h-4 text-muted" /> درصد کارمزد پلتفرم (کمیسیون)
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                max="100"
                value={config.COMMISSION_PERCENTAGE}
                onChange={(e) => handleInputChange("COMMISSION_PERCENTAGE", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">درصد (٪)</span>
            </div>
            <p className="text-[10px] text-muted">از کل فروش تامین‌کننده سهم سیستم می‌شود.</p>
          </div>

          {/* Tax Rate */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <DollarSign className="w-4 h-4 text-muted" /> درصد مالیات بر ارزش افزوده (VAT)
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                max="100"
                value={config.TAX_RATE}
                onChange={(e) => handleInputChange("TAX_RATE", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">درصد (٪)</span>
            </div>
            <p className="text-[10px] text-muted">به قیمت نهایی جهت واریز فاکتورها افزوده می‌شود.</p>
          </div>

          {/* Max ship period */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted" /> حداکثر زمان ارسال کالا توسط تامین‌کننده
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                value={config.MAX_DELIVERY_HOURS}
                onChange={(e) => handleInputChange("MAX_DELIVERY_HOURS", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">ساعت</span>
            </div>
            <p className="text-[10px] text-muted">پس از این مهلت، سیستم وضعیت را تاخیردار محاسبه می‌کند.</p>
          </div>

          {/* Return period */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <RotateCcw className="w-4 h-4 text-muted" /> مهلت مرجوعی کالا برای فروشگاه
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                value={config.RETURN_PERIOD_DAYS}
                onChange={(e) => handleInputChange("RETURN_PERIOD_DAYS", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">روز کاری</span>
            </div>
            <p className="text-[10px] text-muted">مدت زمانی که فروشگاه می‌تواند کالا را مرجوع کند.</p>
          </div>

          {/* Delay points */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <TrendingDown className="w-4 h-4 text-muted" /> کسر امتیاز منفی به ازای هر روز تاخیر
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                value={config.DAILY_DELAY_PENALTY}
                onChange={(e) => handleInputChange("DAILY_DELAY_PENALTY", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">امتیاز منفی/روز</span>
            </div>
            <p className="text-[10px] text-muted">امتیاز منفی از کارنامه عملکرد تامین‌کننده کسر می‌شود.</p>
          </div>

          {/* Critical suspend threshold */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <AlertTriangle className="w-4 h-4 text-muted" /> آستانه امتیاز عملکرد برای تعلیق خودکار
            </label>
            <div className="relative">
              <input
                type="number"
                min="10"
                max="100"
                value={config.CRITICAL_SUSPENSION_THRESHOLD}
                onChange={(e) => handleInputChange("CRITICAL_SUSPENSION_THRESHOLD", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">درصد امتیاز (٪)</span>
            </div>
            <p className="text-[10px] text-muted">اگر نمره عملکرد به کمتر از این برسد، پنل تعلیق می‌شود.</p>
          </div>

          {/* Order Processing hours */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted" /> مهلت زمانی تایید سفارش توسط تامین‌کننده
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                value={config.ORDER_PROCESSING_HOURS !== undefined ? config.ORDER_PROCESSING_HOURS : 24}
                onChange={(e) => handleInputChange("ORDER_PROCESSING_HOURS", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">ساعت</span>
            </div>
            <p className="text-[10px] text-muted">مهلت زمانی پذیرش سفارش ورودی توسط تامین‌کننده کالا.</p>
          </div>

          {/* SLA Warning hours */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted" /> مهلت زمانی هشدار SLA بحرانی
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                value={config.SLA_CRITICAL_HOURS !== undefined ? config.SLA_CRITICAL_HOURS : 12}
                onChange={(e) => handleInputChange("SLA_CRITICAL_HOURS", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">ساعت مانده</span>
            </div>
            <p className="text-[10px] text-muted">زمان نزدیک شدن به ددلاین ارسال برای نمایش علامت هشدار قرمز.</p>
          </div>

          {/* Supplier Auto Verification */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Shield className="w-4 h-4 text-muted" /> قوانین تأیید خودکار تامین‌کننده
            </label>
            <div className="relative">
              <select
                value={config.SUPPLIER_AUTO_VERIFY === "true" || config.SUPPLIER_AUTO_VERIFY === true ? "true" : "false"}
                onChange={(e) => handleInputChange("SUPPLIER_AUTO_VERIFY", e.target.value === "true")}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-bold"
              >
                <option value="false">تایید دستی توسط مدیرکل (پیش‌فرض)</option>
                <option value="true">تایید خودکار بلافاصله پس از ثبت‌نام</option>
              </select>
            </div>
            <p className="text-[10px] text-muted">مکانیزم تایید صلاحیت تامین‌کنندگان جدید ثبت‌نام شده.</p>
          </div>

          {/* Refund Auto Approval */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <RotateCcw className="w-4 h-4 text-muted" /> تایید خودکار درخواست مرجوعی و بازپرداخت
            </label>
            <div className="relative">
              <select
                value={config.REFUND_RULES_AUTO_APPROVE === "true" || config.REFUND_RULES_AUTO_APPROVE === true ? "true" : "false"}
                onChange={(e) => handleInputChange("REFUND_RULES_AUTO_APPROVE", e.target.value === "true")}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-bold"
              >
                <option value="false">بررسی و تایید دستی توسط داور پلتفرم</option>
                <option value="true">تایید سیستمی فوری پس از ثبت مرجوعی</option>
              </select>
            </div>
            <p className="text-[10px] text-muted">قانون مرجوعی و بازگشت مبالغ فاکتور به فروشگاه خریدار.</p>
          </div>

          {/* Cancel score deduction */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <TrendingDown className="w-4 h-4 text-muted" /> نمره کسر امتیاز لغو سفارش تامین‌کننده
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                value={config.CANCEL_SCORE_DEDUCTION !== undefined ? config.CANCEL_SCORE_DEDUCTION : 4}
                onChange={(e) => handleInputChange("CANCEL_SCORE_DEDUCTION", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">امتیاز منفی</span>
            </div>
            <p className="text-[10px] text-muted">در صورت لغو یا عدم پاسخ به سفارش توسط تامین‌کننده.</p>
          </div>

          {/* Return score deduction */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <TrendingDown className="w-4 h-4 text-muted" /> نمره کسر امتیاز ثبت مرجوعی کالا
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                value={config.RETURN_SCORE_DEDUCTION !== undefined ? config.RETURN_SCORE_DEDUCTION : 3}
                onChange={(e) => handleInputChange("RETURN_SCORE_DEDUCTION", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">امتیاز منفی</span>
            </div>
            <p className="text-[10px] text-muted">در صورت ارسال کالای معیوب، اشتباه یا مرجوعی ناشی از تقصیر.</p>
          </div>

          {/* Min settlement amount */}
          <div className="space-y-2 lg:col-span-3">
            <label className="text-xs font-bold text-inverse flex items-center gap-1">
              <Briefcase className="w-4 h-4 text-muted" /> حداقل موجودی مجاز برای ارسال درخواست تسویه حساب
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="10000"
                value={config.MIN_PAYOUT_AMOUNT}
                onChange={(e) => handleInputChange("MIN_PAYOUT_AMOUNT", Number(e.target.value))}
                className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-default text-inverse font-mono font-bold"
              />
              <span className="absolute left-4 top-3 text-xs text-muted">ریال ایران</span>
            </div>
            <p className="text-[10px] text-muted">
              مبلغ فاکتورهای تایید شده تامین‌کننده در کیف‌پول جهت ثبت درخواست واریز نقدی باید حداقل به این مقدار برسد.
            </p>
          </div>
        </div>
      </form>

      {/* 3. DYNAMIC ORDER WORKFLOW ENGINE */}
      <div className="bg-surface p-6 rounded-2xl shadow-sm border border-subtle space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-subtle justify-between">
          <div className="flex items-center gap-3">
            <GitCommit className="w-5 h-5 text-primary-default" />
            <div>
              <h3 className="font-bold text-inverse">موتور جریان کاری سفارشات (Dynamic Order Lifecycle)</h3>
              <p className="text-[10px] text-muted mt-0.5">تعریف مراحل پردازش سفارشات از ثبت اولیه تا تحویل و تسویه فاکتور</p>
            </div>
          </div>
          <span className="text-[10px] bg-primary-default/10 text-primary-default px-2 py-1 rounded font-bold">بدون نیاز به کدنویسی</span>
        </div>

        {/* Workflow steps pipeline visualization */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-3 pt-2">
          {workflowSteps.map((step: string, index: number) => (
            <div key={index} className="relative bg-background p-3.5 rounded-xl border border-subtle flex flex-col justify-between group">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-mono bg-subtle/50 text-muted w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {index + 1}
                </span>
                <button
                  type="button"
                  onClick={() => handleRemoveStep(index)}
                  className="text-muted hover:text-danger p-0.5 rounded cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity"
                  title="حذف گام جریان کاری"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <h5 className="text-xs font-bold text-inverse mt-3 text-center">{step}</h5>
              <div className="text-[9px] text-muted mt-1 text-center font-medium">مرحله فعال</div>
            </div>
          ))}
        </div>

        {/* Add new workflow step */}
        <div className="bg-background/40 p-4 rounded-xl border border-subtle flex flex-col md:flex-row gap-3 items-center">
          <div className="flex-1 space-y-1 w-full">
            <label className="text-[10px] font-bold text-muted block">نام گام جدید پردازش سفارش</label>
            <input
              type="text"
              placeholder="مثال: ترخیص از گمرک، بازرسی کیفی نهایی و ..."
              value={newStepName}
              onChange={(e) => setNewStepName(e.target.value)}
              className="w-full bg-surface border border-subtle rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary-default text-inverse"
            />
          </div>
          <button
            type="button"
            onClick={handleAddStep}
            className="w-full md:w-auto px-5 py-2.5 bg-primary-default hover:bg-primary-default text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1 cursor-pointer shrink-0 mt-4 md:mt-0"
          >
            <Plus className="w-4 h-4" /> افزودن گام به خط لوله پردازش
          </button>
        </div>
      </div>

      {/* 4. AUTOMATION & INTELLIGENT RULE BOT (Zapier-style policies) */}
      <div className="bg-surface p-6 rounded-2xl shadow-sm border border-subtle space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-subtle">
          <Bot className="w-5 h-5 text-primary-default animate-bounce" />
          <div>
            <h3 className="font-bold text-inverse">قوانین اتوماسیون هوشمند پلتفرم (Automation Center)</h3>
            <p className="text-[10px] text-muted mt-0.5">اقدامات خودکار ربات هوشمند سیستم بدون نیاز به ناظر دستی</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Rule 1 */}
          <div className="bg-background/30 p-5 rounded-xl border border-subtle flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-inverse">اتوماسیون جریمه و کسر امتیاز خودکار</span>
                <span className="text-[9px] bg-success/10 text-success px-1.5 py-0.5 rounded font-bold">ربات فعال</span>
              </div>
              <p className="text-xs text-muted leading-relaxed mt-2">
                در صورت فراتر رفتن از زمان ارسال مجاز (مثلاً {config.MAX_DELIVERY_HOURS} ساعت)، ربات به ازای هر روز {config.DAILY_DELAY_PENALTY} امتیاز منفی ثبت و به طور لحظه‌ای به تامین‌کننده پیامک ارسال می‌کند.
              </p>
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-subtle/40">
              <span className="text-[10px] text-muted">وضعیت اجرای زمانبندی: هر ۳ ساعت</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={config.AUTO_PENALIZE_ON_DELAY !== false}
                  onChange={() => toggleConfig("AUTO_PENALIZE_ON_DELAY")}
                />
                <div className="w-9 h-5 bg-subtle/60 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:right-[2px] after:bg-white after:border-border-default after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-success"></div>
              </label>
            </div>
          </div>

          {/* Rule 2 */}
          <div className="bg-background/30 p-5 rounded-xl border border-subtle flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-inverse">اطلاع‌رسانی خودکار و پیش‌اخطار کاهش امتیاز</span>
                <span className="text-[9px] bg-success/10 text-success px-1.5 py-0.5 rounded font-bold">ربات فعال</span>
              </div>
              <p className="text-xs text-muted leading-relaxed mt-2">
                هنگامی که امتیاز عملکرد تامین‌کننده‌ای با کسر متوالی به کمتر از {config.CRITICAL_SUSPENSION_THRESHOLD}٪ برسد، ربات به طور خودکار اخطار قرمز در پنل ثبت کرده و در صورت تداوم، دسترسی کاتالوگ وی را معلق می‌کند.
              </p>
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-subtle/40">
              <span className="text-[10px] text-muted">وضعیت اخطارهای سیستمی: ارسال آنی</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={config.AUTO_NOTIFY_ON_WARNING !== false}
                  onChange={() => toggleConfig("AUTO_NOTIFY_ON_WARNING")}
                />
                <div className="w-9 h-5 bg-subtle/60 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:right-[2px] after:bg-white after:border-border-default after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-success"></div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
