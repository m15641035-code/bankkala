import React, { useState, useEffect } from "react";
import UserModal, { ResetPasswordModal } from "./UserModal";
import { Search, Plus, Edit, KeyRound, Ban, CheckCircle2 } from "lucide-react";
export default function StoresList() {
  const [stores, setStores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const changeStatus = (id: number, status: string) => {
    fetch(`/api/admin/users/${id}/status`, { credentials: "include",
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        
      },
      body: JSON.stringify({ status }),
    }).then(() => fetchStores());
  };
  const fetchStores = () => {
    fetch("/api/admin/stores", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setStores(data);
        else setStores([]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };
  useEffect(() => {
    fetchStores();
  }, []);
  return (
    <div className="p-8 space-y-6 animate-fade-in">
      
      <div className="flex justify-between items-center">
        
        <div>
          
          <h2 className="text-2xl font-bold text-primary">
            مدیریت فروشگاه‌ها
          </h2>
          <p className="text-muted mt-1">لیست تمامی فروشگاه‌های متصل</p>
        </div>
        <button
          onClick={() => {
            setSelectedUser(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-primary-default text-inverse rounded-xl hover:bg-primary-hover transition-colors font-medium text-sm ml-4"
        >
          
          <Plus className="w-4 h-4" /> افزودن مدیر فروشگاه جدید
        </button>
      </div>
      {loading ? (
        <div className="text-center p-12 text-muted">در حال بارگذاری...</div>
      ) : (
        <div className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden">
          
          <table className="w-full text-right text-sm">
            <thead className="bg-background border-b border-subtle text-muted font-medium">
              <tr>
                
                <th className="px-6 py-4">شناسه</th>
                <th className="px-6 py-4">نام فروشگاه</th>
                <th className="px-6 py-4">مدیر</th>
                <th className="px-6 py-4">موبایل</th>
                <th className="px-6 py-4">وضعیت</th>
                <th className="px-6 py-4">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              
              {stores.map((s) => (
                <tr
                  key={s.id}
                  className="hover:bg-background transition-colors"
                >
                  
                  <td className="px-6 py-4 font-mono text-muted">
                    #{s.id}
                  </td>
                  <td className="px-6 py-4 font-bold text-primary">
                    {s.storeName || "-"}
                  </td>
                  <td className="px-6 py-4">
                    {s.firstName} {s.lastName}
                  </td>
                  <td className="px-6 py-4 font-mono text-left" dir="ltr">
                    {s.mobile}
                  </td>
                  <td className="px-6 py-4">
                    
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold ${s.status === "ACTIVE" ? "bg-success/20 text-success" : s.status === "BLOCKED" ? "bg-danger/20 text-danger" : "bg-surface text-secondary"}`}
                    >
                      
                      {s.status === "ACTIVE"
                        ? "فعال"
                        : s.status === "BLOCKED"
                          ? "غیرفعال"
                          : s.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    
                    <div className="flex gap-2">
                      
                      <button
                        onClick={() => {
                          setSelectedUser(s);
                          setIsModalOpen(true);
                        }}
                        className="p-2 text-primary-default hover:bg-primary-default/10 rounded-lg"
                        title="ویرایش"
                      >
                        
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedUser(s);
                          setIsResetModalOpen(true);
                        }}
                        className="p-2 text-muted hover:bg-background rounded-lg"
                        title="تغییر رمز عبور"
                      >
                        
                        <KeyRound className="w-5 h-5" />
                      </button>
                      {s.status !== "ACTIVE" && (
                        <button
                          onClick={() => changeStatus(s.id, "ACTIVE")}
                          className="p-2 text-success hover:bg-success/10 rounded-lg"
                          title="فعال سازی"
                        >
                          
                          <CheckCircle2 className="w-5 h-5" />
                        </button>
                      )}
                      {s.status !== "BLOCKED" && (
                        <button
                          onClick={() => changeStatus(s.id, "BLOCKED")}
                          className="p-2 text-danger hover:bg-danger/10 rounded-lg"
                          title="غیرفعال کردن"
                        >
                          
                          <Ban className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {isModalOpen && (
        <UserModal
          user={selectedUser}
          role="STORE_MANAGER"
          onClose={() => setIsModalOpen(false)}
          onSuccess={() => {
            setIsModalOpen(false);
            fetchStores();
          }}
        />
      )}
      {isResetModalOpen && selectedUser && (
        <ResetPasswordModal
          userId={selectedUser.id}
          onClose={() => setIsResetModalOpen(false)}
          onSuccess={() => setIsResetModalOpen(false)}
        />
      )}
    </div>
  );
}
