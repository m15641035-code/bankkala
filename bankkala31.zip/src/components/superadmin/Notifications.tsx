import React, { useState } from "react";
import { Send, Bell, Users, Store, Globe } from "lucide-react";
export default function Notifications() {
  const [formData, setFormData] = useState({
    target: "ALL",
    message: "",
    type: "INFO",
  });
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    alert("اعلان با موفقیت به صف ارسال اضافه شد.");
    setFormData({ target: "ALL", message: "", type: "INFO" });
  };
  return (
    <div className="p-8 space-y-6 animate-fade-in">
      
      <div>
        
        <h2 className="text-2xl font-bold text-primary">
          مدیریت اعلان‌ها
        </h2>
        <p className="text-muted mt-1">
          ارسال پیام گروهی به کاربران سیستم
        </p>
      </div>
      <div className="bg-card p-6 rounded-2xl shadow-sm border border-subtle max-w-3xl">
        
        <form onSubmit={handleSend} className="space-y-6">
          
          <div>
            
            <label className="block text-sm font-semibold text-secondary mb-3">
              مخاطبین هدف
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              <label
                className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-colors ${formData.target === "ALL" ? "border-primary-default bg-primary-default/10 text-primary-hover" : "border-subtle hover:bg-background"}`}
              >
                
                <input
                  type="radio"
                  name="target"
                  value="ALL"
                  checked={formData.target === "ALL"}
                  onChange={(e) =>
                    setFormData({ ...formData, target: e.target.value })
                  }
                  className="hidden"
                />
                <Globe className="w-5 h-5" />
                <span className="font-medium">همه کاربران</span>
              </label>
              <label
                className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-colors ${formData.target === "SUPPLIERS" ? "border-primary-default bg-primary-default/10 text-primary-hover" : "border-subtle hover:bg-background"}`}
              >
                
                <input
                  type="radio"
                  name="target"
                  value="SUPPLIERS"
                  checked={formData.target === "SUPPLIERS"}
                  onChange={(e) =>
                    setFormData({ ...formData, target: e.target.value })
                  }
                  className="hidden"
                />
                <Users className="w-5 h-5" />
                <span className="font-medium">تامین‌کنندگان</span>
              </label>
              <label
                className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-colors ${formData.target === "STORES" ? "border-primary-default bg-primary-default/10 text-primary-hover" : "border-subtle hover:bg-background"}`}
              >
                
                <input
                  type="radio"
                  name="target"
                  value="STORES"
                  checked={formData.target === "STORES"}
                  onChange={(e) =>
                    setFormData({ ...formData, target: e.target.value })
                  }
                  className="hidden"
                />
                <Store className="w-5 h-5" />
                <span className="font-medium">فروشگاه‌ها</span>
              </label>
            </div>
          </div>
          <div>
            
            <label className="block text-sm font-semibold text-secondary mb-3">
              نوع اعلان
            </label>
            <div className="flex gap-4">
              
              <label className="flex items-center gap-2 cursor-pointer">
                
                <input
                  type="radio"
                  name="type"
                  value="INFO"
                  checked={formData.type === "INFO"}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value })
                  }
                  className="w-4 h-4 text-primary-default"
                />
                <span className="text-sm">اطلاع‌رسانی عمومی</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                
                <input
                  type="radio"
                  name="type"
                  value="SYSTEM"
                  checked={formData.type === "SYSTEM"}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value })
                  }
                  className="w-4 h-4 text-primary-default"
                />
                <span className="text-sm">اعلان سیستمی (مهم)</span>
              </label>
            </div>
          </div>
          <div>
            
            <label className="block text-sm font-semibold text-secondary mb-2">
              متن پیام
            </label>
            <textarea
              required
              rows={4}
              value={formData.message}
              onChange={(e) =>
                setFormData({ ...formData, message: e.target.value })
              }
              placeholder="پیام خود را بنویسید..."
              className="w-full px-4 py-3 bg-background border border-subtle rounded-xl text-sm focus:outline-none focus:border-primary-default"
            ></textarea>
          </div>
          <div className="flex justify-end">
            
            <button
              type="submit"
              className="flex items-center gap-2 bg-primary-default text-inverse px-6 py-3 rounded-xl font-medium hover:bg-primary-hover transition-colors"
            >
              
              <Send className="w-5 h-5" /> ارسال اعلان
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
