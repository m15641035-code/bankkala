import React, { useState, useEffect } from "react";
import { Plus } from "lucide-react";
export default function Categories() {
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("/api/admin/categories", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setCategories(data);
        else setCategories([]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);
  return (
    <div className="p-8 space-y-6 animate-fade-in">
      
      <div className="flex justify-between items-center">
        
        <div>
          
          <h2 className="text-2xl font-bold text-primary">دسته‌بندی‌ها</h2>
          <p className="text-muted mt-1">مدیریت دسته‌بندی محصولات</p>
        </div>
        <button className="flex items-center gap-2 bg-primary-default text-inverse px-4 py-2 rounded-xl text-sm font-medium hover:bg-primary-hover">
          
          <Plus className="w-4 h-4" /> افزودن دسته جدید
        </button>
      </div>
      {loading ? (
        <div className="text-center p-12 text-muted">در حال بارگذاری...</div>
      ) : (
        <div className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden">
          
          <table className="w-full text-right text-sm">
            
            <thead className="bg-background border-b border-subtle text-muted font-medium">
              
              <tr>
                
                <th className="px-6 py-4">شناسه</th>
                <th className="px-6 py-4">نام دسته‌بندی</th>
                <th className="px-6 py-4">وضعیت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              
              {categories.map((c) => (
                <tr key={c.id} className="hover:bg-background">
                  
                  <td className="px-6 py-4 font-mono text-muted">
                    #{c.id}
                  </td>
                  <td className="px-6 py-4 font-semibold text-primary">
                    {c.name}
                  </td>
                  <td className="px-6 py-4">
                    
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-semibold ${c.isActive ? "bg-success/20 text-success" : "bg-surface text-secondary"}`}
                    >
                      
                      {c.isActive ? "فعال" : "غیرفعال"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
