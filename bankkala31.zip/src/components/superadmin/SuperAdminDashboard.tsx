import React, { useState } from "react";
import { Image, 
  LayoutDashboard,
  Users,
  Store,
  Package,
  ShoppingCart,
  Wallet,
  Tags,
  Bell,
  MessageSquare,
  Settings,
  Activity,
  ShieldCheck,
  LogOut,
  DollarSign,
  X,
  Megaphone,
  Sliders,
  Scale,
} from "lucide-react";
import Overview from "./Overview";
import SuppliersList from "./SuppliersList";
import StoresList from "./StoresList";
import ProductsList from "./ProductsList";
import OrdersList from "./OrdersList";
import Financial from "./Financial";
import SettlementsList from "./SettlementsList";
import Categories from "./Categories";
import Tickets from "./Tickets";
import SystemSettings from "./SystemSettings";
import SystemLogs from "./SystemLogs";
import SystemHealth from "./SystemHealth";
import Notifications from "./Notifications";
import ManualInvoices from "./ManualInvoices";
import AdminAnnouncements from "./AdminAnnouncements";
import SuperAdminNewFeatures from "./SuperAdminNewFeatures";
import SupplierPenaltyManagement from "./SupplierPenaltyManagement";
import AdminBanners from "./AdminBanners";
import ReferrersList from "./ReferrersList";
export default function SuperAdminDashboard({
  user,
  onLogout,
  showNotification,
}: {
  user?: any;
  onLogout: () => void;
  showNotification?: (message: string, type: "success" | "error") => void;
}) {
  const [activeTab, setActiveTab] = useState("overview");
  const menuItems = [
    { id: "overview", label: "پیشخوان", icon: LayoutDashboard },
    { id: "suppliers", label: "تامین کنندگان", icon: Users },
    { id: "referrers", label: "همکاران معرف", icon: Users },
    { id: "penalty-management", label: "اخطارها و قوانین تامین‌کنندگان", icon: Scale },
    { id: "stores", label: "فروشگاه‌ها", icon: Store },
    { id: "products", label: "محصولات", icon: Package },
    { id: "orders", label: "سفارشات", icon: ShoppingCart },
    { id: "financial", label: "امور مالی", icon: DollarSign },
    { id: "manual-invoices", label: "تایید فیش‌ها", icon: DollarSign },
    { id: "settlements", label: "درخواست‌های تسویه", icon: Wallet },
    { id: "categories", label: "دسته‌بندی‌ها", icon: Tags },
    { id: "new-features-manager", label: "ابزارهای جدید سیستم", icon: Sliders },
    { id: "notifications", label: "اعلان‌ها", icon: Bell },
    { id: "announcements", label: "مدیریت اطلاعیه‌ها", icon: Megaphone },
    { id: "tickets", label: "تیکت‌ها", icon: MessageSquare },
    { id: "settings", label: "تنظیمات", icon: Settings },
    { id: "logs", label: "لاگ سیستم", icon: Activity },
    { id: "health", label: "سلامت سیستم", icon: ShieldCheck },
  ];
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  return (
    <div className="min-h-screen bg-background flex overflow-hidden" dir="rtl">
      
      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-background/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 right-0 w-64 bg-card border-l border-border-subtle text-text-primary flex flex-col z-50 transform transition-transform duration-300 ease-in-out ${mobileMenuOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"}`}
      >
        
        <div className="p-6 border-b border-border-subtle flex items-center justify-between">
          
          <div className="flex items-center gap-3">
            
            <div className="w-10 h-10 bg-primary-default rounded-xl flex items-center justify-center shadow-lg shadow-primary-default/20">
              
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              
              <h1 className="text-text-primary font-bold text-lg">
                مرکز فرماندهی
              </h1>
              <p className="text-xs text-text-muted">مدیریت کل سیستم</p>
            </div>
          </div>
          <button
            className="lg:hidden text-text-muted hover:text-text-primary"
            onClick={() => setMobileMenuOpen(false)}
          >
            
            <X className="w-6 h-6" />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${activeTab === item.id ? "bg-primary-default text-white shadow-lg shadow-primary-default/20" : "text-text-secondary hover:bg-surface hover:text-text-primary"}`}
            >
              
              <item.icon
                className={`w-5 h-5 ${activeTab === item.id ? "text-white" : "text-text-muted"}`}
              />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-border-subtle">
          
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-surface text-danger rounded-xl text-sm font-medium hover:bg-surface/80 hover:text-danger transition-colors"
          >
            
            <LogOut className="w-5 h-5" /> خروج از حساب
          </button>
        </div>
      </aside>
      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        
        <header className="bg-card px-6 lg:px-8 py-5 flex items-center gap-4 border-b border-subtle shadow-sm z-0">
          
          <button
            className="lg:hidden p-2 -mr-2 text-muted hover:text-secondary bg-background rounded-xl"
            onClick={() => setMobileMenuOpen(true)}
          >
            
            <LayoutDashboard className="w-6 h-6" />
          </button>
          <h1 className="text-xl lg:text-2xl font-bold text-primary">
            
            {menuItems.find((i) => i.id === activeTab)?.label}
          </h1>
        </header>
        <div className="flex-1 overflow-y-auto p-4 lg:p-8 relative">
          
          {activeTab === "overview" && <Overview />}
          {activeTab === "suppliers" && <SuppliersList />}
          {activeTab === "referrers" && <ReferrersList />}
          {activeTab === "penalty-management" && <SupplierPenaltyManagement />}
          {activeTab === "stores" && <StoresList />}
          {activeTab === "products" && <ProductsList />}
          {activeTab === "orders" && <OrdersList />}
          {activeTab === "financial" && <Financial />}
          {activeTab === "manual-invoices" && <ManualInvoices />}
          {activeTab === "settlements" && <SettlementsList />}
          {activeTab === "categories" && <Categories />}
          {activeTab === "new-features-manager" && (
            <SuperAdminNewFeatures
              showNotification={showNotification || (() => {})}
            />
          )}
          {activeTab === "notifications" && <Notifications />}
          {activeTab === "announcements" && <AdminAnnouncements />}
          {activeTab === "banners" && <AdminBanners showNotification={showNotification} />}
          {activeTab === "tickets" && <Tickets />}
          {activeTab === "settings" && <SystemSettings />}
          {activeTab === "logs" && <SystemLogs />}
          {activeTab === "health" && <SystemHealth />}
        </div>
      </main>
    </div>
  );
}
