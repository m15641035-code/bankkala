import React, { useState, useEffect } from "react";
import UserModal, { ResetPasswordModal } from "./UserModal";
import {
  Search,
  Plus,
  Edit,
  KeyRound,
  MoreVertical,
  ShieldAlert,
  Ban,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
export default function SuppliersList() {
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const fetchSuppliers = () => {
    fetch("/api/admin/suppliers", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setSuppliers(data);
        else setSuppliers([]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };
  useEffect(() => {
    fetchSuppliers();
  }, []);
  const changeStatus = (id: number, status: string) => {
    const reason = prompt("لطفا دلیل تغییر وضعیت را وارد کنید (اختیاری):");
    fetch(`/api/admin/users/${id}/status`, { credentials: "include",
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        
      },
      body: JSON.stringify({ status, reason }),
    }).then(() => fetchSuppliers());
  };
  return (
    <div className="p-8 space-y-6 animate-fade-in">
      
      <div className="flex justify-between items-center">
        
        <div>
          
          <h2 className="text-2xl font-bold text-primary">
            مدیریت تامین کنندگان
          </h2>
          <p className="text-muted mt-1">
            لیست تمامی تامین کنندگان و وضعیت آنها
          </p>
        </div>
        <button
          onClick={() => {
            setSelectedUser(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-primary-default text-inverse rounded-xl hover:bg-primary-hover transition-colors font-medium text-sm ml-4"
        >
          
          <Plus className="w-4 h-4" /> افزودن تامین‌کننده جدید
        </button>
        <div className="relative">
          
          <Search className="w-5 h-5 text-muted absolute right-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="جستجوی تامین کننده..."
            className="pl-4 pr-12 py-3 bg-card border border-subtle rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default w-72"
          />
        </div>
      </div>
      {loading ? (
        <div className="text-center p-12 text-muted">در حال بارگذاری...</div>
      ) : (
        <div className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden">
          
          <table className="w-full text-right text-sm">
            
            <thead className="bg-background border-b border-subtle text-muted font-medium">
              
              <tr>
                
                <th className="px-6 py-4">شناسه</th>
                <th className="px-6 py-4">نام تجاری</th>
                <th className="px-6 py-4">نام و نام خانوادگی</th>
                <th className="px-6 py-4">موبایل</th>
                <th className="px-6 py-4">شاخص سلامت عملکرد</th>
                <th className="px-6 py-4">وضعیت</th>
                <th className="px-6 py-4">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              
              {suppliers.map((s) => (
                <tr
                  key={s.id}
                  className="hover:bg-background transition-colors"
                >
                  
                  <td className="px-6 py-4 font-mono text-muted">
                    #{s.id}
                  </td>
                  <td className="px-6 py-4 font-bold text-primary">
                    {s.brandName || "-"}
                  </td>
                  <td className="px-6 py-4">
                    {s.firstName} {s.lastName}
                  </td>
                  <td className="px-6 py-4 font-mono text-left" dir="ltr">
                    {s.mobile}
                  </td>
                  <td className="px-6 py-4">
                    {s.healthMetrics ? (
                      <div className="flex flex-col gap-1 text-right">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-black px-2 py-0.5 rounded-lg ${s.healthMetrics.healthScore >= 90 ? "bg-success/10 text-success dark:text-success" : s.healthMetrics.healthScore >= 75 ? "bg-warning/10 text-warning dark:text-warning" : "bg-danger/10 text-danger dark:text-danger"}`}>
                            {s.healthMetrics.healthScore} از ۱۰۰
                          </span>
                        </div>
                        <div className="text-[10px] text-muted leading-none">
                          تاخیر: {s.healthMetrics.delayCount} | لغو: {s.healthMetrics.cancelCount} | مرجوعی: {s.healthMetrics.returnCount}
                        </div>
                        <div className="text-[9px] text-muted/80 leading-none">
                          رضایت: {s.healthMetrics.satisfaction}٪ | پاسخگویی: {s.healthMetrics.responsiveness}٪
                        </div>
                      </div>
                    ) : (
                      <span className="text-xs text-muted">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold ${s.status === "ACTIVE" ? "bg-success/20 text-success" : s.status === "BLOCKED" ? "bg-danger/20 text-danger" : s.status === "WARNING" ? "bg-warning/20 text-warning" : "bg-surface text-secondary"}`}
                    >
                      
                      {s.status === "ACTIVE"
                        ? "فعال"
                        : s.status === "BLOCKED"
                          ? "مسدود شده"
                          : s.status === "WARNING"
                            ? "دارای اخطار"
                            : s.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    
                    <div className="flex gap-2">
                      
                      <button
                        onClick={() => {
                          setSelectedUser(s);
                          setIsModalOpen(true);
                        }}
                        className="p-2 text-primary-default hover:bg-primary-default/10 rounded-lg"
                        title="ویرایش"
                      >
                        
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedUser(s);
                          setIsResetModalOpen(true);
                        }}
                        className="p-2 text-muted hover:bg-background rounded-lg"
                        title="تغییر رمز عبور"
                      >
                        
                        <KeyRound className="w-5 h-5" />
                      </button>
                      {s.status !== "ACTIVE" && (
                        <button
                          onClick={() => changeStatus(s.id, "ACTIVE")}
                          className="p-2 text-success hover:bg-success/10 rounded-lg"
                          title="فعال سازی"
                        >
                          
                          <CheckCircle2 className="w-5 h-5" />
                        </button>
                      )}
                      {s.status !== "WARNING" && (
                        <button
                          onClick={() => changeStatus(s.id, "WARNING")}
                          className="p-2 text-warning hover:bg-warning/10 rounded-lg"
                          title="ارسال اخطار"
                        >
                          
                          <AlertCircle className="w-5 h-5" />
                        </button>
                      )}
                      {s.status !== "BLOCKED" && (
                        <button
                          onClick={() => changeStatus(s.id, "BLOCKED")}
                          className="p-2 text-danger hover:bg-danger/10 rounded-lg"
                          title="مسدود کردن"
                        >
                          
                          <Ban className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {isModalOpen && (
        <UserModal
          user={selectedUser}
          role="SUPPLIER"
          onClose={() => setIsModalOpen(false)}
          onSuccess={() => {
            setIsModalOpen(false);
            fetchSuppliers();
          }}
        />
      )}
      {isResetModalOpen && selectedUser && (
        <ResetPasswordModal
          userId={selectedUser.id}
          onClose={() => setIsResetModalOpen(false)}
          onSuccess={() => setIsResetModalOpen(false)}
        />
      )}
    </div>
  );
}
