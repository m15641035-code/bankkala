import React, { useState } from "react";
import {
  Package,
  Upload,
  Plus,
  Trash2,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
const CATEGORIES = [
  "موبایل",
  "لپ‌تاپ",
  "کالای دیجیتال",
  "خانه و آشپزخانه",
  "لوازم خانگی برقی",
  "آرایشی و بهداشتی",
  "مد و پوشاک",
  "طلا و نقره",
  "خودرو و موتورسیکلت",
  "سلامت و پزشکی",
  "ابزارآلات و تجهیزات",
  "کتاب و هنر",
  "ورزش و سفر",
  "اسباب بازی کودک و نوزاد",
  "محصولات بومی و محلی",
  "پت شاپ",
];
export function SupplierAddProduct({
  onSuccess,
  onCancel,
  showNotification,
  initialData,
}: any) {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  /* Form Data */ const [formData, setFormData] = useState({
    name: initialData?.name || "",
    shortDescription: initialData?.shortDescription || "",
    longDescription: initialData?.longDescription || "",
    categoryId: initialData?.categoryId?.toString() || "",
    brand: initialData?.brand || "",
    sku: initialData?.sku || "",
    supplierBasePrice: initialData?.supplierBasePrice?.toString() || "",
    discount: initialData?.discount?.toString() || "",
    stock: initialData?.variants?.[0]?.stock?.toString() || "",
    minStock: "",
    images: initialData?.images?.map((img: any) => img.url) || ([] as string[]),
    mainImage: initialData?.images?.[0]?.url || "",
    variants: initialData?.variants || ([] as any[]),
  });
  /* Variant Building */ const [attributes, setAttributes] = useState<
    { name: string; values: string[] }[]
  >([]);
  const [newAttrName, setNewAttrName] = useState("");
  const [newAttrValue, setNewAttrValue] = useState("");
  const nextStep = () => setStep((prev) => Math.min(prev + 1, 5));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));
  const addAttribute = () => {
    if (!newAttrName.trim()) return;
    setAttributes([...attributes, { name: newAttrName, values: [] }]);
    setNewAttrName("");
  };
  const addAttributeValue = (index: number) => {
    if (!newAttrValue.trim()) return;
    const newAttrs = [...attributes];
    if (!newAttrs[index].values.includes(newAttrValue)) {
      newAttrs[index].values.push(newAttrValue);
    }
    setAttributes(newAttrs);
    setNewAttrValue("");
    generateMatrix(newAttrs);
  };
  const generateMatrix = (attrs: any[]) => {
    if (attrs.length === 0) {
      setFormData({ ...formData, variants: [] });
      return;
    }
    /* Cartesian product of attribute values */ const cartesian = (
      arrays: any[][],
    ) => {
      return arrays.reduce(
        (a, b) =>
          a
            .map((x) => b.map((y) => x.concat([y])))
            .reduce((c, d) => c.concat(d), []),
        [[]],
      );
    };
    const validAttrs = attrs.filter((a) => a.values.length > 0);
    if (validAttrs.length === 0) return;
    const valuesArrays = validAttrs.map((a) =>
      a.values.map((v) => ({ [a.name]: v })),
    );
    const combinations = cartesian(valuesArrays).map((combo) => {
      /* flatten */ const attrObj = Object.assign({}, ...combo);
      return {
        attributes: attrObj,
        supplierBasePrice: formData.supplierBasePrice || "",
        stock: "",
        sku: "",
      };
    });
    setFormData({ ...formData, variants: combinations });
  };
  const removeAttribute = (index: number) => {
    const newAttrs = attributes.filter((_, i) => i !== index);
    setAttributes(newAttrs);
    generateMatrix(newAttrs);
  };
  const handleVariantChange = (index: number, field: string, value: string) => {
    const newVariants = [...formData.variants];
    newVariants[index][field] = value;
    setFormData({ ...formData, variants: newVariants });
  };
  const handleSubmit = async () => {
    if (
      !formData.name ||
      !formData.categoryId ||
      !formData.supplierBasePrice ||
      !formData.stock
    ) {
      showNotification(
        "لطفاً فیلدهای اجباری (نام، دسته‌بندی، قیمت پایه و موجودی کل) را پر کنید",
        "error",
      );
      return;
    }
    setIsSubmitting(true);
    try {
      const token = localStorage.getItem("token") || "";
      const url = initialData?.id
        ? `/api/supplier/products/${initialData.id}`
        : "/api/supplier/products";
      const method = initialData?.id ? "PUT" : "POST";
      const res = await fetch(url, { credentials: "include",
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        showNotification(
          initialData?.id
            ? "محصول با موفقیت ویرایش شد"
            : "محصول با موفقیت ثبت شد و در انتظار تایید است",
          "success",
        );
        onSuccess();
      } else {
        const data = await res.json();
        showNotification(data.error || "خطا در ثبت محصول", "error");
      }
    } catch (err) {
      showNotification("خطا در ارتباط با سرور", "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  const steps = [
    "اطلاعات اصلی",
    "قیمت و موجودی",
    "ویژگی‌ها و متغیرها",
    "رسانه",
    "بررسی و ثبت",
  ];
  return (
    <div className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden animate-fade-in">
      
      {/* Stepper */}
      <div className="bg-background border-b border-subtle p-6">
        
        <div className="flex items-center justify-between max-w-3xl mx-auto">
          
          {steps.map((s, i) => (
            <div key={i} className="flex flex-col items-center relative z-10">
              
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm mb-2 transition-colors ${step > i + 1 ? "bg-success text-inverse" : step === i + 1 ? "bg-primary-default text-inverse shadow-md shadow-indigo-200" : "bg-surface text-muted"}`}
              >
                
                {step > i + 1 ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  i + 1
                )}
              </div>
              <span
                className={`text-xs font-semibold ${step === i + 1 ? "text-primary-hover" : "text-muted"}`}
              >
                
                {s}
              </span>
            </div>
          ))}
        </div>
      </div>
      <div className="p-8 max-w-3xl mx-auto min-h-[400px]">
        
        {/* Step 1: Basic Info */}
        {step === 1 && (
          <div className="space-y-5 animate-fade-in">
            
            <h3 className="text-lg font-bold text-primary mb-6 border-b pb-2">
              اطلاعات اصلی محصول
            </h3>
            <div>
              
              <label className="block text-sm font-semibold text-secondary mb-1.5">
                نام محصول *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none"
                placeholder="مثال: لپ‌تاپ ایسوس مدل ZenBook"
              />
            </div>
            <div className="grid grid-cols-2 gap-5">
              
              <div>
                
                <label className="block text-sm font-semibold text-secondary mb-1.5">
                  دسته‌بندی *
                </label>
                <select
                  value={formData.categoryId}
                  onChange={(e) =>
                    setFormData({ ...formData, categoryId: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none"
                >
                  
                  <option value="">انتخاب کنید...</option>
                  {CATEGORIES.map((cat, i) => (
                    <option key={i} value={i + 1}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                
                <label className="block text-sm font-semibold text-secondary mb-1.5">
                  برند
                </label>
                <input
                  type="text"
                  value={formData.brand}
                  onChange={(e) =>
                    setFormData({ ...formData, brand: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none"
                />
              </div>
            </div>
            <div>
              
              <label className="block text-sm font-semibold text-secondary mb-1.5">
                توضیح کوتاه
              </label>
              <textarea
                value={formData.shortDescription}
                onChange={(e) =>
                  setFormData({ ...formData, shortDescription: e.target.value })
                }
                className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none h-20 resize-none"
                placeholder="یک پاراگراف کوتاه در معرفی محصول..."
              ></textarea>
            </div>
            <div>
              
              <label className="block text-sm font-semibold text-secondary mb-1.5">
                توضیح کامل
              </label>
              <textarea
                value={formData.longDescription}
                onChange={(e) =>
                  setFormData({ ...formData, longDescription: e.target.value })
                }
                className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none h-32 resize-none"
                placeholder="توضیحات کامل محصول در اینجا..."
              ></textarea>
            </div>
          </div>
        )}
        {/* Step 2: Price & Inventory */}
        {step === 2 && (
          <div className="space-y-5 animate-fade-in">
            
            <h3 className="text-lg font-bold text-primary mb-6 border-b pb-2">
              قیمت و موجودی
            </h3>
            <div className="bg-primary-default/10 p-4 rounded-xl border border-primary-default/20 mb-6">
              
              <p className="text-sm text-primary-hover font-medium">
                
                توجه: مبلغ وارد شده به عنوان"قیمت پایه تامین‌کننده" مبلغی است که
                با شما تسویه می‌شود. قیمت نهایی برای مشتری توسط پلتفرم محاسبه و
                تعیین می‌گردد.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              
              <div>
                
                <label className="block text-sm font-semibold text-secondary mb-1.5">
                  قیمت پایه تامین‌کننده (تومان) *
                </label>
                <input
                  type="number"
                  value={formData.supplierBasePrice}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      supplierBasePrice: e.target.value,
                    })
                  }
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none text-left"
                  dir="ltr"
                />
              </div>
              <div>
                
                <label className="block text-sm font-semibold text-secondary mb-1.5">
                  موجودی کل *
                </label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) =>
                    setFormData({ ...formData, stock: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none text-left"
                  dir="ltr"
                  required
                />
              </div>
              <div>
                
                <label className="block text-sm font-semibold text-secondary mb-1.5">
                  هشدار حداقل موجودی
                </label>
                <input
                  type="number"
                  value={formData.minStock}
                  onChange={(e) =>
                    setFormData({ ...formData, minStock: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-background border border-subtle rounded-xl focus:ring-2 focus:ring-primary-default outline-none text-left"
                  dir="ltr"
                  placeholder="مثال: 5"
                />
              </div>
            </div>
          </div>
        )}
        {/* Step 3: Variants */}
        {step === 3 && (
          <div className="space-y-6 animate-fade-in">
            
            <h3 className="text-lg font-bold text-primary mb-2">
              ویژگی‌ها و متغیرها
            </h3>
            <p className="text-sm text-muted mb-6 pb-2 border-b">
              اگر محصول شما دارای رنگ، سایز یا ویژگی‌های متغیر است، در این بخش
              تعریف کنید.
            </p>
            {/* Add Attribute */}
            <div className="flex gap-2">
              
              <input
                type="text"
                value={newAttrName}
                onChange={(e) => setNewAttrName(e.target.value)}
                placeholder="نام ویژگی جدید (مثال: رنگ)"
                className="flex-1 px-4 py-2.5 bg-background border border-subtle rounded-xl text-sm"
              />
              <button
                onClick={addAttribute}
                className="bg-primary-default text-inverse hover:bg-primary-hover px-5 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-colors"
              >
                
                افزودن ویژگی
              </button>
            </div>
            {/* Attributes List */}
            {attributes.map((attr, idx) => (
              <div
                key={idx}
                className="bg-background p-4 rounded-xl border border-subtle"
              >
                
                <div className="flex justify-between items-center mb-3">
                  
                  <h4 className="font-bold text-primary">{attr.name}</h4>
                  <button
                    onClick={() => removeAttribute(idx)}
                    className="text-danger hover:bg-danger/10 p-1.5 rounded-lg"
                  >
                    
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mb-3">
                  
                  {attr.values.map((v, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-card border border-subtle rounded-lg text-sm text-secondary flex items-center gap-2"
                    >
                      
                      {v}
                    </span>
                  ))}
                </div>
                <div className="flex gap-2">
                  
                  <input
                    type="text"
                    value={newAttrValue}
                    onChange={(e) => setNewAttrValue(e.target.value)}
                    placeholder="مقدار جدید (مثال: قرمز)"
                    className="flex-1 px-4 py-2 bg-card border border-subtle rounded-lg text-sm"
                  />
                  <button
                    onClick={() => addAttributeValue(idx)}
                    className="bg-primary-default/20 text-primary-hover px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-200 transition-colors"
                  >
                    
                    افزودن مقدار
                  </button>
                </div>
              </div>
            ))}
            {/* Variation Matrix */}
            {formData.variants.length > 0 && (
              <div className="mt-8 border-t pt-6">
                
                <h4 className="font-bold text-primary mb-4">
                  لیست متغیرهای ایجاد شده
                </h4>
                <div className="overflow-x-auto">
                  
                  <table className="w-full text-right text-sm">
                    
                    <thead className="bg-surface text-muted">
                      
                      <tr>
                        
                        <th className="p-3 rounded-r-lg">
                          ترکیب ویژگی‌ها
                        </th>
                        <th className="p-3">قیمت پایه (تومان)</th>
                        <th className="p-3 rounded-l-lg">موجودی</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                      {formData.variants.map((v, idx) => (
                        <tr key={idx} className="border-b border-subtle">
                          
                          <td className="p-3 font-medium text-primary">
                            
                            {Object.values(v.attributes).join(" -")}
                          </td>
                          <td className="p-3">
                            
                            <input
                              type="number"
                              value={v.supplierBasePrice}
                              onChange={(e) =>
                                handleVariantChange(
                                  idx,
                                  "supplierBasePrice",
                                  e.target.value,
                                )
                              }
                              className="w-32 px-3 py-1.5 bg-background border border-subtle rounded text-sm outline-none"
                              dir="ltr"
                            />
                          </td>
                          <td className="p-3">
                            
                            <input
                              type="number"
                              value={v.stock}
                              onChange={(e) =>
                                handleVariantChange(
                                  idx,
                                  "stock",
                                  e.target.value,
                                )
                              }
                              className="w-24 px-3 py-1.5 bg-background border border-subtle rounded text-sm outline-none"
                              dir="ltr"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
        {/* Step 4: Media */}
        {step === 4 && (
          <div className="space-y-6 animate-fade-in">
            
            <h3 className="text-lg font-bold text-primary mb-2">
              رسانه محصول
            </h3>
            <p className="text-sm text-muted mb-6 pb-2 border-b">
              تصویر اصلی و گالری تصاویر محصول را بارگذاری کنید.
            </p>
            <div>
              
              <label className="block text-sm font-semibold text-secondary mb-2">
                تصویر اصلی محصول (شاخص)
              </label>
              <div className="border-2 border-dashed border-default rounded-2xl h-48 flex flex-col items-center justify-center text-muted hover:bg-background transition-colors cursor-pointer relative overflow-hidden">
                
                {formData.mainImage ? (
                  <img
                    src={formData.mainImage}
                    className="w-full h-full object-cover"
                    alt="Main preview"
                  />
                ) : (
                  <>
                    
                    <Upload className="w-8 h-8 mb-2 text-muted" />
                    <span className="text-sm font-medium">
                      برای آپلود تصویر کلیک کنید
                    </span>
                    <span className="text-xs mt-1">
                      فرمت‌های مجاز: JPG, PNG, WEBP
                    </span>
                  </>
                )}
                {/* Mock file input trigger for demo purposes */}
                <input
                  type="file"
                  accept="image/*"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      if (file.size > 2 * 1024 * 1024) {
                        alert("حجم تصویر نباید بیشتر از 2 مگابایت باشد.");
                        return;
                      }
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        setFormData({
                          ...formData,
                          mainImage: reader.result as string,
                        });
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </div>
            </div>
            <div>
              
              <label className="block text-sm font-semibold text-secondary mb-2">
                گالری تصاویر (انتخابی)
              </label>
              <div className="grid grid-cols-4 gap-4">
                
                {formData.images.map((img, i) => (
                  <div
                    key={i}
                    className="aspect-square bg-surface rounded-xl border border-subtle overflow-hidden relative group"
                  >
                    
                    <img
                      src={img}
                      className="w-full h-full object-cover"
                      alt={`gallery-${i}`}
                    />
                    <button
                      onClick={() =>
                        setFormData({
                          ...formData,
                          images: formData.images.filter((_, idx) => idx !== i),
                        })
                      }
                      className="absolute top-2 right-2 bg-card/90 p-1.5 rounded-lg text-danger opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <div className="aspect-square border-2 border-dashed border-default rounded-xl flex items-center justify-center text-muted hover:bg-background cursor-pointer relative">
                  
                  <Plus className="w-8 h-8" />
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={async (e) => {
                      if (e.target.files) {
                        const files = Array.from(e.target.files);
                        const validFiles = files.filter(
                          (f: any) => f.size <= 2 * 1024 * 1024,
                        );
                        if (validFiles.length < files.length) {
                          alert("حجم تصاویر نباید بیشتر از 2 مگابایت باشد.");
                        }
                        const urls = await Promise.all(
                          validFiles.map(
                            (f: any) =>
                              new Promise<string>((resolve) => {
                                const reader = new FileReader();
                                reader.onloadend = () =>
                                  resolve(reader.result as string);
                                reader.readAsDataURL(f);
                              }),
                          ),
                        );
                        setFormData({
                          ...formData,
                          images: [...formData.images, ...urls],
                        });
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
        {/* Step 5: Review & Submit */}
        {step === 5 && (
          <div className="space-y-6 animate-fade-in">
            
            <h3 className="text-lg font-bold text-primary mb-6 border-b pb-2">
              بررسی و ثبت نهایی
            </h3>
            <div className="bg-background p-6 rounded-2xl border border-subtle flex gap-6">
              
              <div className="w-32 h-32 bg-surface rounded-xl overflow-hidden shrink-0">
                
                {formData.mainImage ? (
                  <img
                    src={formData.mainImage}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted">
                    بدون تصویر
                  </div>
                )}
              </div>
              <div className="flex-1">
                
                <h4 className="text-xl font-bold text-primary">
                  {formData.name || "بدون نام"}
                </h4>
                <div className="grid grid-cols-2 gap-y-2 mt-4 text-sm">
                  
                  <p className="text-muted">
                    دسته‌بندی:
                    <span className="font-semibold text-primary">
                      {CATEGORIES[Number(formData.categoryId) - 1] || "-"}
                    </span>
                  </p>
                  <p className="text-muted">
                    برند:
                    <span className="font-semibold text-primary">
                      {formData.brand || "-"}
                    </span>
                  </p>
                  <p className="text-muted">
                    قیمت پایه:
                    <span className="font-bold text-primary-default">
                      {Number(formData.supplierBasePrice).toLocaleString()}
                      تومان
                    </span>
                  </p>
                  <p className="text-muted">
                    موجودی:
                    <span className="font-semibold text-primary">
                      {formData.stock}
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-warning/10 p-4 rounded-xl border border-amber-100 text-sm text-amber-800 flex items-start gap-3">
              
              <CheckCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <p>
                
                با ثبت این محصول تایید می‌کنم که اطلاعات وارد شده صحیح است. پس
                از تایید توسط مدیر سیستم، محصول در ویترین پلتفرم قرار خواهد
                گرفت.
              </p>
            </div>
          </div>
        )}
      </div>
      {/* Footer Controls */}
      <div className="p-6 border-t border-subtle flex justify-between items-center bg-card rounded-b-2xl">
        
        <button
          onClick={step === 1 ? onCancel : prevStep}
          className="px-6 py-2.5 rounded-xl text-sm font-medium text-text-secondary bg-surface hover:bg-surface transition-colors flex items-center gap-2"
        >
          
          {step === 1 ? (
            "انصراف"
          ) : (
            <>
              <ChevronRight className="w-4 h-4" /> مرحله قبل
            </>
          )}
        </button>
        {step < 5 ? (
          <button
            onClick={nextStep}
            className="px-6 py-2.5 rounded-xl text-sm font-medium text-inverse bg-primary-default hover:bg-primary-hover transition-colors shadow-sm flex items-center gap-2"
          >
            
            مرحله بعد <ChevronLeft className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="px-8 py-2.5 rounded-xl text-sm font-bold text-inverse bg-success hover:bg-emerald-700 transition-colors shadow-md disabled:opacity-50"
          >
            
            {isSubmitting ? "در حال پردازش..." : "ثبت نهایی محصول"}
          </button>
        )}
      </div>
    </div>
  );
}
