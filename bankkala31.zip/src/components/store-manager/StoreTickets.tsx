import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Send,
  Plus,
  Clock,
  User,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
export default function StoreTickets() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [newSubject, setNewSubject] = useState("");
  const [newDept, setNewDept] = useState("فنی");
  const [newPriority, setNewPriority] = useState("MEDIUM");
  const [newMsg, setNewMsg] = useState("");
  const [replyMsg, setReplyMsg] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [notification, setNotification] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const fetchTickets = () => {
    setLoading(true);
    fetch("/api/store-manager/tickets", { credentials: "include",
      headers: { /* Auth Header Removed */ },
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setTickets(data);
        } else {
          setTickets([]);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };
  useEffect(() => {
    fetchTickets();
  }, []);
  useEffect(() => {
    if (selectedTicket) {
      const updated = tickets.find((t) => t.id === selectedTicket.id);
      if (updated) {
        setSelectedTicket(updated);
      }
    }
  }, [tickets]);
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim() || !newMsg.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/store-manager/tickets", { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          
        },
        body: JSON.stringify({
          subject: newSubject,
          department: newDept,
          priority: newPriority,
          message: newMsg,
        }),
      });
      if (res.ok) {
        setNewSubject("");
        setNewMsg("");
        setShowCreateModal(false);
        showNotification(
          "تیکت شما با موفقیت ثبت شد و به بخش مدیریت ارسال گردید.",
          "success",
        );
        fetchTickets();
      } else {
        showNotification("خطا در ایجاد تیکت جدید", "error");
      }
    } catch (err) {
      showNotification("خطای شبکه در ارتباط با سرور", "error");
    } finally {
      setSubmitting(false);
    }
  };
  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMsg.trim() || !selectedTicket) return;
    setSubmitting(true);
    try {
      const res = await fetch(
        `/api/store-manager/tickets/${selectedTicket.id}/messages`, { credentials: "include",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            
          },
          body: JSON.stringify({ message: replyMsg }),
        },
      );
      if (res.ok) {
        setReplyMsg("");
        showNotification("پیام شما با موفقیت ارسال شد.", "success");
        fetchTickets();
      } else {
        showNotification("خطا در ارسال پیام", "error");
      }
    } catch (err) {
      showNotification("خطای شبکه در ارتباط با سرور", "error");
    } finally {
      setSubmitting(false);
    }
  };
  const showNotification = (message: string, type: "success" | "error") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };
  return (
    <div className="space-y-6 animate-fade-in text-right" dir="rtl">
      
      {/* Notifications */}
      {notification && (
        <div
          className={`fixed top-4 left-4 z-50 px-4 py-3 rounded-xl shadow-lg border text-sm flex items-center gap-2 animate-bounce ${notification.type === "success" ? "bg-success/10 border-emerald-100 text-emerald-800" : "bg-danger/10 border-rose-100 text-rose-800"}`}
        >
          
          {notification.type === "success" ? (
            <CheckCircle2 className="w-5 h-5 text-success" />
          ) : (
            <AlertCircle className="w-5 h-5 text-danger" />
          )}
          <span>{notification.message}</span>
        </div>
      )}
      {/* Header */}
      <div className="flex justify-between items-center flex-wrap gap-4">
        
        <div>
          
          <h2 className="text-xl font-bold text-primary">
            پشتیبانی و تیکت‌ها
          </h2>
          <p className="text-muted text-xs mt-1">
            با کارشناسان و مدیریت کل بانک کالا در ارتباط باشید
          </p>
        </div>
        {!selectedTicket && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-success hover:bg-emerald-700 text-inverse rounded-xl text-xs font-bold transition-all shadow-sm shadow-emerald-100 cursor-pointer"
          >
            
            <Plus className="w-4 h-4" /> ثبت تیکت جدید
          </button>
        )}
      </div>
      {!selectedTicket ? (
        /* Tickets List View */ loading ? (
          <div className="text-center p-12 text-muted font-medium">
            در حال بارگذاری تیکت‌ها...
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            
            {tickets.map((t) => (
              <div
                key={t.id}
                className="bg-card p-5 rounded-2xl border border-subtle shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
              >
                
                <div className="space-y-1">
                  
                  <div className="flex items-center gap-2.5 flex-wrap">
                    
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-bold ${t.status === "OPEN" ? "bg-danger/20 text-danger" : t.status === "ANSWERED" ? "bg-success/20 text-success" : "bg-surface text-secondary"}`}
                    >
                      
                      {t.status === "OPEN"
                        ? "منتظر پاسخ"
                        : t.status === "ANSWERED"
                          ? "پاسخ داده شده"
                          : "بسته شده"}
                    </span>
                    <span className="text-sm font-bold text-primary">
                      {t.subject}
                    </span>
                    <span className="px-2 py-0.5 bg-surface text-muted rounded text-[10px] font-bold">
                      {t.department}
                    </span>
                  </div>
                  <div className="text-xs text-muted flex gap-4 mt-1 font-mono">
                    
                    <span className="flex items-center gap-1">
                      
                      <Clock className="w-3.5 h-3.5 text-muted" /> تاریخ ارسال:
                      {new Date(t.createdAt).toLocaleDateString("fa-IR")}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedTicket(t)}
                  className="flex items-center gap-1 px-4 py-2 bg-background text-secondary hover:bg-surface rounded-xl text-xs font-bold border border-subtle transition-colors cursor-pointer"
                >
                  
                  <MessageSquare className="w-4 h-4 text-muted" /> مشاهده
                  گفتگو
                </button>
              </div>
            ))}
            {tickets.length === 0 && (
              <div className="text-center py-16 bg-card rounded-2xl border border-dashed border-subtle text-muted font-medium">
                
                هیچ تیکت پشتیبانی ثبت نکرده‌اید. برای شروع دکمه «ثبت تیکت جدید»
                را کلیک کنید.
              </div>
            )}
          </div>
        )
      ) : (
        /* Active Conversation Chat View */ <div className="bg-card rounded-2xl border border-subtle shadow-sm overflow-hidden flex flex-col min-h-[450px]">
          
          {/* Conversation Header */}
          <div className="px-6 py-4 bg-background border-b border-subtle flex justify-between items-center">
            
            <div className="flex items-center gap-2">
              
              <button
                onClick={() => setSelectedTicket(null)}
                className="p-1 rounded-lg text-muted hover:bg-surface transition-colors cursor-pointer ml-1"
              >
                
                <ArrowRight className="w-5 h-5" />
              </button>
              <div>
                
                <h3 className="font-bold text-primary text-sm">
                  {selectedTicket.subject}
                </h3>
                <p className="text-[11px] text-muted mt-0.5">
                  
                  تیکت شماره #{selectedTicket.id} | دپارتمان:
                  {selectedTicket.department}
                </p>
              </div>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-xs font-bold ${selectedTicket.status === "OPEN" ? "bg-danger/20 text-danger" : "bg-success/20 text-success"}`}
            >
              
              {selectedTicket.status === "OPEN"
                ? "منتظر پاسخ"
                : "پاسخ داده شده"}
            </span>
          </div>
          {/* Messages Thread list */}
          <div className="p-6 flex-1 space-y-4 max-h-[350px] overflow-y-auto bg-background/30">
            
            {selectedTicket.messages?.map((msg: any) => {
              const isMe =
                msg.userId ===
                parseInt(
                  localStorage.getItem("user")
                    ? JSON.parse(localStorage.getItem("user")!).id
                    : "0",
                );
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col max-w-[80%] ${isMe ? "mr-auto items-start" : "ml-auto items-end"}`}
                >
                  
                  <div
                    className={`px-4 py-2.5 rounded-2xl text-sm ${isMe ? "bg-success text-inverse rounded-tr-none" : "bg-card text-primary border border-subtle shadow-sm rounded-tl-none"}`}
                  >
                    
                    <p className="whitespace-pre-wrap leading-relaxed">
                      {msg.message}
                    </p>
                  </div>
                  <span className="text-[9px] text-muted mt-1 px-1 font-mono">
                    
                    {new Date(msg.createdAt).toLocaleDateString(
                      "fa-IR",
                    )} ساعت
                    {new Date(msg.createdAt).toLocaleTimeString("fa-IR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
              );
            })}
          </div>
          {/* Conversation Input area */}
          <div className="p-4 border-t border-subtle bg-card">
            
            <form onSubmit={handleSendReply} className="flex gap-2 items-end">
              
              <textarea
                value={replyMsg}
                onChange={(e) => setReplyMsg(e.target.value)}
                placeholder="پاسخ خود را اینجا بنویسید..."
                className="flex-1 min-h-[60px] p-3 text-sm bg-background border border-subtle rounded-xl focus:outline-none focus:ring-2 focus:ring-success text-right resize-none"
                required
              />
              <button
                type="submit"
                disabled={submitting || !replyMsg.trim()}
                className="px-4 py-3 bg-success hover:bg-emerald-700 disabled:bg-surface text-inverse rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer h-10"
              >
                
                <Send className="w-4 h-4" /> ارسال پاسخ
              </button>
            </form>
          </div>
        </div>
      )}
      {/* Create Ticket Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/60 backdrop-blur-sm">
          
          <div className="bg-card w-full max-w-xl rounded-2xl shadow-xl overflow-hidden animate-fade-in text-right">
            
            <div className="px-6 py-4 bg-background border-b border-subtle flex justify-between items-center">
              
              <h3 className="font-bold text-primary text-sm">
                ثبت تیکت پشتیبانی جدید
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-xs text-muted hover:text-muted font-bold bg-card px-2 py-1 rounded border border-subtle transition-colors cursor-pointer"
              >
                
                انصراف
              </button>
            </div>
            <form onSubmit={handleCreateTicket} className="p-6 space-y-4">
              
              <div>
                
                <label className="block text-xs font-bold text-muted mb-1">
                  موضوع تیکت
                </label>
                <input
                  type="text"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  placeholder="موضوع تیکت خود را وارد کنید"
                  className="w-full p-2.5 text-sm border border-subtle rounded-xl focus:outline-none focus:ring-2 focus:ring-success text-right"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-xs font-bold text-muted mb-1">
                    دپارتمان
                  </label>
                  <select
                    value={newDept}
                    onChange={(e) => setNewDept(e.target.value)}
                    className="w-full p-2.5 text-sm border border-subtle rounded-xl focus:outline-none focus:ring-2 focus:ring-success text-right"
                  >
                    
                    <option value="مالی">مالی و حسابداری</option>
                    <option value="فنی">پشتیبانی فنی</option>
                    <option value="فروش">فروش و بازاریابی</option>
                    <option value="عمومی">عمومی و پیشنهادات</option>
                  </select>
                </div>
                <div>
                  
                  <label className="block text-xs font-bold text-muted mb-1">
                    اولویت
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value)}
                    className="w-full p-2.5 text-sm border border-subtle rounded-xl focus:outline-none focus:ring-2 focus:ring-success text-right"
                  >
                    
                    <option value="LOW">معمولی</option>
                    <option value="MEDIUM">متوسط</option>
                    <option value="HIGH">فوری / اضطراری</option>
                  </select>
                </div>
              </div>
              <div>
                
                <label className="block text-xs font-bold text-muted mb-1">
                  متن پیام پشتیبانی
                </label>
                <textarea
                  value={newMsg}
                  onChange={(e) => setNewMsg(e.target.value)}
                  placeholder="مشکل یا سوال خود را به طور کامل شرح دهید..."
                  className="w-full p-2.5 text-sm border border-subtle rounded-xl focus:outline-none focus:ring-2 focus:ring-success text-right min-h-[120px]"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 bg-success hover:bg-emerald-700 disabled:bg-surface text-inverse rounded-xl text-sm font-bold flex justify-center items-center gap-1.5 transition-all cursor-pointer"
              >
                
                {submitting ? "در حال ثبت..." : "ثبت و ارسال تیکت"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
