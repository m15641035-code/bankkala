import React, { useState, useEffect } from "react";
import { Layers, Trash2, X, Package, Info, Check, Plus } from "lucide-react";
export default function MyCatalog() {
  const [catalog, setCatalog] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState<number | null>(
    null,
  );
  const fetchCatalog = async () => {
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch("/api/store-manager/my-catalog", { credentials: "include",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setCatalog(await res.json());
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchCatalog();
  }, []);
  const handleRemove = async (productId: number) => {
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch(`/api/store-manager/my-catalog/${productId}`, { credentials: "include",
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchCatalog();
        setShowConfirmDelete(null);
        setSelectedProduct(null);
      } else {
        const data = await res.json();
        alert(data.error || "خطا در حذف محصول");
      }
    } catch (err) {
      alert("خطا در ارتباط با سرور");
    }
  };
  return (
    <div className="space-y-6 animate-fade-in">
      
      {selectedProduct && (
        <div
          className="fixed inset-0 bg-background/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setSelectedProduct(null)}
        >
          
          <div
            className="bg-card rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden my-8"
            onClick={(e) => e.stopPropagation()}
          >
            
            <div className="flex justify-between items-center p-6 border-b border-subtle">
              
              <h3 className="text-xl font-bold text-primary">
                جزئیات محصول
              </h3>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-2 hover:bg-surface rounded-full transition-colors text-muted"
              >
                
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Images */}
                <div className="space-y-4">
                  
                  <div className="aspect-square bg-surface rounded-2xl flex items-center justify-center overflow-hidden border border-subtle">
                    
                    {selectedProduct.images?.length > 0 ? (
                      <img
                        src={selectedProduct.images[0].url}
                        alt={selectedProduct.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Layers className="w-24 h-24 text-inverse" />
                    )}
                  </div>
                  {selectedProduct.images?.length > 1 && (
                    <div className="grid grid-cols-4 gap-2">
                      
                      {selectedProduct.images.slice(1).map((img: any) => (
                        <div
                          key={img.id}
                          className="aspect-square bg-surface rounded-xl overflow-hidden border border-subtle"
                        >
                          
                          <img
                            src={img.url}
                            className="w-full h-full object-cover"
                            alt=""
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                {/* Details */}
                <div className="flex flex-col">
                  
                  <div className="flex items-center gap-2 mb-3">
                    
                    <span className="text-xs font-bold text-success bg-success/10 px-3 py-1 rounded-full border border-emerald-100">
                      
                      {selectedProduct.category?.name || "بدون دسته‌بندی"}
                    </span>
                    <span className="text-xs font-bold text-muted bg-surface px-3 py-1 rounded-full border border-subtle">
                      
                      وضعیت:
                      {selectedProduct.status === "ACTIVE" ||
                      selectedProduct.status === "PUBLISHED"
                        ? "منتشر شده"
                        : selectedProduct.status}
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-primary mb-2">
                    {selectedProduct.name}
                  </h2>
                  <p className="text-muted text-sm mb-6 leading-relaxed">
                    
                    {selectedProduct.shortDescription ||
                      "بدون توضیحات کوتاه"}
                  </p>
                  <div className="bg-background rounded-2xl p-5 mb-6 border border-subtle space-y-4">
                    
                    <div className="flex justify-between items-center pb-4 border-b border-subtle">
                      
                      <span className="text-muted font-medium">
                        قیمت نهایی فروش برای شما
                      </span>
                      <div className="text-left">
                        
                        <span className="text-2xl font-bold text-success">
                          {selectedProduct.finalPrice?.toLocaleString()}
                        </span>
                        <span className="text-sm text-muted mr-1">
                          تومان
                        </span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      
                      <div className="flex items-center gap-3">
                        
                        <div className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-blue-600">
                          
                          <Package className="w-5 h-5" />
                        </div>
                        <div>
                          
                          <p className="text-xs text-muted">موجودی فعلی</p>
                          <p className="font-bold text-primary">
                            {selectedProduct.inventory} عدد
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        
                        <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                          
                          <Layers className="w-5 h-5" />
                        </div>
                        <div>
                          
                          <p className="text-xs text-muted">
                            حداقل سفارش (MOQ)
                          </p>
                          <p className="font-bold text-primary">
                            {selectedProduct.minOrderQuantity} عدد
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3 mb-6 flex-1">
                    
                    <h4 className="font-bold text-primary mb-3 flex items-center gap-2">
                      
                      <Info className="w-5 h-5 text-muted" /> مشخصات فنی
                    </h4>
                    <div className="grid grid-cols-2 gap-y-3 text-sm border border-subtle p-4 rounded-xl bg-background/50">
                      
                      <div className="text-muted">تامین‌کننده:</div>
                      <div className="font-medium text-primary">
                        {selectedProduct.supplierName || "نامشخص"}
                      </div>
                      <div className="text-muted">برند:</div>
                      <div className="font-medium text-primary">
                        {selectedProduct.brand || "ندارد"}
                      </div>
                      <div className="text-muted">کد کالا (SKU):</div>
                      <div className="font-medium text-primary">
                        {selectedProduct.sku || "ندارد"}
                      </div>
                      {selectedProduct.publishStartDate && (
                        <>
                          
                          <div className="text-muted">تاریخ انتشار:</div>
                          <div className="font-medium text-primary">
                            
                            {new Date(
                              selectedProduct.publishStartDate,
                            ).toLocaleDateString("fa-IR")}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="mt-auto pt-4 border-t border-subtle flex gap-3">
                    
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="px-6 py-4 rounded-xl text-base font-bold text-muted bg-surface hover:bg-surface transition-colors"
                    >
                      
                      بستن
                    </button>
                    <button
                      onClick={() => setShowConfirmDelete(selectedProduct.id)}
                      className="flex-1 py-4 rounded-xl flex items-center justify-center gap-2 text-base font-bold bg-danger/10 text-danger hover:bg-danger/20 transition-colors"
                    >
                      
                      <Trash2 className="w-5 h-5" /> حذف از بانک کالای من
                    </button>
                  </div>
                </div>
              </div>
              {selectedProduct.longDescription && (
                <div className="mt-12 pt-8 border-t border-subtle">
                  
                  <h4 className="text-lg font-bold text-primary mb-4">
                    توضیحات تکمیلی
                  </h4>
                  <div className="prose prose-slate max-w-none text-muted text-sm leading-loose">
                    
                    {selectedProduct.longDescription}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      <div className="flex justify-between items-center bg-card p-5 rounded-2xl shadow-sm border border-subtle">
        
        <div>
          
          <h2 className="text-xl font-bold text-primary">
            بانک کالای من (My Product Catalog)
          </h2>
          <p className="text-muted text-sm mt-1">
            
            محصولاتی که برای فروشگاه خود انتخاب کرده‌اید. این محصولات آماده
            اتصال به ووکامرس/شاپایفای شما هستند.
          </p>
        </div>
      </div>
      {loading ? (
        <div className="text-center p-12 text-muted">در حال بارگذاری...</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          
          {catalog.map((item) => {
            const product = item.product;
            return (
              <div
                key={item.id}
                className="bg-card rounded-2xl shadow-sm border border-subtle overflow-hidden flex flex-col group hover:shadow-md transition-shadow relative cursor-pointer"
                onClick={(e) => {
                  if ((e.target as any).closest("button")) return;
                  setSelectedProduct(product);
                }}
              >
                
                <div className="h-48 bg-surface relative overflow-hidden flex items-center justify-center text-inverse">
                  
                  {product.images?.length > 0 ? (
                    <img
                      src={product.images[0].url}
                      className="w-full h-full object-cover"
                      alt={product.name}
                    />
                  ) : (
                    <Layers className="w-16 h-16" />
                  )}
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  
                  <div className="flex justify-between items-start mb-2">
                    
                    <p className="text-xs font-semibold text-success bg-success/10 px-2 py-1 rounded">
                      {product.category?.name}
                    </p>
                  </div>
                  <h3 className="font-bold text-primary text-lg mb-2 leading-tight">
                    {product.name}
                  </h3>
                  <p className="text-xs text-muted mb-3 line-clamp-2">
                    {product.description ||
                      product.shortDescription ||
                      "بدون توضیحات"}
                  </p>
                  <div className="mt-auto pt-4 flex flex-col gap-3 border-t border-subtle">
                    
                    <div className="flex justify-between items-end">
                      
                      <p className="text-xs text-muted">قیمت نهایی فروش</p>
                      <p className="font-bold text-success text-lg">
                        
                        {product.finalPrice?.toLocaleString()}
                        <span className="text-[10px] font-normal text-muted">
                          تومان
                        </span>
                      </p>
                    </div>
                    <div className="flex justify-between items-center text-xs text-muted font-medium">
                      
                      <span>
                        وضعیت:
                        {item.status === "PENDING_SYNC"
                          ? "در انتظار سینک"
                          : "سینک شده"}
                      </span>
                      <span>
                        {new Date(item.selected_at).toLocaleDateString("fa-IR")}
                      </span>
                    </div>
                    <button
                      onClick={() => setShowConfirmDelete(product.id)}
                      className="w-full py-2 rounded-xl flex items-center justify-center gap-2 text-sm font-bold bg-danger/10 text-danger hover:bg-danger/20 transition-colors mt-2"
                    >
                      
                      <Trash2 className="w-4 h-4" /> حذف از بانک کالای من
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {catalog.length === 0 && (
            <div className="col-span-full py-12 text-center text-muted bg-card rounded-2xl border border-subtle">
              
              شما هنوز هیچ محصولی به بانک کالای خود اضافه نکرده‌اید.
            </div>
          )}
        </div>
      )}
      {showConfirmDelete !== null && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          
          <div className="bg-card rounded-2xl w-full max-w-md shadow-2xl p-6 text-right">
            
            <h3 className="text-lg font-bold text-primary mb-2">
              حذف محصول از بانک کالای من
            </h3>
            <p className="text-sm text-muted leading-relaxed mb-6">
              
              آیا از حذف این محصول از بانک کالای خود اطمینان دارید؟ تمامی
              سفارشات در حال بررسی مرتبط با این محصول نیز حذف خواهند شد.
            </p>
            <div className="flex gap-3 justify-end">
              
              <button
                onClick={() => setShowConfirmDelete(null)}
                className="px-4 py-2.5 rounded-xl font-bold text-muted bg-surface hover:bg-surface transition-colors text-sm cursor-pointer"
              >
                
                انصراف
              </button>
              <button
                onClick={() => handleRemove(showConfirmDelete)}
                className="px-4 py-2.5 rounded-xl font-bold text-inverse bg-danger hover:bg-rose-700 transition-colors text-sm cursor-pointer"
              >
                
                تایید و حذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
