import React, { useState, useEffect } from "react";
import { User, Save, Bell, CheckCircle } from "lucide-react";
export function StoreManagerProfile({ user, showNotification }: any) {
  const [activeSubTab, setActiveSubTab] = useState<"profile" | "notifications">(
    "profile",
  );
  const [formData, setFormData] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    shaba: user?.shaba || "",
    mobile: user?.mobile || "",
    address: user?.address || "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  /* Notification states persisted in localStorage */ const [
    notifSettings,
    setNotifSettings,
  ] = useState({ newOrders: true, payments: true, announcements: false });
  useEffect(() => {
    if (user?.id) {
      const saved = localStorage.getItem(`notif-settings-${user.id}`);
      if (saved) {
        try {
          setNotifSettings(JSON.parse(saved));
        } catch (e) {
          console.error(e);
        }
      }
    }
  }, [user?.id]);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch("/api/store-manager/profile", { credentials: "include",
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        showNotification("ویرایش مشخصات با موفقیت انجام شد", "success");
      } else {
        showNotification("خطا در ویرایش مشخصات", "error");
      }
    } catch (err) {
      showNotification("خطای شبکه", "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleSaveNotifications = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      localStorage.setItem(
        `notif-settings-${user?.id || "guest"}`,
        JSON.stringify(notifSettings),
      );
      showNotification("تنظیمات اطلاع‌رسانی با موفقیت ذخیره شد", "success");
    } catch (err) {
      showNotification("خطا در ذخیره تنظیمات", "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      
      <div className="bg-card rounded-3xl p-6 lg:p-8 border border-subtle shadow-sm max-w-2xl mx-auto">
        
        {/* Tab Headers */}
        <div className="flex border-b border-subtle mb-8 pb-1 gap-6">
          
          <button
            onClick={() => setActiveSubTab("profile")}
            className={`pb-4 text-base font-extrabold flex items-center gap-2 transition-all cursor-pointer relative ${activeSubTab === "profile" ? "text-primary-default" : "text-muted hover:text-muted"}`}
          >
            
            <User className="w-5 h-5" /> ویرایش مشخصات کاربری
            {activeSubTab === "profile" && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-primary-default rounded-full animate-fade-in"></span>
            )}
          </button>
          <button
            onClick={() => setActiveSubTab("notifications")}
            className={`pb-4 text-base font-extrabold flex items-center gap-2 transition-all cursor-pointer relative ${activeSubTab === "notifications" ? "text-primary-default" : "text-muted hover:text-muted"}`}
          >
            
            <Bell className="w-5 h-5" /> تنظیمات نوتیفیکیشن
            {activeSubTab === "notifications" && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-primary-default rounded-full animate-fade-in"></span>
            )}
          </button>
        </div>
        {activeSubTab === "profile" ? (
          /* Profile Details Form */ <form
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  نام
                </label>
                <input
                  type="text"
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none"
                  value={formData.firstName}
                  onChange={(e) =>
                    setFormData({ ...formData, firstName: e.target.value })
                  }
                />
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  نام خانوادگی
                </label>
                <input
                  type="text"
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none"
                  value={formData.lastName}
                  onChange={(e) =>
                    setFormData({ ...formData, lastName: e.target.value })
                  }
                />
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  موبایل
                </label>
                <input
                  type="text"
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none font-mono text-left"
                  value={formData.mobile}
                  onChange={(e) =>
                    setFormData({ ...formData, mobile: e.target.value })
                  }
                  dir="ltr"
                />
              </div>
              <div>
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  شماره شبا (بدون IR)
                </label>
                <input
                  type="text"
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none font-mono text-left"
                  value={formData.shaba}
                  onChange={(e) =>
                    setFormData({ ...formData, shaba: e.target.value })
                  }
                  dir="ltr"
                  placeholder="000000000000000000000000"
                />
              </div>
              <div className="md:col-span-2">
                
                <label className="block text-xs font-bold text-secondary mb-2">
                  آدرس فروشگاه
                </label>
                <textarea
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-colors outline-none h-20 resize-none"
                  value={formData.address}
                  onChange={(e) =>
                    setFormData({ ...formData, address: e.target.value })
                  }
                  placeholder="آدرس دقیق و کامل فروشگاه خود را وارد کنید..."
                />
              </div>
            </div>
            <div className="pt-6 border-t border-subtle flex justify-end">
              
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-3 rounded-xl font-bold text-inverse bg-primary-default hover:bg-primary-hover transition-all shadow-lg shadow-primary-default/15 flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                
                <Save className="w-5 h-5" />
                {isSubmitting ? "در حال ثبت..." : "ذخیره تغییرات"}
              </button>
            </div>
          </form>
        ) : (
          /* Notification Settings Form */ <form
            onSubmit={handleSaveNotifications}
            className="space-y-6"
          >
            
            <div>
              
              <p className="text-sm text-muted leading-relaxed mb-6">
                
                نوع و کانال‌های اطلاع‌رسانی مورد علاقه خود را مشخص کنید.
                هشدارهای مربوط به سفارشات و فاکتورها جهت بهبود کارایی برای شما
                ارسال خواهند شد.
              </p>
              <div className="space-y-4">
                
                {/* Switch 1: New Orders */}
                <div className="flex items-center justify-between p-4 bg-background/70 rounded-2xl border border-subtle">
                  
                  <div>
                    
                    <h4 className="text-sm font-bold text-primary">
                      اطلاع‌رسانی فاکتورها و سفارشات جدید
                    </h4>
                    <p className="text-[11px] text-muted mt-0.5">
                      دریافت ایمیل و نوتیفیکیشن هنگام ایجاد یا تغییر وضعیت
                      سفارشات
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={notifSettings.newOrders}
                      onChange={(e) =>
                        setNotifSettings({
                          ...notifSettings,
                          newOrders: e.target.checked,
                        })
                      }
                    />
                    <div className="w-11 h-6 bg-surface peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:-translate-x-full after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-default after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-default"></div>
                  </label>
                </div>
                {/* Switch 2: Successful Payments */}
                <div className="flex items-center justify-between p-4 bg-background/70 rounded-2xl border border-subtle">
                  
                  <div>
                    
                    <h4 className="text-sm font-bold text-primary">
                      تایید پرداخت‌ها و تسویه‌حساب‌ها
                    </h4>
                    <p className="text-[11px] text-muted mt-0.5">
                      ارسال ایمیل تاییدیه بلافاصله پس از پرداخت صورت‌حساب‌ها یا
                      فیش‌های بانکی
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={notifSettings.payments}
                      onChange={(e) =>
                        setNotifSettings({
                          ...notifSettings,
                          payments: e.target.checked,
                        })
                      }
                    />
                    <div className="w-11 h-6 bg-surface peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:-translate-x-full after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-default after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-default"></div>
                  </label>
                </div>
                {/* Switch 3: System Announcements */}
                <div className="flex items-center justify-between p-4 bg-background/70 rounded-2xl border border-subtle">
                  
                  <div>
                    
                    <h4 className="text-sm font-bold text-primary">
                      اطلاعیه‌های سیستمی و عمومی پلتفرم
                    </h4>
                    <p className="text-[11px] text-muted mt-0.5">
                      اخبار، ارتقای ویژگی‌ها و اطلاعیه‌های دوره‌ای مدیریت کل
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={notifSettings.announcements}
                      onChange={(e) =>
                        setNotifSettings({
                          ...notifSettings,
                          announcements: e.target.checked,
                        })
                      }
                    />
                    <div className="w-11 h-6 bg-surface peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:-translate-x-full after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-default after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-default"></div>
                  </label>
                </div>
              </div>
            </div>
            <div className="pt-6 border-t border-subtle flex justify-end">
              
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-3 rounded-xl font-bold text-inverse bg-primary-default hover:bg-primary-hover transition-all shadow-lg shadow-primary-default/15 flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                
                <Save className="w-5 h-5" />
                {isSubmitting
                  ? "در حال ثبت..."
                  : "ذخیره تنظیمات نوتیفیکیشن"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
