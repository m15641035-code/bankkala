import React, { useState, useEffect } from "react";
import {
  ShoppingCart,
  Plus,
  Check,
  X,
  CreditCard,
  Loader2,
  Eye,
  Info,
  Calendar,
  Truck,
  User,
  MapPin,
  FileText,
  XCircle,
  Printer,
} from "lucide-react";
import { printOrderInvoice } from "../../utils/printLabel";
export default function StoreOrders({
  onNavigateToInvoices,
}: {
  onNavigateToInvoices?: () => void;
}): React.ReactElement {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [myCatalog, setMyCatalog] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState("");
  const [shippingAddressType, setShippingAddressType] = useState<
    "STORE_ADDRESS" | "OTHER_ADDRESS"
  >("OTHER_ADDRESS");
  const [shippingAddress, setShippingAddress] = useState("");
  const [shippingMethod, setShippingMethod] = useState<
    "PLATFORM_PANEL" | "PERSONAL_PANEL"
  >("PLATFORM_PANEL");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  /* Redesigned form states */ const [productSearch, setProductSearch] =
    useState("");
  const [shippingProvince, setShippingProvince] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [shippingPostalCode, setShippingPostalCode] = useState("");
  const [shippingAddressDetail, setShippingAddressDetail] = useState("");
  const [shippingRecipientName, setShippingRecipientName] = useState("");
  const [shippingRecipientPhone, setShippingRecipientPhone] = useState("");
  const [postalLabelUrl, setPostalLabelUrl] = useState("");
  const [uploadingLabel, setUploadingLabel] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const simulateLabelUpload = (file: File) => {
    setUploadingLabel(true);
    setUploadProgress(10);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadingLabel(false);
          setPostalLabelUrl(
            `https://storage.iranpost.ir/labels/${Date.now()}_${file.name}`,
          );
          return 100;
        }
        return prev + 30;
      });
    }, 150);
  };
  const [selectedOrders, setSelectedOrders] = useState<number[]>([]);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"ONLINE" | "MANUAL">(
    "ONLINE",
  );
  const [currentOrderIdToPay, setCurrentOrderIdToPay] = useState<number | null>(
    null,
  );
  const [selectedOrderForDetails, setSelectedOrderForDetails] = useState<
    any | null
  >(null);
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);
  const [paymentSuccessData, setPaymentSuccessData] = useState<any>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(5);
  const handleExportCSV = () => {
    if (orders.length === 0) {
      alert("هیچ سفارشی برای خروجی گرفتن وجود ندارد.");
      return;
    }
    const headers = [
      "شناسه سفارش",
      "نام محصول",
      "تعداد",
      "مبلغ کل (تومان)",
      "وضعیت",
      "تاریخ ثبت",
    ];
    const rows = orders.map((o) => [
      o.id,
      o.product?.name || "محصول حذف شده",
      o.quantity,
      o.totalAmount || 0,
      o.status === "REQUESTED"
        ? "در انتظار تایید"
        : o.status === "SUPPLIER_APPROVED"
          ? "تایید شده"
          : o.status === "PAID"
            ? "پرداخت شده"
            : o.status,
      new Date(o.createdAt).toLocaleDateString("fa-IR"),
    ]);
    const csvContent = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(","),
      ),
    ].join("\n");
    const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `سفارشات_فروشگاه.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  useEffect(() => {
    let timer: any;
    if (paymentSuccessData && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (paymentSuccessData && countdown === 0) {
      handleClosePaymentModalAndRedirect();
    }
    return () => clearTimeout(timer);
  }, [paymentSuccessData, countdown]);
  const handleClosePaymentModalAndRedirect = () => {
    setPaymentModalOpen(false);
    setPaymentSuccessData(null);
    setCountdown(5);
    setSelectedOrders([]);
    fetchOrders();
    if (onNavigateToInvoices) onNavigateToInvoices();
  };
  const closePaymentModal = () => {
    setPaymentModalOpen(false);
    setPaymentSuccessData(null);
    setPaymentError(null);
    setCountdown(5);
  };
  useEffect(() => {
    fetchOrders();
    fetchCatalog();
  }, []);
  const fetchOrders = async () => {
    try {
      const res = await fetch("/api/store-manager/orders", { credentials: "include",
        headers: { /* Auth Header Removed */ },
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const fetchCatalog = async () => {
    try {
      const res = await fetch("/api/store-manager/my-catalog", { credentials: "include",
        headers: { /* Auth Header Removed */ },
      });
      if (res.ok) {
        const data = await res.json();
        setMyCatalog(data);
      }
    } catch (err) {
      console.error(err);
    }
  };
  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) {
      setError("لطفاً یک محصول را انتخاب کنید");
      return;
    }
    let finalAddress = "";
    if (shippingMethod === "PLATFORM_PANEL") {
      if (shippingAddressType === "OTHER_ADDRESS") {
        if (
          !shippingProvince.trim() ||
          !shippingCity.trim() ||
          !shippingAddressDetail.trim() ||
          !shippingPostalCode.trim() ||
          !shippingRecipientName.trim() ||
          !shippingRecipientPhone.trim()
        ) {
          setError(
            "لطفاً تمامی فیلدهای مشخصات گیرنده و آدرس پستی را تکمیل کنید.",
          );
          return;
        }
        if (!/^\d{10}$/.test(shippingPostalCode.trim())) {
          setError("کد پستی باید دقیقاً ۱۰ رقم عددی باشد.");
          return;
        }
        if (!/^09\d{9}$/.test(shippingRecipientPhone.trim())) {
          setError("شماره موبایل گیرنده معتبر نیست (مثال: 09121111111).");
          return;
        }
        finalAddress = `استان: ${shippingProvince.trim()} | شهر: ${shippingCity.trim()} | نشانی: ${shippingAddressDetail.trim()} | کد پستی: ${shippingPostalCode.trim()} | گیرنده: ${shippingRecipientName.trim()} | تلفن: ${shippingRecipientPhone.trim()}`;
      }
    }
    if (shippingMethod === "PERSONAL_PANEL" && !postalLabelUrl) {
      setError("بارگذاری فایل لیبل پستی برای پنل پستی شخصی الزامی است.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/store-manager/orders", { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          
        },
        body: JSON.stringify({
          productId: parseInt(selectedProduct),
          quantity,
          notes,
          shippingAddressType,
          shippingAddress: finalAddress,
          shippingMethod,
          postalLabel: postalLabelUrl,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowModal(false);
        setSelectedProduct("");
        setQuantity(1);
        setNotes("");
        setShippingAddress("");
        setShippingProvince("");
        setShippingCity("");
        setShippingPostalCode("");
        setShippingAddressDetail("");
        setShippingRecipientName("");
        setShippingRecipientPhone("");
        setPostalLabelUrl("");
        setProductSearch("");
        fetchOrders();
      } else {
        setError(data.error || "خطا در ثبت سفارش");
      }
    } catch (err) {
      setError("خطای شبکه. لطفاً مجدداً تلاش کنید.");
    } finally {
      setSubmitting(false);
    }
  };
  const handlePaymentClick = (orderId: number) => {
    setCurrentOrderIdToPay(orderId);
    setPaymentError(null);
    setPaymentSuccessData(null);
    setPaymentModalOpen(true);
  };
  const handleBatchPaymentClick = () => {
    if (selectedOrders.length === 0) return;
    setCurrentOrderIdToPay(null);
    setPaymentError(null);
    setPaymentSuccessData(null);
    setPaymentModalOpen(true);
  };
  const processPayment = async () => {
    const orderIds = currentOrderIdToPay
      ? [currentOrderIdToPay]
      : selectedOrders;
    if (orderIds.length === 0) return;
    setPaymentSubmitting(true);
    setPaymentError(null);
    setPaymentSuccessData(null);
    try {
      const res = await fetch("/api/store-manager/settle-orders", { credentials: "include",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          
        },
        body: JSON.stringify({ orderIds, paymentMethod }),
      });
      const data = await res.json();
      if (res.ok) {
        if (data.manual) {
          // Store invoice created manually and wallet balance deducted
          setPaymentSuccessData({ invoiceId: data.invoiceId });
          fetchOrders();
        } else if (data.payLink) {
          const newTab = window.open(data.payLink, "_blank");
          if (!newTab) window.location.href = data.payLink;
          setPaymentModalOpen(false);
          setSelectedOrders([]);
        }
      } else {
        setPaymentError(data.error || "خطا در ارتباط با درگاه پرداخت");
      }
    } catch (err) {
      setPaymentError(
        "خطای شبکه در ارتباط با سرور. لطفاً اتصال خود را بررسی کنید.",
      );
    } finally {
      setPaymentSubmitting(false);
    }
  };
  const getStatusText = (status: string) => {
    const statusMap: any = {
      REQUESTED: "درخواست شده",
      SUPPLIER_APPROVED: "تایید تامین‌کننده",
      WAITING_FOR_PAYMENT: "در انتظار پرداخت",
      PAID: "پرداخت شده",
      PREPARING: "در حال آماده‌سازی",
      COMPLETED: "تکمیل شده",
      CANCELLED: "لغو شده",
      REJECTED: "رد شده",
    };
    return statusMap[status] || status;
  };
  const getStatusColor = (status: string) => {
    const colorMap: any = {
      REQUESTED: "text-warning bg-warning/10",
      SUPPLIER_APPROVED: "text-blue-600 bg-surface",
      WAITING_FOR_PAYMENT: "text-purple-600 bg-purple-50",
      PAID: "text-success bg-success/10",
      PREPARING: "text-primary-default bg-primary-default/10",
      COMPLETED: "text-success bg-success/20",
      CANCELLED: "text-danger bg-danger/10",
      REJECTED: "text-danger bg-red-50",
    };
    return colorMap[status] || "text-muted bg-background";
  };
  const payableOrders = orders.filter(
    (order) =>
      order.status === "SUPPLIER_APPROVED" && order.storeInvoiceId === null,
  );
  return (
    <div className="space-y-6 animate-fade-in">
      
      <div className="flex justify-between items-center bg-card p-5 rounded-2xl shadow-sm border border-subtle">
        
        <div>
          
          <h2 className="text-xl font-bold text-primary">سفارشات</h2>
          <p className="text-sm text-muted mt-1">
            مدیریت و پیگیری سفارشات شما
          </p>
        </div>
        <div className="flex items-center gap-3">
          
          <button
            onClick={handleExportCSV}
            className="bg-success/10 text-success hover:bg-success/20 px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 border border-emerald-200 cursor-pointer shadow-sm shadow-emerald-50"
          >
            
            <FileText className="w-5 h-5" /> خروجی اکسل (CSV)
          </button>
          <button
            onClick={() => {
              setError(null);
              setShowModal(true);
            }}
            className="bg-primary-default text-inverse px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-primary-hover transition-colors flex items-center gap-2"
          >
            
            <Plus className="w-5 h-5" /> ثبت سفارش
          </button>
        </div>
      </div>
      {selectedOrders.length > 0 && (
        <div className="bg-success/10 border border-emerald-200/50 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in shadow-sm">
          
          <div className="flex items-center gap-3">
            
            <div className="p-3 bg-success text-inverse rounded-xl">
              
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              
              <p className="font-bold text-emerald-900 text-sm">
                
                تعداد {selectedOrders.length} سفارش جهت پرداخت گروهی انتخاب شده
                است.
              </p>
              <p className="text-xs text-success mt-0.5">
                
                مجموع کل قابل پرداخت:
                <span className="font-extrabold text-sm text-emerald-950">
                  
                  {orders
                    .filter((o) => selectedOrders.includes(o.id))
                    .reduce((sum, o) => sum + (o.totalAmount || 0), 0)
                    .toLocaleString()}
                </span>
                تومان
              </p>
            </div>
          </div>
          <button
            onClick={handleBatchPaymentClick}
            className="w-full md:w-auto bg-success text-inverse px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 shadow-md shadow-emerald-200"
          >
            
            <CreditCard className="w-4 h-4" /> فاکتورسازی و پرداخت آنلاین (
            {selectedOrders.length} سفارش)
          </button>
        </div>
      )}
      {loading ? (
        <div className="flex justify-center items-center py-20">
          
          <Loader2 className="w-8 h-8 text-primary-default animate-spin" />
        </div>
      ) : (
        <div className="bg-card rounded-3xl shadow-sm border border-subtle overflow-hidden">
          
          {orders.length === 0 ? (
            <div className="text-center py-20 text-muted">
              
              <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>هیچ سفارشی ثبت نشده است</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              
              <table className="w-full text-sm text-right">
                
                <thead className="bg-background text-muted">
                  
                  <tr>
                    
                    <th className="py-4 px-6 w-12 text-center">
                      
                      <input
                        type="checkbox"
                        className="rounded border-default text-primary-default focus:ring-primary-default w-4 h-4 cursor-pointer"
                        checked={
                          payableOrders.length > 0 &&
                          selectedOrders.length === payableOrders.length
                        }
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedOrders(payableOrders.map((o) => o.id));
                          } else {
                            setSelectedOrders([]);
                          }
                        }}
                      />
                    </th>
                    <th className="py-4 px-6 font-semibold">شناسه سفارش</th>
                    <th className="py-4 px-6 font-semibold">اقلام</th>
                    <th className="py-4 px-6 font-semibold">مبلغ کل (تومان)</th>
                    <th className="py-4 px-6 font-semibold">وضعیت</th>
                    <th className="py-4 px-6 font-semibold">تاریخ ثبت</th>
                    <th className="py-4 px-6 font-semibold text-center">
                      عملیات
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  
                  {orders.map((order) => {
                    const isPayable =
                      order.status === "SUPPLIER_APPROVED" &&
                      order.storeInvoiceId === null;
                    const isSelected = selectedOrders.includes(order.id);
                    return (
                      <tr
                        key={order.id}
                        className={`hover:bg-background/50 transition-colors ${isSelected ? "bg-primary-default/10/30" : ""}`}
                      >
                        
                        <td className="py-4 px-6 text-center">
                          
                          {isPayable ? (
                            <input
                              type="checkbox"
                              className="rounded border-default text-primary-default focus:ring-primary-default w-4 h-4 cursor-pointer"
                              checked={isSelected}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedOrders([
                                    ...selectedOrders,
                                    order.id,
                                  ]);
                                } else {
                                  setSelectedOrders(
                                    selectedOrders.filter(
                                      (id) => id !== order.id,
                                    ),
                                  );
                                }
                              }}
                            />
                          ) : (
                            <span className="text-inverse text-xs">-</span>
                          )}
                        </td>
                        <td className="py-4 px-6 font-medium text-primary">
                          #{order.id}
                        </td>
                        <td className="py-4 px-6 text-muted">
                          
                          {order.items?.map((item: any) => (
                            <div key={item.id}>
                              
                              {item.product?.name}
                              <span className="text-muted">
                                x{item.quantity}
                              </span>
                            </div>
                          ))}
                        </td>
                        <td className="py-4 px-6 font-bold text-primary">
                          
                          {order.totalAmount?.toLocaleString()}
                        </td>
                        <td className="py-4 px-6">
                          
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(order.status)}`}
                          >
                            
                            {getStatusText(order.status)}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-muted">
                          
                          {new Date(order.createdAt).toLocaleDateString(
                            "fa-IR",
                          )}
                        </td>
                        <td className="py-4 px-6 text-center">
                          
                          <div className="flex items-center justify-center gap-2">
                            
                            <button
                              onClick={() => setSelectedOrderForDetails(order)}
                              className="bg-primary-default/10 hover:bg-primary-default/20 text-primary-hover px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                            >
                              
                              <Eye className="w-3.5 h-3.5" /> جزئیات سفارش
                            </button>
                            {isPayable && (
                              <button
                                onClick={() => handlePaymentClick(order.id)}
                                className="bg-success/20 text-success hover:bg-emerald-200 px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                              >
                                
                                <CreditCard className="w-4 h-4" /> پرداخت تک
                                تکی
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      {showModal && (
        <div
          className="fixed inset-0 bg-background/60 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setShowModal(false)}
        >
          
          <div
            className="bg-card rounded-3xl w-full max-w-xl shadow-2xl p-6 md:p-8 my-8 text-right relative max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            
            <div className="flex justify-between items-center mb-6 border-b border-subtle pb-4">
              
              <h3 className="text-xl font-black text-primary">
                ثبت سفارش جدید
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-muted hover:bg-surface p-2 rounded-full cursor-pointer transition-colors"
              >
                
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateOrder} className="space-y-6">
              
              {/* Product Search and Selector */}
              <div>
                
                <label className="block text-sm font-bold text-secondary mb-2">
                  ۱. انتخاب محصول از بانک کالا
                </label>
                {/* Search Box */}
                <div className="relative mb-3">
                  
                  <input
                    type="text"
                    placeholder="جستجوی نام کالا یا شناسه (SKU)..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full bg-background border border-subtle rounded-xl pr-10 pl-4 py-2.5 text-xs focus:ring-2 focus:ring-primary-default outline-none transition-all"
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted">
                    
                    <span className="text-xs">🔍</span>
                  </div>
                </div>
                <div className="max-h-52 overflow-y-auto space-y-2 border border-subtle p-2 rounded-xl bg-background">
                  
                  {myCatalog.length === 0 && (
                    <div className="text-center py-6 text-xs text-muted">
                      بانک کالای شما خالی است
                    </div>
                  )}
                  {myCatalog.length > 0 &&
                    myCatalog.filter(
                      (sel) =>
                        sel.product.name
                          .toLowerCase()
                          .includes(productSearch.toLowerCase()) ||
                        (sel.product.sku &&
                          sel.product.sku
                            .toLowerCase()
                            .includes(productSearch.toLowerCase())),
                    ).length === 0 && (
                      <div className="text-center py-6 text-xs text-muted">
                        محصولی با این مشخصات یافت نشد
                      </div>
                    )}
                  {myCatalog
                    .filter(
                      (sel) =>
                        sel.product.name
                          .toLowerCase()
                          .includes(productSearch.toLowerCase()) ||
                        (sel.product.sku &&
                          sel.product.sku
                            .toLowerCase()
                            .includes(productSearch.toLowerCase())),
                    )
                    .map((sel) => {
                      const isSelected =
                        selectedProduct === sel.productId.toString();
                      return (
                        <div
                          key={sel.productId}
                          onClick={() =>
                            setSelectedProduct(sel.productId.toString())
                          }
                          className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all border ${isSelected ? "border-primary-default bg-primary-default/10/70 ring-2 ring-primary-default/10" : "border-subtle hover:bg-surface bg-card"}`}
                        >
                          
                          <div className="w-12 h-12 bg-surface rounded-lg overflow-hidden flex-shrink-0 border border-subtle">
                            
                            {sel.product.images?.length > 0 ? (
                              <img
                                src={sel.product.images[0].url}
                                className="w-full h-full object-cover"
                                alt=""
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-muted bg-background">
                                
                                <ShoppingCart className="w-4 h-4" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            
                            <h4 className="font-bold text-xs text-primary truncate">
                              {sel.product.name}
                            </h4>
                            <div className="flex justify-between items-center mt-1">
                              
                              <span className="text-[10px] text-muted font-mono">
                                SKU: {sel.product.sku || "-"}
                              </span>
                              <span className="text-[10px] text-primary-default font-bold bg-primary-default/10 px-1.5 py-0.5 rounded">
                                موجودی: {sel.product.inventory}
                              </span>
                            </div>
                          </div>
                          {isSelected && (
                            <div className="w-5 h-5 bg-primary-default text-inverse rounded-full flex items-center justify-center flex-shrink-0">
                              
                              <Check className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
              {/* Quantity */}
              <div className="grid grid-cols-2 gap-4">
                
                <div>
                  
                  <label className="block text-sm font-bold text-secondary mb-2">
                    ۲. تعداد سفارش
                  </label>
                  <input
                    type="number"
                    min="1"
                    className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-primary-default outline-none"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value))}
                    required
                  />
                </div>
                <div>
                  
                  <label className="block text-sm font-bold text-secondary mb-2">
                    نوع ارسال (لجستیک)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    
                    <button
                      type="button"
                      onClick={() => setShippingMethod("PLATFORM_PANEL")}
                      className={`py-2 px-2 text-[11px] font-bold rounded-xl border transition-all cursor-pointer ${shippingMethod === "PLATFORM_PANEL" ? "bg-primary-default border-primary-default text-inverse shadow-sm" : "bg-background border-subtle text-muted hover:bg-surface"}`}
                    >
                      
                      پنل پستی پلتفرم
                    </button>
                    <button
                      type="button"
                      onClick={() => setShippingMethod("PERSONAL_PANEL")}
                      className={`py-2 px-2 text-[11px] font-bold rounded-xl border transition-all cursor-pointer ${shippingMethod === "PERSONAL_PANEL" ? "bg-primary-default border-primary-default text-inverse shadow-sm" : "bg-background border-subtle text-muted hover:bg-surface"}`}
                    >
                      
                      پنل پستی خودم
                    </button>
                  </div>
                </div>
              </div>
              {/* Personal Panel Label Upload Warning/Interaction */}
              {shippingMethod === "PERSONAL_PANEL" && (
                <div className="p-4 bg-warning/10 border border-amber-200 rounded-2xl space-y-3">
                  
                  <div className="flex items-start gap-2.5">
                    
                    <span className="text-base">⚠️</span>
                    <div className="flex-1">
                      
                      <h5 className="text-xs font-bold text-amber-900">
                        بارگذاری لیبل پستی در مراحل بعدی
                      </h5>
                      <p className="text-[10px] text-warning leading-relaxed mt-0.5">
                        
                        شما ارسال با پنل پستی شخصی را انتخاب کرده‌اید. لطفا پس
                        از تسویه فاکتور، لیبل پستی خود را در جزئیات سفارش
                        بارگذاری نمایید.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              {/* Shipping Address Section */}
              {shippingMethod === "PLATFORM_PANEL" && (
                <div className="space-y-4 bg-background p-4 md:p-5 rounded-2xl border border-subtle animate-fade-in">
                  
                  <div className="flex justify-between items-center">
                    
                    <span className="block text-xs font-black text-primary-default uppercase tracking-wider">
                      ۳. مشخصات و نشانی کامل گیرنده
                    </span>
                    <div className="flex gap-1.5">
                      
                      <button
                        type="button"
                        onClick={() => setShippingAddressType("OTHER_ADDRESS")}
                        className={`px-3 py-1 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${shippingAddressType === "OTHER_ADDRESS" ? "bg-card border-primary-default text-primary-default shadow-sm" : "bg-transparent border-subtle text-muted hover:bg-surface"}`}
                      >
                        
                        آدرس دیگر (دستی)
                      </button>
                      <button
                        type="button"
                        onClick={() => setShippingAddressType("STORE_ADDRESS")}
                        className={`px-3 py-1 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${shippingAddressType === "STORE_ADDRESS" ? "bg-card border-primary-default text-primary-default shadow-sm" : "bg-transparent border-subtle text-muted hover:bg-surface"}`}
                      >
                        
                        آدرس فروشگاه
                      </button>
                    </div>
                  </div>
                  {shippingAddressType === "STORE_ADDRESS" ? (
                    <div className="bg-primary-default/10/50 p-3 rounded-xl border border-primary-default/20 flex items-start gap-2.5 text-right">
                      
                      <MapPin className="w-4 h-4 text-primary-default flex-shrink-0 mt-0.5" />
                      <div>
                        
                        <p className="text-xs font-bold text-primary-hover">
                          استفاده از آدرس پیش‌فرض فروشگاه
                        </p>
                        <p className="text-[10px] text-primary-hover leading-relaxed mt-1">
                          
                          مرسولات به نشانی ثبت شده در مشخصات فروشگاه شما ارسال
                          خواهند شد. در صورت تمایل به تغییر این آدرس، می‌توانید
                          به بخش ویرایش پروفایل مراجعه کنید.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3 text-right">
                      
                      {/* Receiver Contact Details */}
                      <div className="grid grid-cols-2 gap-3">
                        
                        <div>
                          
                          <label className="block text-[11px] font-bold text-muted mb-1">
                            نام و نام خانوادگی گیرنده *
                          </label>
                          <input
                            type="text"
                            required
                            value={shippingRecipientName}
                            onChange={(e) =>
                              setShippingRecipientName(e.target.value)
                            }
                            placeholder="مثال: علی احمدی"
                            className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none"
                          />
                        </div>
                        <div>
                          
                          <label className="block text-[11px] font-bold text-muted mb-1">
                            شماره تماس گیرنده *
                          </label>
                          <input
                            type="text"
                            required
                            value={shippingRecipientPhone}
                            onChange={(e) =>
                              setShippingRecipientPhone(e.target.value)
                            }
                            placeholder="مثال: 09121111111"
                            className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none text-left font-mono"
                          />
                        </div>
                      </div>
                      {/* Province and City */}
                      <div className="grid grid-cols-2 gap-3">
                        
                        <div>
                          
                          <label className="block text-[11px] font-bold text-muted mb-1">
                            استان *
                          </label>
                          <input
                            type="text"
                            required
                            value={shippingProvince}
                            onChange={(e) =>
                              setShippingProvince(e.target.value)
                            }
                            placeholder="مثال: تهران"
                            className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none"
                          />
                        </div>
                        <div>
                          
                          <label className="block text-[11px] font-bold text-muted mb-1">
                            شهر *
                          </label>
                          <input
                            type="text"
                            required
                            value={shippingCity}
                            onChange={(e) => setShippingCity(e.target.value)}
                            placeholder="مثال: تهران"
                            className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none"
                          />
                        </div>
                      </div>
                      {/* Postal Code */}
                      <div>
                        
                        <label className="block text-[11px] font-bold text-muted mb-1">
                          کد پستی ۱۰ رقمی گیرنده *
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={10}
                          value={shippingPostalCode}
                          onChange={(e) =>
                            setShippingPostalCode(
                              e.target.value.replace(/\D/g, ""),
                            )
                          }
                          placeholder="مثال: 1459873111"
                          className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none text-left font-mono tracking-wider"
                        />
                      </div>
                      {/* Exact Address */}
                      <div>
                        
                        <label className="block text-[11px] font-bold text-muted mb-1">
                          نشانی دقیق پستی (خیابان، کوچه، پلاک، واحد) *
                        </label>
                        <textarea
                          rows={2}
                          required
                          value={shippingAddressDetail}
                          onChange={(e) =>
                            setShippingAddressDetail(e.target.value)
                          }
                          placeholder="بزرگراه همت، خیابان شریعتی، کوچه لادن، پلاک ۴، واحد ۲"
                          className="w-full bg-card border border-subtle rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-primary-default outline-none resize-none"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
              {/* Order Notes */}
              <div>
                
                <label className="block text-sm font-bold text-secondary mb-2">
                  ۴. یادداشت برای تامین‌کننده (اختیاری)
                </label>
                <textarea
                  className="w-full bg-background border border-subtle rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-primary-default outline-none"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="رنگ، سایز، بسته‌بندی ویژه یا نکات اضطراری مرسوله..."
                />
              </div>
              {error && (
                <div className="bg-danger/10 border border-rose-200 text-danger p-3.5 rounded-xl text-xs font-bold leading-relaxed">
                  
                  {error}
                </div>
              )}
              {/* Submit / Cancel buttons */}
              <div className="pt-4 border-t border-subtle flex gap-3">
                
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-xs text-muted bg-surface hover:bg-surface transition-colors cursor-pointer"
                >
                  
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={submitting || !selectedProduct}
                  className="flex-1 px-4 py-3 rounded-xl font-bold text-xs text-inverse bg-primary-default hover:bg-primary-hover transition-colors disabled:opacity-50 cursor-pointer"
                >
                  
                  {submitting ? "در حال ثبت..." : "ثبت نهایی سفارش"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {paymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          
          <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6 animate-in zoom-in-95 duration-200 text-right">
            
            {paymentSuccessData ? (
              <div className="text-center py-6 space-y-4">
                
                <div className="w-16 h-16 bg-success/20 text-success rounded-full flex items-center justify-center mx-auto animate-bounce">
                  
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black text-primary">
                  فاکتور با موفقیت صادر شد! 🎉
                </h3>
                <p className="text-sm text-muted leading-relaxed px-2">
                  
                  سفارشات شما با موفقیت به فاکتور رسمی
                  <strong className="text-primary-default">
                    INV-{paymentSuccessData.invoiceId}
                  </strong>
                  تبدیل شد.
                </p>
                <div className="bg-primary-default/10 text-primary-hover p-4 rounded-xl text-xs text-right space-y-2 border border-primary-default/30 leading-relaxed">
                  
                  <p className="font-bold text-sm mb-1 text-primary-hover">
                    مراحل بعدی پرداخت:
                  </p>
                  <p>
                    ۱. سیستم اکنون شما را به بخش
                    <strong className="text-primary-hover font-bold">
                      «صورت‌حساب‌ها»
                    </strong>
                    منتقل می‌کند.
                  </p>
                  <p>
                    ۲. در آنجا می‌توانید مشخصات دقیق بانکی (شماره کارت و شبا) را
                    به همراه دکمه کپی آسان مشاهده کنید.
                  </p>
                  <p>
                    ۳. پس از انتقال وجه به آن حساب، تصویر فیش واریزی را در همان
                    فاکتور بارگذاری نمایید تا فاکتور شما تایید نهایی شود.
                  </p>
                </div>
                <div className="pt-4 space-y-3">
                  
                  <p className="text-xs text-muted">
                    
                    انتقال خودکار به بخش صورت‌حساب‌ها در
                    <span className="font-bold text-primary-default font-mono text-sm">
                      {countdown}
                    </span>
                    ثانیه...
                  </p>
                  <div className="flex gap-2">
                    
                    <button
                      onClick={closePaymentModal}
                      className="flex-1 px-4 py-2.5 rounded-xl text-xs font-bold text-muted bg-surface hover:bg-surface transition-all"
                    >
                      
                      بستن و ماندن
                    </button>
                    <button
                      onClick={handleClosePaymentModalAndRedirect}
                      className="flex-1 px-4 py-2.5 rounded-xl text-xs font-bold text-inverse bg-primary-default hover:bg-primary-hover transition-all shadow-md shadow-indigo-100"
                    >
                      
                      انتقال فوری به صورت‌حساب‌ها
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                
                <div className="flex justify-between items-center mb-6">
                  
                  <h3 className="text-xl font-bold text-primary">
                    انتخاب روش پرداخت
                  </h3>
                  <button
                    onClick={closePaymentModal}
                    disabled={paymentSubmitting}
                    className="text-muted hover:text-muted disabled:opacity-50"
                  >
                    
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-4">
                  
                  <label
                    className={`block p-4 rounded-xl border-2 cursor-pointer transition-all ${paymentMethod === "ONLINE" ? "border-success bg-success/10" : "border-subtle hover:border-emerald-200"} ${paymentSubmitting ? "pointer-events-none opacity-50" : ""}`}
                  >
                    
                    <div className="flex items-center gap-3">
                      
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="ONLINE"
                        checked={paymentMethod === "ONLINE"}
                        onChange={() => setPaymentMethod("ONLINE")}
                        disabled={paymentSubmitting}
                        className="text-success focus:ring-success w-4 h-4 cursor-pointer"
                      />
                      <div>
                        
                        <p className="font-bold text-primary">
                          پرداخت آنلاین (درگاه زیبال)
                        </p>
                        <p className="text-sm text-muted mt-1">
                          انتقال سریع و خودکار به درگاه پرداخت
                        </p>
                      </div>
                    </div>
                  </label>
                  <label
                    className={`block p-4 rounded-xl border-2 cursor-pointer transition-all ${paymentMethod === "MANUAL" ? "border-primary-default bg-primary-default/10" : "border-subtle hover:border-primary-default/30"} ${paymentSubmitting ? "pointer-events-none opacity-50" : ""}`}
                  >
                    
                    <div className="flex items-center gap-3">
                      
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="MANUAL"
                        checked={paymentMethod === "MANUAL"}
                        onChange={() => setPaymentMethod("MANUAL")}
                        disabled={paymentSubmitting}
                        className="text-primary-default focus:ring-primary-default w-4 h-4 cursor-pointer"
                      />
                      <div>
                        
                        <p className="font-bold text-primary">
                          پرداخت کارت به کارت / بانکی
                        </p>
                        <p className="text-sm text-muted mt-1">
                          ثبت فاکتور پرداخت دستی و بارگذاری فیش واریز بانکی
                        </p>
                      </div>
                    </div>
                  </label>
                  {paymentMethod === "MANUAL" && (
                    <div className="bg-primary-default/10 text-primary-hover p-4 rounded-xl text-sm leading-relaxed border border-primary-default/30 animate-fade-in text-right">
                      
                      <p className="font-bold mb-2 text-primary-hover">
                        مراحل پرداخت کارت به کارت / بانکی:
                      </p>
                      <p className="text-xs text-primary-hover leading-relaxed">
                        
                        با انتخاب این روش، فاکتور شما صادر می‌شود. پس از آن
                        کافیست به بخش
                        <strong className="text-primary-hover font-bold">
                          «صورت‌حساب‌ها»
                        </strong>
                        بروید، شماره کارت و شماره شبای بانکی را در آنجا مشاهده
                        کرده و پس از واریز وجه، تصویر فیش واریزی خود را در همان
                        بخش بارگذاری نمایید تا فاکتور و سفارشات شما نهایی و
                        تایید شوند.
                      </p>
                    </div>
                  )}
                  {paymentError && (
                    <div className="bg-danger/10 border border-rose-200 text-danger p-3 rounded-xl text-xs font-bold leading-relaxed text-right animate-shake">
                      
                      {paymentError}
                    </div>
                  )}
                </div>
                <div className="flex gap-3 mt-8">
                  
                  <button
                    onClick={closePaymentModal}
                    disabled={paymentSubmitting}
                    className="flex-1 px-4 py-3 rounded-xl font-bold text-muted bg-surface hover:bg-surface transition-colors disabled:opacity-50"
                  >
                    
                    انصراف
                  </button>
                  <button
                    onClick={processPayment}
                    disabled={paymentSubmitting}
                    className="flex-1 px-4 py-3 rounded-xl font-bold text-inverse bg-success hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-100 disabled:opacity-75"
                  >
                    
                    {paymentSubmitting ? (
                      <>
                        
                        <Loader2 className="w-4 h-4 animate-spin" /> در حال
                        ثبت...
                      </>
                    ) : (
                      "تایید و ادامه"
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
      {/* Visual Order Details and Status Tracking Timeline Modal */}
      {selectedOrderForDetails && (
        <div
          className="fixed inset-0 bg-background/60 backdrop-blur-sm flex justify-center items-center z-50 p-4 overflow-y-auto"
          dir="rtl"
        >
          
          <div className="bg-card rounded-3xl max-w-4xl w-full p-6 lg:p-8 shadow-2xl relative animate-scale-up my-8 max-h-[90vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex justify-between items-start border-b border-subtle pb-5 mb-6">
              
              <div>
                
                <h3 className="text-xl font-extrabold text-primary">
                  جزئیات و رهگیری سفارش #{selectedOrderForDetails.id}
                </h3>
                <div className="flex items-center gap-3 mt-2 text-xs text-muted">
                  
                  <span className="flex items-center gap-1">
                    
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(
                      selectedOrderForDetails.createdAt,
                    ).toLocaleDateString("fa-IR")}
                  </span>
                  <span className="w-1 h-1 bg-surface rounded-full"></span>
                  <span>
                    روش تسویه:
                    {selectedOrderForDetails.storeInvoiceId
                      ? "فاکتور صادر شده"
                      : "نیازمند صدور فاکتور"}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedOrderForDetails(null)}
                className="w-10 h-10 rounded-xl hover:bg-surface text-muted hover:text-muted flex items-center justify-center transition-colors cursor-pointer"
              >
                
                <X className="w-6 h-6" />
              </button>
            </div>
            {/* Visual Status Tracking Timeline */}
            <div className="mb-8 p-6 bg-background rounded-2xl border border-subtle">
              
              <h4 className="text-sm font-bold text-secondary mb-6 flex items-center gap-2">
                
                <Truck className="w-4 h-4 text-primary-default" /> وضعیت لحظه‌ای
                و رهگیری مرسوله:
              </h4>
              {selectedOrderForDetails.status === "CANCELLED" ||
              selectedOrderForDetails.status === "REJECTED" ? (
                <div className="p-4 bg-danger/10 border border-rose-100 rounded-xl text-danger text-sm font-bold flex items-center gap-2">
                  
                  <XCircle className="w-5 h-5" /> این سفارش متأسفانه لغو یا رد
                  شده است.
                </div>
              ) : (
                <div className="relative">
                  
                  {/* Progress Line */}
                  <div className="absolute top-5 right-10 left-10 h-1 bg-surface -z-10 hidden md:block">
                    
                    <div
                      className="h-full bg-primary-default transition-all duration-500"
                      style={{
                        width:
                          selectedOrderForDetails.status === "REQUESTED"
                            ? "0%"
                            : selectedOrderForDetails.status ===
                                "SUPPLIER_APPROVED"
                              ? "25%"
                              : selectedOrderForDetails.status ===
                                  "WAITING_FOR_PAYMENT"
                                ? "50%"
                                : ["PAID", "PREPARING"].includes(
                                      selectedOrderForDetails.status,
                                    )
                                  ? "75%"
                                  : selectedOrderForDetails.status ===
                                      "COMPLETED"
                                    ? "100%"
                                    : "0%",
                      }}
                    ></div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                    
                    {[
                      {
                        title: "ثبت درخواست",
                        desc: "سفارش ثبت شد",
                        active: [
                          "REQUESTED",
                          "SUPPLIER_APPROVED",
                          "WAITING_FOR_PAYMENT",
                          "PAID",
                          "PREPARING",
                          "COMPLETED",
                        ].includes(selectedOrderForDetails.status),
                      },
                      {
                        title: "تایید تامین‌کننده",
                        desc: "بررسی اصالت و موجودی",
                        active: [
                          "SUPPLIER_APPROVED",
                          "WAITING_FOR_PAYMENT",
                          "PAID",
                          "PREPARING",
                          "COMPLETED",
                        ].includes(selectedOrderForDetails.status),
                      },
                      {
                        title: "پرداخت و تایید نهایی",
                        desc: "وصول وجه فاکتور",
                        active: ["PAID", "PREPARING", "COMPLETED"].includes(
                          selectedOrderForDetails.status,
                        ),
                      },
                      {
                        title: "آماده‌سازی سفارش",
                        desc: "بسته‌بندی و ارسال فیزیکی",
                        active: ["PREPARING", "COMPLETED"].includes(
                          selectedOrderForDetails.status,
                        ),
                      },
                      {
                        title: "تحویل کالا",
                        desc: "تکمیل چرخه خرید",
                        active: selectedOrderForDetails.status === "COMPLETED",
                      },
                    ].map((step, idx) => (
                      <div
                        key={idx}
                        className="flex flex-row md:flex-col items-center text-right md:text-center gap-4 md:gap-2"
                      >
                        
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm z-10 transition-all ${step.active ? "bg-primary-default text-inverse shadow-lg shadow-primary-default/20" : "bg-surface text-muted"}`}
                        >
                          
                          {step.active ? (
                            <Check className="w-5 h-5 stroke-[3]" />
                          ) : (
                            idx + 1
                          )}
                        </div>
                        <div>
                          
                          <p
                            className={`font-bold text-xs ${step.active ? "text-primary-hover" : "text-muted"}`}
                          >
                            {step.title}
                          </p>
                          <p className="text-[10px] text-muted mt-0.5">
                            {step.desc}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            {/* Order Items Table */}
            <div className="space-y-4">
              
              <h4 className="text-sm font-bold text-secondary">
                اقلام و فرآورده‌های سفارش داده شده:
              </h4>
              <div className="overflow-x-auto rounded-2xl border border-subtle overflow-hidden">
                
                <table className="w-full text-sm text-right">
                  
                  <thead className="bg-background text-muted">
                    
                    <tr>
                      
                      <th className="py-3 px-4 font-bold">نام محصول</th>
                      <th className="py-3 px-4 font-bold text-center">تعداد</th>
                      <th className="py-3 px-4 font-bold">مبلغ واحد (تومان)</th>
                      <th className="py-3 px-4 font-bold">
                        مبلغ کل (تومان)
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    
                    {selectedOrderForDetails.items?.map((item: any) => (
                      <tr key={item.id} className="hover:bg-background/50">
                        
                        <td className="py-3 px-4 font-semibold text-primary">
                          {item.product?.name}
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-bold text-secondary">
                          {item.quantity}
                        </td>
                        <td className="py-3 px-4 font-mono text-muted">
                          {(item.price || 0).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-primary">
                          {((item.price || 0) * item.quantity).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            {/* Footing Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 pt-6 border-t border-subtle text-sm">
              
              <div className="space-y-2 text-muted">
                
                <p className="flex justify-between">
                  
                  <span>نام تامین‌کننده:</span>
                  <span className="font-semibold text-primary">
                    
                    {selectedOrderForDetails.items?.[0]?.product?.supplier
                      ?.brandName || "نامشخص"}
                  </span>
                </p>
                {/* Shipping Section - Restricted to PAID status */}
                {!(
                  selectedOrderForDetails.status === "PAID" ||
                  selectedOrderForDetails.status === "PREPARING" ||
                  selectedOrderForDetails.status === "SHIPPED" ||
                  selectedOrderForDetails.status === "DELIVERED" ||
                  selectedOrderForDetails.status === "COMPLETED"
                ) ? (
                  <div className="p-4 bg-background border border-subtle/60 rounded-2xl space-y-2 mt-4 text-center">
                    
                    <Truck className="w-8 h-8 text-muted mx-auto animate-pulse" />
                    <h5 className="font-bold text-xs text-secondary">
                      بخش لجستیک و اطلاعات پستی غیرفعال است
                    </h5>
                    <p className="text-[10px] text-muted leading-relaxed max-w-sm mx-auto">
                      
                      طبق قوانین پلتفرم، خدمات لجستیک، کد رهگیری، و تولید لیبل
                      پستی تنها پس از تایید پذیرش تامین‌کننده، صدور فاکتور
                      نهایی، و پرداخت موفق صورت‌حساب در دسترس قرار می‌گیرد.
                    </p>
                  </div>
                ) : (
                  <div className="p-4 bg-primary-default/10/40 border border-primary-default/20 rounded-2xl space-y-3.5 mt-4">
                    
                    <div className="flex items-center gap-1.5 border-b border-primary-default/20 pb-2">
                      
                      <Truck className="w-4 h-4 text-primary-default" />
                      <h5 className="font-bold text-primary-hover text-xs">
                        اطلاعات لجستیک و مرسوله پستی
                      </h5>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-muted">
                      
                      <div>
                        
                        <span className="text-muted block mb-0.5">
                          نشانی گیرنده:
                        </span>
                        <span className="font-bold text-primary">
                          {selectedOrderForDetails.shippingAddress ||
                            "نشانی پیش‌فرض فروشگاه"}
                        </span>
                      </div>
                      <div>
                        
                        <span className="text-muted block mb-0.5">
                          روش ارسال:
                        </span>
                        <span className="font-bold text-primary">
                          
                          {selectedOrderForDetails.shippingMethod ===
                          "PERSONAL_PANEL"
                            ? "پنل پستی اختصاصی"
                            : "پنل پستی پلتفرم"}
                        </span>
                      </div>
                      <div>
                        
                        <span className="text-muted block mb-0.5">
                          کد رهگیری مرسوله:
                        </span>
                        <span className="font-mono font-bold text-primary-hover">
                          
                          {selectedOrderForDetails.trackingCode ||
                            `IR-${selectedOrderForDetails.id}09218475293`}
                        </span>
                      </div>
                      <div>
                        
                        <span className="text-muted block mb-0.5">
                          وضعیت حمل و نقل:
                        </span>
                        <span className="px-2 py-0.5 bg-primary-default/20 text-primary-hover rounded font-bold text-[10px]">
                          
                          {selectedOrderForDetails.status === "PAID"
                            ? "آماده جهت بسته‌بندی"
                            : selectedOrderForDetails.status === "PREPARING"
                              ? "در حال آماده‌سازی پستی"
                              : selectedOrderForDetails.status === "SHIPPED"
                                ? "تحویل به پستچی (ارسال شده)"
                                : "تحویل داده شده"}
                        </span>
                      </div>
                    </div>
                    {/* Generate Shipping Label (Upload Label) */}
                    {selectedOrderForDetails.shippingMethod ===
                      "PERSONAL_PANEL" &&
                      !selectedOrderForDetails.postalLabel && (
                        <div className="pt-2 border-t border-primary-default/20/30">
                          
                          <p className="text-[11px] font-bold text-primary-hover mb-1.5 flex items-center gap-1">
                            
                            <Plus className="w-3.5 h-3.5" /> صدور لیبل
                            جدید:
                          </p>
                          <div className="relative border border-dashed border-primary-default/40 hover:border-primary-default rounded-xl p-3 bg-card text-center transition-colors cursor-pointer">
                            
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                alert("در حال بارگذاری و پردازش لیبل...");
                                const fakeUrl = `https://storage.iranpost.ir/labels/${Date.now()}_label.pdf`;
                                try {
                                  const res = await fetch(
                                    `/api/orders/${selectedOrderForDetails.id}/label`, { credentials: "include",
                                      method: "POST",
                                      headers: {
                                        "Content-Type": "application/json",
                                      },
                                      body: JSON.stringify({
                                        labelUrl: fakeUrl,
                                      }),
                                    },
                                  );
                                  if (!res.ok) throw new Error("خطا");
                                  alert("لیبل با موفقیت بارگذاری شد.");
                                  fetchOrders(); // Refresh orders
                                  setSelectedOrderForDetails({
                                    ...selectedOrderForDetails,
                                    postalLabel: fakeUrl,
                                  });
                                } catch (err) {
                                  alert("خطا در بارگذاری لیبل");
                                }
                              }}
                            />
                            <div className="text-[10px] text-primary-hover font-bold">
                              کلیک کنید یا فایل لیبل (PDF) را جهت بارگذاری و
                              تولید بکشید
                            </div>
                          </div>
                        </div>
                      )}
                    {/* Print Shipping Label */}
                    {selectedOrderForDetails.postalLabel && (
                      <div className="pt-2 border-t border-primary-default/20/30 flex justify-between items-center bg-primary-default/20/20 p-2.5 rounded-xl border border-primary-default/20/40">
                        
                        <span className="text-primary-hover font-bold text-[11px]">
                          لیبل پستی صادر شده:
                        </span>
                        <a
                          href={selectedOrderForDetails.postalLabel}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="bg-primary-default hover:bg-primary-hover text-inverse text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors inline-flex items-center gap-1"
                        >
                          
                          <Printer className="w-3.5 h-3.5" /> مشاهده و چاپ لیبل
                          پستی
                        </a>
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div className="bg-background p-4 rounded-2xl space-y-2 border border-subtle">
                
                <div className="flex justify-between text-muted text-xs">
                  
                  <span>مجموع ارزش کالاها:</span>
                  <span>
                    {selectedOrderForDetails.totalAmount?.toLocaleString()}
                    تومان
                  </span>
                </div>
                <div className="flex justify-between text-muted text-xs">
                  
                  <span>هزینه حمل و نقل و مالیات:</span>
                  <span className="text-success font-semibold">
                    رایگان
                  </span>
                </div>
                <div className="h-px bg-surface my-2"></div>
                <div className="flex justify-between text-primary font-extrabold text-base">
                  
                  <span>مبلغ قابل پرداخت:</span>
                  <span className="text-primary-default font-mono">
                    {selectedOrderForDetails.totalAmount?.toLocaleString()}
                    تومان
                  </span>
                </div>
              </div>
            </div>
            {/* Action buttons */}
            <div className="flex gap-3 mt-8">
              
              <button
                onClick={() => setSelectedOrderForDetails(null)}
                className="flex-1 py-3 bg-surface hover:bg-surface text-secondary font-bold rounded-xl text-sm transition-colors cursor-pointer text-center"
              >
                
                بستن پنجره جزئیات
              </button>
              <button
                onClick={() => printOrderInvoice(selectedOrderForDetails)}
                className="flex-1 py-3 bg-primary-default/10 hover:bg-primary-default/20 text-primary-hover border border-primary-default/30 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                
                <Printer className="w-5 h-5" /> دریافت فاکتور رسمی (PDF)
              </button>
              {selectedOrderForDetails.status === "SUPPLIER_APPROVED" &&
                selectedOrderForDetails.storeInvoiceId === null && (
                  <button
                    onClick={() => {
                      const id = selectedOrderForDetails.id;
                      setSelectedOrderForDetails(null);
                      handlePaymentClick(id);
                    }}
                    className="flex-1 py-3 bg-primary-default hover:bg-primary-hover text-inverse font-bold rounded-xl text-sm shadow-lg shadow-primary-default/10 transition-all cursor-pointer text-center"
                  >
                    
                    اقدام به پرداخت صورت‌حساب
                  </button>
                )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
