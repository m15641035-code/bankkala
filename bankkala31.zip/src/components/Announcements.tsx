import React, { useState, useEffect } from "react";
import { Megaphone, Calendar } from "lucide-react";
export default function Announcements({ role }: { role: string }) {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("/api/announcements")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          // Filter by role:'ALL' or specific role
          const filtered = data.filter(
            (a: any) => a.target === "ALL" || a.target === role,
          );
          setAnnouncements(filtered);
        } else {
          setAnnouncements([]);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [role]);
  if (loading)
    return (
      <div className="text-xs text-muted animate-pulse text-center py-2">
        در حال دریافت اطلاعیه‌ها...
      </div>
    );
  if (announcements.length === 0) return null;
  return (
    <div className="space-y-3 mb-6 text-right">
      
      {announcements.map((ann, idx) => (
        <div
          key={ann.id}
          className="relative overflow-hidden bg-gradient-to-l from-indigo-50/90 to-white/90 dark:from-indigo-950/40 dark:to-slate-800/80 backdrop-blur-md border border-primary-default/20/80 p-4 rounded-2xl flex justify-between items-start shadow-sm hover:shadow-md transition-all duration-300"
          style={{ animationDelay: `${idx * 100}ms` }}
        >
          
          {/* Accent decoration line */}
          <div className="absolute top-0 right-0 w-1.5 h-full bg-gradient-to-b from-indigo-500 to-indigo-600"></div>
          <div className="flex gap-3.5 pr-2 w-full">
            
            <div className="p-2 bg-primary-default/20/80 rounded-xl text-primary-default shrink-0 self-start shadow-inner">
              
              <Megaphone className="w-4 h-4" />
            </div>
            <div className="w-full">
              
              <div className="flex items-center gap-2 flex-wrap justify-between">
                
                <h4 className="font-extrabold text-xs md:text-sm text-primary">
                  
                  {ann.title}
                </h4>
                <span className="inline-flex items-center gap-1 text-[9px] bg-primary-default/20 text-primary-hover font-bold px-2 py-0.5 rounded-full">
                  
                  <Calendar className="w-2.5 h-2.5" /> اطلاعیه جدید
                </span>
              </div>
              <p className="text-[11px] md:text-xs text-muted mt-1.5 leading-relaxed font-medium">
                
                {ann.content}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
