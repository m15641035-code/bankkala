import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const stack = [];
let inString = false;
let stringChar = '';
let inComment = false;
let inLineComment = false;
let currentLine = 1;

const trace = [];

for (let i = 0; i < content.length; i++) {
  const char = content[i];
  if (char === '\n') {
    currentLine++;
  }

  if (inComment) {
    if (char === '*' && content[i + 1] === '/') {
      inComment = false;
      i++;
    }
    continue;
  }

  if (inLineComment) {
    if (char === '\n') {
      inLineComment = false;
    }
    continue;
  }

  if (inString) {
    if (char === stringChar && content[i - 1] !== '\\') {
      inString = false;
    }
    continue;
  }

  if (char === '/' && content[i + 1] === '*') {
    inComment = true;
    i++;
    continue;
  }
  if (char === '/' && content[i + 1] === '/') {
    inLineComment = true;
    i++;
    continue;
  }

  if (char === '"' || char === "'" || char === '`') {
    inString = true;
    stringChar = char;
    continue;
  }

  if (char === '{') {
    const item = { line: currentLine, index: i, snippet: content.substring(i, i + 40).replace(/\n/g, ' ') };
    stack.push(item);
    trace.push(`OPEN  at line ${currentLine}: ${item.snippet} (stack depth: ${stack.length})`);
  } else if (char === '}') {
    if (stack.length > 0) {
      const item = stack.pop();
      trace.push(`CLOSE at line ${currentLine} matching line ${item.line} { ${item.snippet} } (stack depth: ${stack.length})`);
    } else {
      trace.push(`EXTRA CLOSE at line ${currentLine}`);
    }
  }
}

fs.writeFileSync('brace_trace.txt', trace.join('\n'));
console.log('Wrote brace trace to brace_trace.txt');
console.log('Final open stack size:', stack.length);
if (stack.length > 0) {
  console.log('Unclosed braces:');
  stack.forEach((item, idx) => {
    console.log(`- Open on Line ${item.line}: ${item.snippet}`);
  });
}
