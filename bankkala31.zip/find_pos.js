import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const positions = [32733, 32767, 33341];

positions.forEach(pos => {
  console.log(`\n--- POSITION ${pos} ---`);
  console.log('Context before:');
  console.log(line339.substring(pos - 100, pos));
  console.log('Context after:');
  console.log(line339.substring(pos, pos + 200));
});
