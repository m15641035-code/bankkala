import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr = 'ORDERS TAB';
const idx = line339.indexOf(searchStr);
if (idx !== -1) {
  console.log(line339.substring(idx + 7000, idx + 14000));
}
