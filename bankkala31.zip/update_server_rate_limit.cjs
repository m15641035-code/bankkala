const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

// Add import
code = code.replace(
  "import express from 'express';",
  "import express from 'express';\nimport rateLimit from 'express-rate-limit';"
);

// Create limiters after rootDir
const limitersCode = `
// Security: Rate Limiters
const webhookLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 webhook requests per windowMs
  message: { error: 'Too many webhook requests from this IP, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const payoutRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // Limit each IP to 5 payout requests per hour
  message: { error: 'Too many payout requests, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});
`;
code = code.replace("const rootDir = process.cwd();", "const rootDir = process.cwd();\n" + limitersCode);

// Apply to webhook
code = code.replace(
  "app.post('/api/webhooks/woocommerce', async (req: any, res: any) => {",
  "app.post('/api/webhooks/woocommerce', webhookLimiter, async (req: any, res: any) => {"
);

// Add supplier payout endpoint
const payoutEndpoint = `
app.post('/api/supplier/payout/request', authenticateToken, requireSupplier, payoutRequestLimiter, async (req: any, res: any) => {
  try {
    const supplierId = req.user.userId;
    const { amount } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'مبلغ تسویه نامعتبر است' });
    }
    
    const user = await prisma.user.findUnique({ where: { id: supplierId } });
    if (!user || !user.shaba) {
      return res.status(400).json({ error: 'لطفا ابتدا شماره شبا خود را در پروفایل ثبت کنید' });
    }
    
    const wallet = await prisma.wallet.findUnique({ where: { supplierId } });
    if (!wallet) {
      return res.status(404).json({ error: 'کیف پول یافت نشد' });
    }
    
    // Import dynamically to avoid top-level issues if needed, or we can use WalletService directly
    const { WalletService } = await import('./src/services/WalletService.js');
    const walletService = new WalletService();
    
    const payoutRequest = await walletService.requestPayout(wallet.id, amount, user.shaba);
    
    res.json({ success: true, message: 'درخواست تسویه با موفقیت ثبت شد', payoutRequest });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});
`;

code = code.replace(
  "app.get('/api/supplier/reports', authenticateToken, requireSupplier, async (req: any, res: any) => {",
  payoutEndpoint + "\napp.get('/api/supplier/reports', authenticateToken, requireSupplier, async (req: any, res: any) => {"
);

fs.writeFileSync('server.ts', code);
