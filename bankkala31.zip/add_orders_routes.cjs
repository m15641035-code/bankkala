const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

const routes = `
// =========================================================================
// MANUAL ORDERS (STORE MANAGER)
// =========================================================================
app.post('/api/store-manager/orders', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const { productId, quantity, notes } = req.body;
    
    if (!productId || !quantity) return res.status(400).json({ error: 'Product and quantity required' });
    
    const product = await prisma.product.findUnique({ where: { id: parseInt(productId) } });
    if (!product) return res.status(404).json({ error: 'محصول یافت نشد' });
    
    const qty = parseInt(quantity);
    let finalPrice = product.finalPrice;
    if (!finalPrice) {
      finalPrice = product.supplierBasePrice;
      if (product.marginType === 'PERCENTAGE' && product.marginValue) {
        finalPrice = product.supplierBasePrice * (1 + product.marginValue / 100);
      } else if (product.marginType === 'FIXED' && product.marginValue) {
        finalPrice = product.supplierBasePrice + product.marginValue;
      }
    }
    
    const totalAmount = finalPrice * qty;
    
    const newOrder = await prisma.order.create({
      data: {
        storeId,
        totalAmount,
        status: 'REQUESTED',
        items: {
          create: {
            supplierId: product.supplierId,
            productId: product.id,
            status: 'REQUESTED',
            quantity: qty,
            notes: notes || null,
            price: finalPrice,
            supplierPrice: product.supplierBasePrice
          }
        }
      },
      include: { items: true }
    });
    
    // Notify supplier
    await prisma.notification.create({
      data: {
        userId: product.supplierId,
        title: 'سفارش جدید',
        message: 'شما یک سفارش جدید دارید (منتظر تایید)',
        isRead: false
      }
    });
    
    res.json(newOrder);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

app.post('/api/store-manager/orders/:orderId/pay', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const { orderId } = req.params;
    
    const order = await prisma.order.findFirst({
      where: { id: parseInt(orderId), storeId },
      include: { items: true }
    });
    
    if (!order) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (order.status !== 'SUPPLIER_APPROVED' && order.status !== 'WAITING_FOR_PAYMENT') {
      return res.status(400).json({ error: 'سفارش در وضعیت پرداخت نیست' });
    }
    
    // Ensure wallet exists for supplier
    await prisma.$transaction(async (tx) => {
      await tx.order.update({
        where: { id: order.id },
        data: { status: 'PAID' }
      });
      
      for (const item of order.items) {
        await tx.orderItem.update({
          where: { id: item.id },
          data: { status: 'PAID' }
        });
        
        let wallet = await tx.wallet.findUnique({ where: { userId: item.supplierId } });
        if (!wallet) {
          wallet = await tx.wallet.create({ data: { userId: item.supplierId, balance: 0 } });
        }
        
        const supplierAmount = item.supplierPrice * item.quantity;
        
        await tx.walletTransaction.create({
          data: {
            walletId: wallet.id,
            type: 'CREDIT',
            amount: supplierAmount,
            description: \`سهم فروش از سفارش #\${order.id}\`,
            status: 'COMPLETED'
          }
        });
        
        await tx.wallet.update({
          where: { id: wallet.id },
          data: { balance: { increment: supplierAmount } }
        });
      }
    });
    
    res.json({ message: 'پرداخت با موفقیت انجام شد' });
  } catch(e) {
     console.error(e);
     res.status(500).json({ error: 'Server error' });
  }
});

// =========================================================================
// SUPPLIER ORDER ACTIONS (APPROVE/REJECT)
// =========================================================================
app.post('/api/supplier/orders/:itemId/approve', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { itemId } = req.params;
    const supplierId = req.user.userId || req.user.id;
    
    const item = await prisma.orderItem.findFirst({
      where: { id: parseInt(itemId), supplierId },
      include: { order: true }
    });
    
    if (!item) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (item.status !== 'REQUESTED') return res.status(400).json({ error: 'وضعیت سفارش نامعتبر است' });
    
    await prisma.orderItem.update({
      where: { id: item.id },
      data: { status: 'SUPPLIER_APPROVED' }
    });
    
    await prisma.order.update({
      where: { id: item.orderId },
      data: { status: 'SUPPLIER_APPROVED' }
    });
    
    await prisma.notification.create({
      data: {
        userId: item.order.storeId,
        title: 'تایید سفارش',
        message: \`سفارش #\${item.orderId} توسط تامین‌کننده تایید شد و آماده پرداخت است.\`,
        isRead: false
      }
    });
    
    res.json({ message: 'سفارش تایید شد' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

app.post('/api/supplier/orders/:itemId/reject', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { itemId } = req.params;
    const supplierId = req.user.userId || req.user.id;
    
    const item = await prisma.orderItem.findFirst({
      where: { id: parseInt(itemId), supplierId },
      include: { order: true }
    });
    
    if (!item) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (item.status !== 'REQUESTED') return res.status(400).json({ error: 'وضعیت سفارش نامعتبر است' });
    
    await prisma.orderItem.update({
      where: { id: item.id },
      data: { status: 'REJECTED' }
    });
    
    await prisma.order.update({
      where: { id: item.orderId },
      data: { status: 'REJECTED' }
    });
    
    await prisma.notification.create({
      data: {
        userId: item.order.storeId,
        title: 'رد سفارش',
        message: \`متاسفانه سفارش #\${item.orderId} توسط تامین‌کننده رد شد.\`,
        isRead: false
      }
    });
    
    res.json({ message: 'سفارش رد شد' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

`;

code = code.replace("app.listen(PORT", routes + "\napp.listen(PORT");
fs.writeFileSync('server.ts', code);
