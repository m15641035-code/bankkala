const fs = require('fs');
['src/services/announcementsRoute.ts', 'src/services/newFeaturesRoute.ts', 'src/services/configRoute.ts', 'src/services/orderLabelRoute.ts'].forEach(filename => {
  let code = fs.readFileSync(filename, 'utf8');
  // replace any '//' followed by text and then 'app.' with '/*...*/ app.'
  code = code.replace(/\/\/([^]*?)app\./g, '/* $1 */ app.');
  code = code.replace(/\/\/([^]*?)const /g, '/* $1 */ const ');
  code = code.replace(/\/\/([^]*?)let /g, '/* $1 */ let ');
  code = code.replace(/\/\/([^]*?)return /g, '/* $1 */ return ');
  // clean up any multi-line comments that accidentally swallowed too much?
  // Actually, replacing `//` with `\n//` is much safer!
});
