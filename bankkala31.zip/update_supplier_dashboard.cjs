const fs = require('fs');

let code = fs.readFileSync('src/components/supplier/SupplierDashboard.tsx', 'utf8');

// Update state definition
code = code.replace(
  "const [walletInfo, setWalletInfo] = useState<{ wallet: any, transactions: any[] }>({ wallet: null, transactions: [] });",
  "const [walletInfo, setWalletInfo] = useState<any>({ balance: 0, totalEarnings: 0, totalWithdrawn: 0, history: [] });"
);

// Update render part
const oldWalletTab = `              {activeTab === 'wallet' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-500 rounded-full blur-3xl opacity-30"></div>
                    <div className="absolute top-10 right-10 w-32 h-32 bg-purple-500 rounded-full blur-3xl opacity-20"></div>
                    
                    <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div>
                        <p className="text-indigo-200 font-medium mb-1">موجودی قابل تسویه (تومان)</p>
                        <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                          {(walletInfo.wallet?.balance || 0).toLocaleString()}
                        </h2>
                        <div className="flex items-center gap-2 mt-4 text-sm text-indigo-200">
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                          شماره شبا ثبت شده: <span className="font-mono text-white text-xs">{user?.shaba}</span>
                        </div>
                      </div>
                      <button className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-50 transition-colors">
                        درخواست تسویه حساب
                      </button>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100">
                    <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                      <h3 className="font-bold text-slate-800 text-lg">تراکنش‌های اخیر</h3>
                    </div>
                    {walletInfo.transactions.length > 0 ? (
                      <div className="divide-y divide-slate-100">
                        {walletInfo.transactions.map((tx: any) => (
                          <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div className="flex items-center gap-4">
                              <div className={\`w-10 h-10 rounded-full flex items-center justify-center \${
                                tx.type === 'CREDIT' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                              }\`}>
                                {tx.type === 'CREDIT' ? <TrendingUp className="w-5 h-5" /> : <TrendingUp className="w-5 h-5 transform rotate-180" />}
                              </div>
                              <div>
                                <p className="font-bold text-slate-800 text-sm">
                                  {tx.type === 'CREDIT' ? 'فروش محصول' : 'تسویه حساب'}
                                </p>
                                <p className="text-xs text-slate-500 mt-1 font-mono">
                                  {new Date(tx.createdAt).toLocaleDateString('fa-IR')}
                                </p>
                              </div>
                            </div>
                            <span className={\`font-bold \${tx.type === 'CREDIT' ? 'text-emerald-600' : 'text-rose-600'}\`}>
                              {tx.type === 'CREDIT' ? '+' : '-'}{tx.amount.toLocaleString()} تومان
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-8 text-center text-slate-500">
                        <Wallet className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                        <p>هیچ تراکنشی یافت نشد.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}`;

const newWalletTab = `              {activeTab === 'wallet' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden md:col-span-2">
                      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-500 rounded-full blur-3xl opacity-30"></div>
                      <div className="absolute top-10 right-10 w-32 h-32 bg-purple-500 rounded-full blur-3xl opacity-20"></div>
                      
                      <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 h-full">
                        <div>
                          <p className="text-indigo-200 font-medium mb-1">موجودی قابل تسویه (تومان)</p>
                          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                            {Number(walletInfo.balance || 0).toLocaleString()}
                          </h2>
                          <div className="flex items-center gap-2 mt-4 text-sm text-indigo-200">
                            <CheckCircle className="w-4 h-4 text-emerald-400" />
                            شماره شبا ثبت شده: <span className="font-mono text-white text-xs">{user?.shaba || 'ثبت نشده'}</span>
                          </div>
                        </div>
                        <button className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-50 transition-colors whitespace-nowrap">
                          درخواست تسویه حساب
                        </button>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-6">
                      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col justify-center">
                        <p className="text-slate-500 font-medium mb-1 text-sm">کل درآمدهای شما (تومان)</p>
                        <h3 className="text-2xl font-bold text-slate-800">
                          {Number(walletInfo.totalEarnings || 0).toLocaleString()}
                        </h3>
                        <div className="mt-2 text-xs font-medium text-emerald-600 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" /> از ابتدای فعالیت
                        </div>
                      </div>
                      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col justify-center">
                        <p className="text-slate-500 font-medium mb-1 text-sm">کل تسویه شده (تومان)</p>
                        <h3 className="text-2xl font-bold text-slate-800">
                          {Number(walletInfo.totalWithdrawn || 0).toLocaleString()}
                        </h3>
                        <div className="mt-2 text-xs font-medium text-indigo-600 flex items-center gap-1">
                          <Wallet className="w-3 h-3" /> مبالغ واریز شده به حساب
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                      <h3 className="font-bold text-slate-800 text-lg">تراکنش‌های اخیر و گزارشات</h3>
                      <div className="flex gap-2">
                        <select className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block p-2">
                          <option value="">همه وضعیت‌ها</option>
                          <option value="COMPLETED">موفق</option>
                          <option value="PENDING">در حال انجام</option>
                          <option value="FAILED">ناموفق</option>
                        </select>
                        <select className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block p-2">
                          <option value="">همه انواع</option>
                          <option value="ORDER_REVENUE">درآمد فروش</option>
                          <option value="WITHDRAWAL">برداشت/تسویه</option>
                        </select>
                      </div>
                    </div>
                    {walletInfo.history && walletInfo.history.length > 0 ? (
                      <div className="divide-y divide-slate-100">
                        {walletInfo.history.map((tx: any) => (
                          <div key={tx.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between hover:bg-slate-50 transition-colors gap-4">
                            <div className="flex items-center gap-4">
                              <div className={\`w-12 h-12 rounded-full flex items-center justify-center shrink-0 \${
                                tx.type === 'ORDER_REVENUE' || tx.type === 'CREDIT' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                              }\`}>
                                {tx.type === 'ORDER_REVENUE' || tx.type === 'CREDIT' ? <TrendingUp className="w-6 h-6" /> : <TrendingUp className="w-6 h-6 transform rotate-180" />}
                              </div>
                              <div>
                                <p className="font-bold text-slate-800 text-base">
                                  {tx.type === 'ORDER_REVENUE' || tx.type === 'CREDIT' ? 'درآمد حاصل از فروش' : 'درخواست تسویه حساب'}
                                </p>
                                <p className="text-sm text-slate-500 mt-1">
                                  {tx.description}
                                </p>
                                <div className="flex gap-3 mt-2 text-xs">
                                  <span className="font-mono text-slate-400">
                                    {new Date(tx.createdAt).toLocaleDateString('fa-IR')} - {new Date(tx.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                                  </span>
                                  <span className={\`px-2 py-0.5 rounded-full font-medium \${
                                    tx.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-700' :
                                    tx.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                                    'bg-rose-100 text-rose-700'
                                  }\`}>
                                    {tx.status === 'COMPLETED' ? 'موفق' : tx.status === 'PENDING' ? 'در حال پردازش' : 'ناموفق'}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col items-end shrink-0">
                              <span className={\`text-lg font-bold \${tx.type === 'ORDER_REVENUE' || tx.type === 'CREDIT' ? 'text-emerald-600' : 'text-rose-600'}\`}>
                                {tx.type === 'ORDER_REVENUE' || tx.type === 'CREDIT' ? '+' : '-'}{Number(tx.amount).toLocaleString()} تومان
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-12 text-center text-slate-500">
                        <Wallet className="w-16 h-16 mx-auto text-slate-200 mb-4" />
                        <p className="text-lg font-medium text-slate-700 mb-1">هیچ تراکنشی یافت نشد</p>
                        <p className="text-sm text-slate-500">تا کنون فعالیتی در کیف پول شما ثبت نشده است.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}`;

code = code.replace(oldWalletTab, newWalletTab);

fs.writeFileSync('src/components/supplier/SupplierDashboard.tsx', code);
