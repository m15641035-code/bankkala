const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Reverse replacements
content = content.replace(/\n\/\/ STEP 1:\n/g, "// STEP 1:");
content = content.replace(/\n\/\/ STEP 2:\n/g, "// STEP 2:");
content = content.replace(/\n\/\/ STEP 3:\n/g, "// STEP 3:");
content = content.replace(/\n\/\/ STEP 4:\n/g, "// STEP 4:");
content = content.replace(/\n\/\/ STEP 5:\n/g, "// STEP 5:");

// Just in case
content = content.replace(/\n\/\/ Personal Info\n/g, "// Personal Info");
content = content.replace(/\n\/\/ Business Info\n/g, "// Business Info");
content = content.replace(/\n\/\/ Financial Info\n/g, "// Financial Info");
content = content.replace(/\n\/\/ Credentials Summary\n/g, "// Credentials Summary");
content = content.replace(/\n\/\/ Store Details\n/g, "// Store Details");
content = content.replace(/\n\/\/ Supplier Draft Restore Banner\n/g, "// Supplier Draft Restore Banner");

fs.writeFileSync('src/App.tsx', content);
console.log('App.tsx splits undone.');
