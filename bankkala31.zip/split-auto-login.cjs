const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target = "// Auto-login if token exists  useEffect";
if (content.includes(target)) {
  content = content.replace(target, "\n// Auto-login if token exists\nuseEffect");
  console.log('Successfully split Auto-login comment from useEffect!');
} else {
  // Let's do a search with indexOf or replace with regex
  const idx = content.indexOf("// Auto-login");
  if (idx !== -1) {
    console.log('Found partial match starting with // Auto-login:');
    console.log(content.substring(idx, idx + 150));
    // Let's replace any spaces after 'exists' with a newline
    const sub = content.substring(idx, idx + 100);
    const replaced = sub.replace(/exists\s+useEffect/, "exists\nuseEffect");
    content = content.replace(sub, replaced);
    console.log('Split completed via search and replace.');
  }
}

fs.writeFileSync('src/App.tsx', content);
