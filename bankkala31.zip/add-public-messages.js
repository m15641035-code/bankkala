const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const publicMessagesRoute = `
// Public Messages for Landing Page
app.get('/api/public-messages', async (req, res) => {
  res.json([
    { id: 1, text: "به پلتفرم B2B ما خوش آمدید!", type: "info" },
    { id: 2, text: "ثبت‌نام برای تامین‌کنندگان با تخفیف ویژه", type: "success" }
  ]);
});
`;

content = content.replace("app.get('/api/health', (req, res) => res.json({ status: \"ok\" }));", "app.get('/api/health', (req, res) => res.json({ status: \"ok\" }));\n" + publicMessagesRoute);

fs.writeFileSync('server.ts', content);
