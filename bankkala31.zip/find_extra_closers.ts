import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const pos1 = 41673;
const pos2 = 49665;

console.log('--- Extra ) at col 41673 ---');
console.log(JSON.stringify(line339.substring(pos1 - 50, pos1 + 50)));

console.log('--- Extra ) at col 49665 ---');
console.log(JSON.stringify(line339.substring(pos2 - 50, pos2 + 50)));
