import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr1 = 'LineChart';
const idx1 = line339.indexOf(searchStr1);
if (idx1 !== -1) {
  console.log('=== LineChart Context ===');
  console.log(line339.substring(idx1 - 100, idx1 + 1200));
}

const searchStr2 = 'BarChart';
const idx2 = line339.indexOf(searchStr2);
if (idx2 !== -1) {
  console.log('\n=== BarChart Context ===');
  console.log(line339.substring(idx2 - 100, idx2 + 1000));
}
