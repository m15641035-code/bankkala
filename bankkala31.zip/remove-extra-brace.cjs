const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Find the end of the first useEffect with three braces and replace with two
const regex = /localStorage\.removeItem\('user'\);\s*\}\s*\}\s*\}\s*\}\s*,\s*\[token\]\s*\);/;
// Wait, let's search for exactly what is there.
const match = content.match(/localStorage\.removeItem\('user'\);\s*\}\s*\}\s*\}\s*,\s*\[token\]\s*\);/);
if (match) {
  console.log('Found match:', match[0]);
  content = content.replace(match[0], "localStorage.removeItem('user'); } }, [token]);");
} else {
  // Try another match with 4 braces or space combinations
  const match2 = content.match(/localStorage\.removeItem\('user'\);\s*\}\s*\}\s*\}\s*\}\s*,\s*\[token\]\s*\);/);
  if (match2) {
    console.log('Found match2:', match2[0]);
    content = content.replace(match2[0], "localStorage.removeItem('user'); } }, [token]);");
  } else {
    console.log('No literal brace match. Printing context:');
    const idx = content.indexOf("localStorage.removeItem('user')");
    if (idx !== -1) {
      console.log(content.substring(idx, idx + 100));
      // Let's replace the first encountered braces after the statement
      const sub = content.substring(idx, idx + 100);
      const replacedSub = sub.replace(/\}\s*\}\s*\}\s*,\s*\[token\]\s*\);/, "} }, [token]);");
      content = content.replace(sub, replacedSub);
    }
  }
}

fs.writeFileSync('src/App.tsx', content);
console.log('Finished updating App.tsx.');

