const fs = require('fs');
const content = fs.readFileSync('src/components/superadmin/SuperAdminDashboard.tsx', 'utf8');

const regex = /Overview/g;
let match;
while ((match = regex.exec(content)) !== null) {
  console.log(`Found 'Overview' at index ${match.index}:`);
  console.log(content.substring(Math.max(0, match.index - 100), Math.min(content.length, match.index + 200)));
  console.log('----------------');
}
