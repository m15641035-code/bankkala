const fs = require('fs');
let code = fs.readFileSync('src/components/supplier/SupplierDashboard.tsx', 'utf8');

const regex = /\{\/\* ORDERS TAB \*\/\}\s*\{activeTab === 'orders' && \([\s\S]*?سفارشی برای محصولات شما ثبت نشده است\.\s*<\/p>\s*<\/div>\s*\)\}\s*<\/div>\s*<\/div>\s*\)\}/;

const newOrdersTab = `{/* ORDERS TAB */}
              {activeTab === 'orders' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    {orders.length > 0 ? (
                      <div className="overflow-x-auto">
                        <table className="w-full text-right text-sm">
                          <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                            <tr>
                              <th className="px-6 py-4">سفارش</th>
                              <th className="px-6 py-4">فروشگاه</th>
                              <th className="px-6 py-4">محصول / SKU</th>
                              <th className="px-6 py-4">تعداد</th>
                              <th className="px-6 py-4">موجودی فعلی</th>
                              <th className="px-6 py-4">یادداشت</th>
                              <th className="px-6 py-4">وضعیت</th>
                              <th className="px-6 py-4">عملیات</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {orders.map(order => (
                              <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                                <td className="px-6 py-4">
                                  <div className="font-mono font-medium text-indigo-600">#{order.id}</div>
                                  {order.order?.createdAt && (
                                    <div className="text-xs text-slate-500 mt-1">
                                      {new Date(order.order.createdAt).toLocaleDateString('fa-IR')}
                                    </div>
                                  )}
                                </td>
                                <td className="px-6 py-4 text-slate-800 text-xs">
                                  کاربر #{order.order?.storeId}
                                </td>
                                <td className="px-6 py-4">
                                  <div className="text-slate-800 font-medium">{order.product?.name}</div>
                                  <div className="text-xs text-slate-500 mt-1">{order.product?.sku || 'بدون SKU'}</div>
                                </td>
                                <td className="px-6 py-4 text-slate-800 font-bold">
                                  {order.quantity || 1}
                                </td>
                                <td className="px-6 py-4">
                                  <span className={\`font-bold \${order.product?.inventory >= order.quantity ? 'text-emerald-600' : 'text-rose-600'}\`}>
                                    {order.product?.inventory}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-xs text-slate-500 max-w-[150px] truncate" title={order.notes}>
                                  {order.notes || '-'}
                                </td>
                                <td className="px-6 py-4">
                                  <span className={\`px-2.5 py-1 rounded-full text-xs font-semibold \${
                                    order.status === 'REQUESTED' ? 'bg-amber-100 text-amber-700' :
                                    order.status === 'SUPPLIER_APPROVED' ? 'bg-blue-100 text-blue-700' :
                                    order.status === 'WAITING_FOR_PAYMENT' ? 'bg-purple-100 text-purple-700' :
                                    order.status === 'PAID' ? 'bg-emerald-100 text-emerald-700' :
                                    order.status === 'PREPARING' ? 'bg-indigo-100 text-indigo-700' :
                                    order.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-700' :
                                    order.status === 'REJECTED' ? 'bg-rose-100 text-rose-700' :
                                    order.status === 'CANCELLED' ? 'bg-slate-100 text-slate-700' :
                                    'bg-slate-100 text-slate-700'
                                  }\`}>
                                    {order.status === 'REQUESTED' ? 'در حال بررسی' :
                                     order.status === 'SUPPLIER_APPROVED' ? 'تایید شده' :
                                     order.status === 'WAITING_FOR_PAYMENT' ? 'در انتظار پرداخت' :
                                     order.status === 'PAID' ? 'پرداخت شده' :
                                     order.status === 'PREPARING' ? 'در حال آماده‌سازی' :
                                     order.status === 'COMPLETED' ? 'تکمیل شده' :
                                     order.status === 'REJECTED' ? 'رد شده' :
                                     order.status === 'CANCELLED' ? 'لغو شده' : order.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 flex flex-col gap-2">
                                  {(order.status === 'REQUESTED' || order.status === 'PENDING') && (
                                    <>
                                      <button 
                                        onClick={() => updateOrderStatus(order.id, 'SUPPLIER_APPROVED')}
                                        className="text-xs bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                      >
                                        تایید موجودی
                                      </button>
                                      <button 
                                        onClick={() => updateOrderStatus(order.id, 'REJECTED')}
                                        className="text-xs bg-rose-50 text-rose-600 hover:bg-rose-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                      >
                                        رد سفارش
                                      </button>
                                    </>
                                  )}
                                  {order.status === 'PAID' && (
                                    <button 
                                      onClick={() => updateOrderStatus(order.id, 'PREPARING')}
                                      className="text-xs bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                    >
                                      در حال آماده‌سازی
                                    </button>
                                  )}
                                  {order.status === 'PREPARING' && (
                                    <button 
                                      onClick={() => updateOrderStatus(order.id, 'COMPLETED')}
                                      className="text-xs bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                    >
                                      تکمیل ارسال
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="text-center py-16 text-slate-500">
                        <ShoppingCart className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                        <p className="text-lg font-medium text-slate-700 mb-1">سفارشی ندارید</p>
                        <p className="text-sm">هنوز سفارشی برای محصولات شما ثبت نشده است.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}`;

if (regex.test(code)) {
  code = code.replace(regex, newOrdersTab);
  fs.writeFileSync('src/components/supplier/SupplierDashboard.tsx', code);
  console.log("Orders tab replaced");
} else {
  console.log("Regex not matched");
}
