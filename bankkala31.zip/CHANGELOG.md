# Changelog

All notable changes to this project will be documented in this file.

## [2026-07-14]
- Initial documentation setup.
