const fs = require('fs');
const execSync = require('child_process').execSync;

const frontendRoutes = execSync('grep -rhoP "\"/api/[^\"]+\"" src/ | sort | uniq').toString().split('\n').filter(r => r).map(r => r.replace(/"/g, ''));
const backendFiles = execSync('find server.ts src/services/ -name "*.ts"').toString().split('\n').filter(f => f);

const allBackendContent = backendFiles.map(f => fs.readFileSync(f, 'utf8')).join('\n');

frontendRoutes.forEach(route => {
  // Try to find a match. Some routes have dynamic parts (e.g., /api/admin/products/${id})
  const baseRoute = route.split('?')[0].split('$')[0].split('/(')[0].replace(/\/:\w+$/, '');
  
  if (!allBackendContent.includes(baseRoute)) {
    console.log(`Missing route: ${baseRoute} (original: ${route})`);
  }
});
