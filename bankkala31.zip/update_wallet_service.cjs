const fs = require('fs');

let code = fs.readFileSync('src/services/WalletService.ts', 'utf8');

// Add import
code = code.replace(
  "import { PaymentServiceFactory } from './payment/PaymentServiceFactory';",
  "import { PaymentServiceFactory } from './payment/PaymentServiceFactory';\nimport { appEvents } from './NotificationService';"
);

// In creditWallet, after commit
code = code.replace(
  "return ledgerEntry;",
  `
      // Emit event after successful credit
      appEvents.emit('wallet.credited', {
        walletId,
        amount: transactionAmount.toNumber(),
        supplierId: wallet.supplierId
      });

      return ledgerEntry;`
);

// In syncPayoutStatus, emit event if SUCCESS
code = code.replace(
  "// If it failed, unlock the funds",
  `
        if (newStatus === PayoutStatus.SUCCESS) {
          const wallet = await tx.wallet.findUnique({ where: { id: payoutRequest.walletId }});
          if (wallet) {
            appEvents.emit('payout.success', {
              walletId: payoutRequest.walletId,
              amount: payoutRequest.amount.toNumber(),
              supplierId: wallet.supplierId,
              shaba: payoutRequest.shaba
            });
          }
        }

        // If it failed, unlock the funds`
);

fs.writeFileSync('src/services/WalletService.ts', code);
