# BankKala Production Checklist

## Security & IP Restrictions
- [ ] **Zibal IP Whitelisting**: Ensure the production server's outgoing IP (`88.135.68.251`) is correctly registered at the Zibal merchant panel. Failure to do so will result in failed API requests.
- [ ] **WooCommerce Webhook Security**: Validate that the `x-wc-webhook-signature` is verified against the store's shared secret for every webhook request to prevent spoofed order payloads.
- [ ] **Rate Limiting Active**: Verify `express-rate-limit` is functioning correctly on critical endpoints:
  - `/api/webhooks/woocommerce`
  - `/api/supplier/payout/request`
- [ ] **RBAC Verification**: Confirm that endpoints check `req.user.role` correctly (e.g. `SUPPLIER`, `SUPER_ADMIN`, `STORE_MANAGER`).

## Database & Performance
- [ ] **Index Configuration**: Ensure Prisma schema includes indexes on high-traffic queries.
  - `LedgerEntry`: `@@index([walletId])`, `@@index([createdAt])`, `@@index([referenceId])`
  - `PayoutRequest`: `@@index([walletId])`, `@@index([status])`
- [ ] **Transaction Safety**: Validate that financial movements (wallet credits, debits, and payouts) are executing within Prisma `$transaction` blocks to prevent race conditions.

## Environment Variables (.env)
- [ ] **Zibal API Token**: Keep the token secure. It **must not** be committed to Git.
  ```env
  ZIBAL_MERCHANT=c2d30fa3b90d4b41b72f5b4bd6648ecd
  # Keep other secrets out of source control as well
  ```
- [ ] **JWT Secret**: Use a strong, random string for `JWT_SECRET` in production.
- [ ] **Node Environment**: Ensure `NODE_ENV=production` is set so mock gateways are disabled and real gateways are used.

## Infrastructure & Maintenance
- [ ] **SSL/TLS**: Ensure the application is served over HTTPS to protect data in transit.
- [ ] **Backups**: Configure automated daily backups for the Cloud SQL PostgreSQL database.
