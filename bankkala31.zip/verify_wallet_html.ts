import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr = 'WALLET TAB';
const idx = line339.indexOf(searchStr);
const endIdx = line339.indexOf('ADD PRODUCT TAB');

const segment = line339.substring(idx, endIdx);

// Standard HTML parser to find mismatched tags
const tagRegex = /<\/?([a-zA-Z0-9:-]+)(?:\s+[^>]*)?>/g;

let match;
const stack: string[] = [];
const selfClosing = ['input', 'img', 'br', 'hr', 'col', 'source', 'AlertCircle', 'Clock', 'Wallet', 'TrendingUp', 'CheckCircle', 'X', 'AlertCircle', 'Check', 'Copy'];

while ((match = tagRegex.exec(segment)) !== null) {
  const fullTag = match[0];
  const tagName = match[1];
  
  if (fullTag.startsWith('</')) {
    // Closing tag
    if (stack.length === 0) {
      console.log(`Error: Closing tag </${tagName}> without open tag!`);
    } else {
      const top = stack.pop();
      if (top !== tagName) {
        console.log(`Mismatch: Expected </${top}> but got </${tagName}>`);
      }
    }
  } else if (fullTag.endsWith('/>') || selfClosing.includes(tagName)) {
    // Self-closing, do nothing
  } else {
    // Opening tag
    stack.push(tagName);
  }
}

console.log('Unclosed tags at the end of WALLET TAB:');
console.log(stack);
