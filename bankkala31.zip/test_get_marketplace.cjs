const axios = require('axios');
async function test() {
  try {
    console.log("Checking api...");
  } catch(e) {
    console.error(e);
  }
}
test();
