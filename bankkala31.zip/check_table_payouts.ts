import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const tableSection = line339.substring(32500, 35500);

const tagRegex = /<\/?([a-zA-Z0-9:-]+)(?:\s+[^>]*)?>/g;
let match;
const stack: { tag: string; index: number; full: string }[] = [];

while ((match = tagRegex.exec(tableSection)) !== null) {
  const full = match[0];
  const tag = match[1];
  const isClosing = full.startsWith('</');
  const isSelfClosing = full.replace(/\s+/g, '').endsWith('/>');
  
  if (isClosing) {
    if (stack.length === 0) {
      console.log(`Unmatched closing tag in section: </${tag}> at position ${match.index}`);
    } else {
      const top = stack.pop()!;
      if (top.tag !== tag) {
        console.log(`Mismatch in section: Opened <${top.tag}> but closed with </${tag}>`);
        console.log('Opened:', top.full);
        console.log('Closed:', full);
      }
    }
  } else if (!isSelfClosing) {
    stack.push({ tag, index: match.index, full });
  }
}

console.log('Remaining open tags in table section:', stack.length);
stack.forEach(s => {
  console.log(`Unclosed: <${s.tag}>`);
  console.log(s.full);
});
