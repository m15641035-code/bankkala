import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const positions = [
  { type: '(', col: 2517 },
  { type: '(', col: 24847 },
  { type: '(', col: 24940 },
  { type: '(', col: 32618 },
  { type: '{', col: 2345 },
  { type: '{', col: 24821 },
  { type: '{', col: 30542 },
  { type: '{', col: 33330 },
];

for (const pos of positions) {
  const index = pos.col - 1; // 0-indexed column matching
  console.log(`\n--- Unclosed '${pos.type}' at col ${pos.col} ---`);
  console.log(line339.substring(index - 50, index + 150));
}
