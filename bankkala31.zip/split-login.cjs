const fs = require('fs');
let appStr = fs.readFileSync('src/App.tsx', 'utf8');

const loginBlockRegex = /\{view === "login" && \(\(\) => \{[\s\S]*?return \([\s\S]*?\}\)\(\)\}/;

const newLoginBlock = `{view === "login" && (
  <div className="w-full max-w-[1000px] flex flex-col md:flex-row bg-white dark:bg-surface rounded-[2.5rem] shadow-2xl overflow-hidden border border-border-default/50 dark:border-border-subtle/50" dir="rtl">
    {/* Right Side: Login Form */}
    <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary-default/10 rounded-full blur-3xl -z-10 translate-x-1/3 -translate-y-1/3"></div>
      
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 bg-gradient-to-br from-primary-default to-accent text-white rounded-xl flex items-center justify-center shadow-lg shadow-primary-default/20">
          <Store className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-text-primary">بانک کالا</h1>
          <p className="text-xs font-bold text-primary-default">پلتفرم یکپارچه B2B</p>
        </div>
      </div>

      <div className="mb-8 text-right">
        <h2 className="text-xl font-black text-text-primary mb-2">ورود به حساب کاربری</h2>
        <p className="text-sm text-text-muted font-medium">جهت ورود به سیستم اطلاعات خود را وارد کنید</p>
      </div>

      <form onSubmit={handleLoginSubmit} className="space-y-5">
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-text-secondary">نام کاربری</label>
          <div className="relative group">
            <input
              type="text"
              required
              value={loginUsername}
              onChange={(e) => setLoginUsername(e.target.value)}
              className="w-full pl-4 pr-11 py-3.5 bg-background hover:bg-surface/80 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all text-text-primary font-bold border-border-default dark:border-border-subtle"
              placeholder="نام کاربری یا موبایل"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-text-muted group-focus-within:text-primary-default transition-colors">
              <User className="w-5 h-5" />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-text-secondary">رمز عبور</label>
            <a href="#" className="text-[10px] text-primary-default font-bold hover:underline">فراموشی رمز؟</a>
          </div>
          <div className="relative group">
            <input
              type={showLoginPassword ? "text" : "password"}
              required
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              className="w-full pl-12 pr-11 py-3.5 bg-background hover:bg-surface/80 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-default/20 focus:border-primary-default transition-all text-text-primary font-bold border-border-default dark:border-border-subtle"
              placeholder="رمز عبور"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-text-muted group-focus-within:text-primary-default transition-colors">
              <Lock className="w-5 h-5" />
            </div>
            <button
              type="button"
              onClick={() => setShowLoginPassword(!showLoginPassword)}
              className="absolute inset-y-0 left-0 pl-4 flex items-center text-text-muted hover:text-primary-default transition-colors"
            >
              {showLoginPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <motion.button
          type="submit"
          disabled={loading}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          className="w-full bg-primary-default hover:bg-primary-hover text-white font-black py-4 rounded-xl shadow-lg shadow-primary-default/25 transition-all flex items-center justify-center gap-2 mt-2 disabled:opacity-75"
        >
          {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <span>ورود به سیستم</span>}
        </motion.button>
      </form>

      <div className="mt-8 text-center border-t border-border-default/50 dark:border-border-subtle/50 pt-6">
        <p className="text-xs text-text-muted">
          حساب کاربری ندارید؟ 
          <button onClick={() => setView("role_select")} className="text-primary-default font-bold mr-1 hover:underline">ثبت‌نام سریع</button>
        </p>
      </div>
    </div>

    {/* Left Side: Dynamic Banners & Announcements */}
    <div className="hidden md:flex w-1/2 bg-surface dark:bg-background relative p-8 flex-col justify-between overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] z-0"></div>
      
      <div className="relative z-10">
        <div className="bg-primary-default/10 text-primary-default text-xs font-bold px-3 py-1.5 rounded-full inline-block mb-4">
          اطلاعیه سامانه
        </div>
        <Announcements role="ALL" compact />
      </div>

      <div className="relative z-10 mt-12 bg-gradient-to-br from-primary-default/5 to-accent/5 border border-primary-default/10 rounded-2xl p-6 backdrop-blur-sm">
        <div className="w-10 h-10 bg-primary-default/10 text-primary-default rounded-xl flex items-center justify-center mb-4">
          <Globe className="w-5 h-5" />
        </div>
        <h3 className="text-lg font-black text-text-primary mb-2">توسعه تجارت در سطح ملی</h3>
        <p className="text-sm text-text-muted leading-relaxed">
          با اتصال به شبکه گسترده تأمین‌کنندگان و فروشگاه‌های بانک کالا، زنجیره تأمین خود را بهینه‌سازی کنید و از ابزارهای هوشمند اعتباری بهره‌مند شوید.
        </p>
      </div>
    </div>
  </div>
)}`;

appStr = appStr.replace(loginBlockRegex, newLoginBlock);
fs.writeFileSync('src/App.tsx', appStr);
