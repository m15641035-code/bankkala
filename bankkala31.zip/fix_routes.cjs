const fs = require('fs');

function fixFile(filename) {
  let code = fs.readFileSync(filename, 'utf8');
  // replace '// (some text) app.' with '/* $1 */ app.'
  code = code.replace(/\/\/ ([^a-z]*[a-zA-Z0-9 _\(\)]+) app\./g, '/* $1 */ app.');
  code = code.replace(/\/\/ ([^a-z]*[a-zA-Z0-9 _\(\)]+) res\./g, '/* $1 */ res.');
  code = code.replace(/\/\/ ([^a-z]*[a-zA-Z0-9 _\(\)]+) const\./g, '/* $1 */ const.');
  code = code.replace(/\/\/ ([^a-z]*[a-zA-Z0-9 _\(\)]+) const /g, '/* $1 */ const ');
  
  // also fix if they end with router.
  code = code.replace(/\/\/ ([^a-z]*[a-zA-Z0-9 _\(\)]+) router\./g, '/* $1 */ router.');

  fs.writeFileSync(filename, code);
}

['src/services/announcementsRoute.ts', 'src/services/newFeaturesRoute.ts', 'src/services/configRoute.ts', 'src/services/orderLabelRoute.ts'].forEach(fixFile);
