import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

console.log('--- Modal and Tab Boundary Context ---');
console.log(line339.substring(39000, 42000));
