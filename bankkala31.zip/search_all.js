import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const regex = /\.map/g;
let match;
while ((match = regex.exec(line339)) !== null) {
  console.log(`Found .map at position ${match.index}:`);
  console.log(line339.substring(match.index - 50, match.index + 150));
  console.log('---');
}
