
export default function registerOrderLabels(app: any, prisma: any) { app.post('/api/orders/:id/label', async (req: any, res: any) => { try { const { id } = req.params; const { labelUrl } = req.body; const order = await prisma.order.update({ where: { id }, data: { postalLabel: labelUrl } }); res.json(order); } catch (error) { res.status(500).json({ error:'Internal server error' }); } });
}
