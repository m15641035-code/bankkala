const fs = require('fs');
let serverTs = fs.readFileSync('server.ts', 'utf8');

const mockRoute = `
// ==========================================
// Mock Payment Gateway Routes (Development Only)
// ==========================================
app.get('/api/mock/payment-callback', async (req, res) => {
  const { authority, status, callbackUrl } = req.query;
  
  // If no status is provided, we simulate a payment UI
  if (!status && authority && callbackUrl) {
    const html = \`
      <html>
        <body style="font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; background: #f9fafb;">
          <div style="background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center;">
            <h2 style="margin-top: 0;">Mock Payment Gateway</h2>
            <p>Authority: <strong>\${authority}</strong></p>
            <div style="margin-top: 2rem; display: flex; gap: 1rem; justify-content: center;">
              <a href="/api/mock/payment-callback?authority=\${authority}&status=success&callbackUrl=\${encodeURIComponent(callbackUrl)}" style="background: #10b981; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; font-weight: bold;">Simulate Success</a>
              <a href="/api/mock/payment-callback?authority=\${authority}&status=failed&callbackUrl=\${encodeURIComponent(callbackUrl)}" style="background: #ef4444; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 4px; font-weight: bold;">Simulate Failure</a>
            </div>
          </div>
        </body>
      </html>
    \`;
    res.send(html);
    return;
  }

  // Handle the simulation callback
  if (authority && typeof authority === 'string') {
    import('./src/services/payment/MockZibalService.js').then(({ mockPaymentStore }) => {
      const record = mockPaymentStore.get(authority);
      if (record) {
        record.status = status === 'failed' ? 'failed' : 'success';
      }
    }).catch(console.error);
  }
  
  if (callbackUrl && typeof callbackUrl === 'string') {
    res.redirect(\`\${callbackUrl}?Authority=\${authority}&Status=\${status === 'success' ? 'OK' : 'NOK'}\`);
  } else {
    res.json({ message: 'Mock payment processed', authority, status });
  }
});

async function startServer() {
`;

serverTs = serverTs.replace('async function startServer() {', mockRoute);
fs.writeFileSync('server.ts', serverTs);
