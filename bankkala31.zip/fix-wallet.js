const fs = require('fs');
let code = fs.readFileSync('src/services/WalletService.ts', 'utf8');

// I will just strip ALL `//` comments that don't look like URLs
code = code.replace(/\/\/[^\n]*/g, '');

fs.writeFileSync('src/services/WalletService.ts', code);
