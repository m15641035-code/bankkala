import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
console.log('Total lines:', lines.length);
console.log('Line 338:', lines[337]);
const line339 = lines[338];
console.log('Line 339 length:', line339.length);
console.log('Line 339 last 1500 chars:');
console.log(line339.substring(line339.length - 1500));
console.log('Line 340:', lines[339]);
console.log('Line 341:', lines[340]);
