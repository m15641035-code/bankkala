const fs = require('fs');
const content = fs.readFileSync('src/components/UserDashboardWidgets.tsx', 'utf8');
const lines = content.split('\n');

for (let i = 3; i < 10; i++) {
  if (lines[i] !== undefined) {
    console.log(`Line ${i + 1}: ${lines[i].substring(0, 500)}`);
  }
}
