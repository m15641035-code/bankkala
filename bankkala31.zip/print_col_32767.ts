import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

console.log('--- At Col 32767 ---');
console.log(line339.substring(32567, 32967));
