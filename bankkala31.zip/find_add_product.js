import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr = 'ADD PRODUCT TAB';
const idx = line339.indexOf(searchStr);
console.log('Index of ADD PRODUCT TAB:', idx);
if (idx !== -1) {
  console.log('Context around ADD PRODUCT TAB (200 chars):');
  console.log(line339.substring(idx - 100, idx + 100));
}
