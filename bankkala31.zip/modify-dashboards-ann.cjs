const fs = require('fs');

['src/components/supplier/SupplierDashboard.tsx', 'src/components/store-manager/StoreManagerDashboard.tsx'].forEach(file => {
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace("import React,", "import React, { useState } from 'react';\nimport Announcements from '../Announcements';\n//");
  
  // They both have a main content area. Let's find:
  // <div className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto">
  const mainRegex = /<div className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto bg-slate-50\/50">/;
  
  if (file.includes('supplier')) {
    code = code.replace(mainRegex, `<div className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto bg-slate-50/50">\n        <Announcements role="SUPPLIER" />`);
  } else {
    code = code.replace(mainRegex, `<div className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto bg-slate-50/50">\n        <Announcements role="STORE_MANAGER" />`);
  }
  
  fs.writeFileSync(file, code);
});
