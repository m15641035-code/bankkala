const fs = require('fs');
const content = fs.readFileSync('src/components/superadmin/Tickets.tsx', 'utf8');
const lines = content.split('\n');
console.log('Tickets.tsx total lines:', lines.length);
lines.forEach((line, idx) => {
  console.log(`Line ${idx + 1}: ${line.substring(0, 150)}`);
});
