import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const idx = line339.indexOf('/* WITHDRAWAL MODAL */');
console.log('Index:', idx);
console.log('Preceding 100 chars:');
console.log(JSON.stringify(line339.substring(idx - 100, idx)));
