import fs from 'fs';
import path from 'path';

const filesToProcess = [];

function getFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      getFiles(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts') || fullPath.endsWith('.js') || fullPath.endsWith('.cjs')) {
      filesToProcess.push(fullPath);
    }
  }
}

getFiles('./src');

const replacements = [
  // Indigo
  { regex: /bg-indigo-[456]00\/([0-9]+)/g, replace: 'bg-primary-default/$1' },
  { regex: /bg-indigo-[456]00/g, replace: 'bg-primary-default' },
  { regex: /text-indigo-[4567]00/g, replace: 'text-primary-default' },
  { regex: /text-indigo-[89]00/g, replace: 'text-primary-hover' },
  { regex: /border-indigo-[456]00\/([0-9]+)/g, replace: 'border-primary-default/$1' },
  { regex: /border-indigo-[456]00/g, replace: 'border-primary-default' },
  { regex: /ring-indigo-[456]00\/([0-9]+)/g, replace: 'ring-primary-default/$1' },
  { regex: /ring-indigo-[456]00/g, replace: 'ring-primary-default' },
  { regex: /shadow-indigo-[456]00\/([0-9]+)/g, replace: 'shadow-primary-default/$1' },
  
  // Emerald
  { regex: /bg-emerald-[456]00\/([0-9]+)/g, replace: 'bg-success/$1' },
  { regex: /bg-emerald-[456]00/g, replace: 'bg-success' },
  { regex: /text-emerald-[4567]00/g, replace: 'text-success' },
  { regex: /border-emerald-[456]00\/([0-9]+)/g, replace: 'border-success/$1' },
  { regex: /border-emerald-[456]00/g, replace: 'border-success' },
  { regex: /ring-emerald-[456]00\/([0-9]+)/g, replace: 'ring-success/$1' },
  { regex: /ring-emerald-[456]00/g, replace: 'ring-success' },
  
  // Amber / Orange
  { regex: /bg-(amber|orange)-[456]00\/([0-9]+)/g, replace: 'bg-warning/$2' },
  { regex: /bg-(amber|orange)-[456]00/g, replace: 'bg-warning' },
  { regex: /text-(amber|orange)-[4567]00/g, replace: 'text-warning' },
  { regex: /border-(amber|orange)-[456]00\/([0-9]+)/g, replace: 'border-warning/$2' },
  { regex: /border-(amber|orange)-[456]00/g, replace: 'border-warning' },
  
  // Rose / Red
  { regex: /bg-(rose|red)-[456]00\/([0-9]+)/g, replace: 'bg-danger/$2' },
  { regex: /bg-(rose|red)-[456]00/g, replace: 'bg-danger' },
  { regex: /text-(rose|red)-[4567]00/g, replace: 'text-danger' },
  { regex: /border-(rose|red)-[456]00\/([0-9]+)/g, replace: 'border-danger/$2' },
  { regex: /border-(rose|red)-[456]00/g, replace: 'border-danger' },

  // Background and Cards (Slate / Blue)
  { regex: /bg-(slate|gray|zinc)-9[05]0/g, replace: 'bg-background' },
  { regex: /bg-(slate|gray|zinc)-800/g, replace: 'bg-card' },
  { regex: /bg-(slate|gray|zinc)-50/g, replace: 'bg-background' },
  { regex: /bg-blue-50/g, replace: 'bg-surface' },
  { regex: /bg-(slate|gray|zinc)-100/g, replace: 'bg-surface' },
  { regex: /bg-(slate|gray|zinc)-200/g, replace: 'bg-surface' },
  { regex: /border-(slate|gray|zinc)-[23]00/g, replace: 'border-border-default' },
  { regex: /border-(slate|gray|zinc)-[78]00/g, replace: 'border-border-subtle' },
  
  // Text colors
  { regex: /text-(slate|gray|zinc)-[789]00/g, replace: 'text-text-primary' },
  { regex: /text-(slate|gray|zinc)-[56]00/g, replace: 'text-text-muted' },
  { regex: /text-(slate|gray|zinc)-[34]00/g, replace: 'text-text-muted' },
  { regex: /text-(slate|gray|zinc)-[12]00/g, replace: 'text-text-primary' },
  { regex: /text-(slate|gray|zinc)-50/g, replace: 'text-text-primary' },
];

for (const file of filesToProcess) {
  let content = fs.readFileSync(file, 'utf8');
  let original = content;
  
  for (const { regex, replace } of replacements) {
    content = content.replace(regex, replace);
  }
  
  if (content !== original) {
    fs.writeFileSync(file, content);
    console.log(`Updated ${file}`);
  }
}
