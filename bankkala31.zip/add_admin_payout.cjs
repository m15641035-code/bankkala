const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

const adminEndpoint = `
// Review/Force-Update payout status (Super Admin Only)
app.put('/api/admin/payouts/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const payoutId = req.params.id;
    const { status } = req.body; // e.g. 'SUCCESS' or 'FAILED'
    
    if (!['SUCCESS', 'FAILED'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const payoutRequest = await prisma.payoutRequest.findUnique({ where: { id: payoutId } });
    if (!payoutRequest) {
      return res.status(404).json({ error: 'Payout request not found' });
    }
    
    // Check if it's already in final state
    if (payoutRequest.status === 'SUCCESS' || payoutRequest.status === 'FAILED') {
      return res.status(400).json({ error: 'Payout is already in a final state' });
    }

    await prisma.$transaction(async (tx) => {
      // Update payout status
      await tx.payoutRequest.update({
        where: { id: payoutId },
        data: { status }
      });

      // Update associated ledger entry
      await tx.ledgerEntry.updateMany({
        where: { referenceId: payoutId, type: 'WITHDRAWAL' },
        data: { status: status === 'SUCCESS' ? 'COMPLETED' : 'FAILED' }
      });

      // If failed, return funds to wallet
      if (status === 'FAILED') {
        await tx.wallet.update({
          where: { id: payoutRequest.walletId },
          data: {
            balance: {
              increment: payoutRequest.amount
            }
          }
        });
      }
    });

    res.json({ success: true, message: \`Payout status updated to \${status}\` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
`;

code = code.replace("app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req: any, res: any) => {", adminEndpoint + "\napp.get('/api/admin/stats', authenticateToken, requireAdmin, async (req: any, res: any) => {");

fs.writeFileSync('server.ts', code);
