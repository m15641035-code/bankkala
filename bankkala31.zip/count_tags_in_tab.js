import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const searchStr = 'PRODUCTS TAB';
const idx = line339.indexOf(searchStr);
const endIdx = line339.indexOf('ORDERS TAB');

const productsTabContent = line339.substring(idx, endIdx);

// Let's count open <div> and close </div>
const openDivs = (productsTabContent.match(/<div/g) || []).length;
const closeDivs = (productsTabContent.match(/<\/div>/g) || []).length;

console.log('Open divs count:', openDivs);
console.log('Close divs count:', closeDivs);

// Let's look at the exact end of the PRODUCTS TAB
const lastChars = productsTabContent.substring(productsTabContent.length - 200);
console.log('End of PRODUCTS TAB context:', lastChars);
