const fs = require('fs');
let code = fs.readFileSync('src/components/store-manager/StoreManagerDashboard.tsx', 'utf8');

const targetImports = `import StoreConnection from './StoreConnection';`;
const newImports = `import StoreConnection from './StoreConnection';
import { StoreManagerProfile } from './StoreManagerProfile';`;

code = code.replace(targetImports, newImports);

const targetNavItems = `  const navItems = [
    { id: 'overview', label: 'پیشخوان', icon: LayoutDashboard },
    { id: 'orders', label: 'سفارشات من', icon: ShoppingBag },
    { id: 'marketplace', label: 'بازارچه کالا', icon: Package },
    { id: 'my_catalog', label: 'بانک کالای من', icon: Store },
    { id: 'settlements', label: 'امور مالی', icon: CreditCard },
    { id: 'invoices', label: 'صورت‌حساب‌ها', icon: FileText },
    { id: 'settings', label: 'تنظیمات اتصال', icon: Settings }
  ];`;
  
const newNavItems = `  const navItems = [
    { id: 'overview', label: 'پیشخوان', icon: LayoutDashboard },
    { id: 'orders', label: 'سفارشات من', icon: ShoppingBag },
    { id: 'marketplace', label: 'بازارچه کالا', icon: Package },
    { id: 'my_catalog', label: 'بانک کالای من', icon: Store },
    { id: 'settlements', label: 'امور مالی', icon: CreditCard },
    { id: 'invoices', label: 'صورت‌حساب‌ها', icon: FileText },
    { id: 'profile', label: 'ویرایش مشخصات', icon: User },
    { id: 'settings', label: 'تنظیمات اتصال', icon: Settings }
  ];`;
code = code.replace(targetNavItems, newNavItems);

const targetTabs = `{activeTab === 'settings' && (<StoreConnection />)}`;
const newTabs = `{activeTab === 'settings' && (<StoreConnection />)}
              {activeTab === 'profile' && (<StoreManagerProfile user={user} showNotification={showNotification} />)}`;
code = code.replace(targetTabs, newTabs);

fs.writeFileSync('src/components/store-manager/StoreManagerDashboard.tsx', code);
