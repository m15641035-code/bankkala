const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

const imports = `
import { FinancialJobs } from './src/services/financial/Jobs.js';
`;
code = code.replace("import { PaymentLifecycleService } from './src/services/financial/PaymentLifecycleService.js';", imports + "import { PaymentLifecycleService } from './src/services/financial/PaymentLifecycleService.js';");

code = code.replace("  NotificationService.init();", "  NotificationService.init();\n  FinancialJobs.start();");
fs.writeFileSync('server.ts', code);
