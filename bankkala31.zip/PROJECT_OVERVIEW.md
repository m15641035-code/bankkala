# Project Overview

## What is this?
A comprehensive B2B marketplace platform for managing inventory, orders, and financial transactions between suppliers and retail store managers.

## Users
- **SuperAdmin**: System oversight and management.
- **Supplier**: Manages products, handles orders, requests settlements.
- **StoreManager**: Manages inventory, places orders, handles invoices/payments.

## Problem Solved
Simplifies B2B trading by digitizing product catalogs, streamlining order processing, and automating settlement/financial flows between businesses.
