import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const pStack = [];
const cStack = [];

let inString = false;
let stringChar = '';
let inComment = false;
let inLineComment = false;
let currentLine = 1;

for (let i = 0; i < content.length; i++) {
  const char = content[i];
  if (char === '\n') {
    currentLine++;
  }

  if (inComment) {
    if (char === '*' && content[i + 1] === '/') {
      inComment = false;
      i++;
    }
    continue;
  }

  if (inLineComment) {
    if (char === '\n') {
      inLineComment = false;
    }
    continue;
  }

  if (inString) {
    if (char === stringChar && content[i - 1] !== '\\') {
      inString = false;
    }
    continue;
  }

  if (char === '/' && content[i + 1] === '*') {
    inComment = true;
    i++;
    continue;
  }
  if (char === '/' && content[i + 1] === '/') {
    inLineComment = true;
    i++;
    continue;
  }

  if (char === '"' || char === "'" || char === '`') {
    inString = true;
    stringChar = char;
    continue;
  }

  if (char === '(') {
    pStack.push({ line: currentLine, index: i, text: content.substring(i, i + 30).replace(/\n/g, ' ') });
  } else if (char === ')') {
    if (pStack.length > 0) pStack.pop();
  }

  if (char === '{') {
    cStack.push({ line: currentLine, index: i, text: content.substring(i, i + 30).replace(/\n/g, ' ') });
  } else if (char === '}') {
    if (cStack.length > 0) cStack.pop();
  }
}

console.log('=== UNCLOSED CURLY BRACES ===');
cStack.forEach((c, idx) => {
  console.log(`${idx + 1}. Line ${c.line} (char ${c.index}): ${c.text}`);
});

console.log('\n=== UNCLOSED PARENTHESES ===');
pStack.forEach((p, idx) => {
  console.log(`${idx + 1}. Line ${p.line} (char ${p.index}): ${p.text}`);
});
