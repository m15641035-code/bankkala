const fs = require('fs');
let code = fs.readFileSync('src/components/superadmin/SuperAdminDashboard.tsx', 'utf8');

// Add import
code = code.replace("import FinancialReports from './FinancialReports';", "import FinancialReports from './FinancialReports';\nimport AdminAnnouncements from './AdminAnnouncements';");

// Add to menu
const menuRegex = /\{ id: 'settings', label: 'تنظیمات سامانه', icon: Settings \}/;
code = code.replace(menuRegex, "{ id: 'messages', label: 'پیام‌ها و اطلاع‌رسانی', icon: Megaphone },\n    { id: 'settings', label: 'تنظیمات سامانه', icon: Settings }");

// Render logic
const renderRegex = /if \(activeTab === 'settings'\) \{/;
code = code.replace(renderRegex, "if (activeTab === 'messages') {\n      return <AdminAnnouncements />;\n    }\n    if (activeTab === 'settings') {");

fs.writeFileSync('src/components/superadmin/SuperAdminDashboard.tsx', code);
