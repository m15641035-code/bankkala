import ts from 'typescript';
import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const sourceFile = ts.createSourceFile(
  filePath,
  content,
  ts.ScriptTarget.Latest,
  true
);

const diagnostics = (sourceFile as any).parseDiagnostics || [];

console.log(`Found ${diagnostics.length} parsing diagnostics:`);
diagnostics.forEach((diag, idx) => {
  const { line, character } = ts.getLineAndCharacterOfPosition(sourceFile, diag.start);
  console.log(`${idx + 1}: Line ${line + 1}, Char ${character + 1} - Error ${diag.code}: ${ts.flattenDiagnosticMessageText(diag.messageText, '\n')}`);
});
