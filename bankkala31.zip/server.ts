import "dotenv/config";
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error("CRITICAL ERROR: JWT_SECRET environment variable is not set.");
  process.exit(1);
}import express from 'express';

const CATEGORIES = [
  'موبایل', 'لپ‌تاپ', 'کالای دیجیتال', 'خانه و آشپزخانه', 'لوازم خانگی برقی',
  'آرایشی و بهداشتی', 'مد و پوشاک', 'طلا و نقره', 'خودرو و موتورسیکلت',
  'سلامت و پزشکی', 'ابزارآلات و تجهیزات', 'کتاب و هنر', 'ورزش و سفر',
  'اسباب بازی کودک و نوزاد', 'محصولات بومی و محلی', 'پت شاپ'
];
import rateLimit from 'express-rate-limit';

declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

import dotenv from 'dotenv';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { execSync } from 'child_process';
import { NotificationService } from './src/services/NotificationService.js';
import { createServer as createViteServer } from 'vite';

import { z } from 'zod';

import { FinancialJobs } from './src/services/financial/Jobs.js';
import { PaymentLifecycleService } from './src/services/financial/PaymentLifecycleService.js';
import { PaymentServiceFactory } from './src/services/payment/PaymentServiceFactory.js';
import { mockPaymentStore } from './src/services/payment/MockZibalService.js';
import { initiatePaymentSchema, refundPaymentSchema, reportQuerySchema } from './src/validators/financial.js';
import registerConfig from './src/services/configRoute.js';
import registerAnnouncements from './src/services/announcementsRoute.js';
import registerOrderLabels from './src/services/orderLabelRoute.js';
import registerNewFeatures from './src/services/newFeaturesRoute.js';
import registerPenaltyRoutes from './src/services/penaltyRoute.js';


// Load environment variables
dotenv.config();

const rootDir = process.cwd();

// Security: Rate Limiters
const webhookLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 webhook requests per windowMs
  message: { error: 'Too many webhook requests from this IP, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const payoutRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // Limit each IP to 5 payout requests per hour
  message: { error: 'Too many payout requests, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});


// Ensure Prisma database file and directory exist
const dbDir = path.join(rootDir, 'prisma');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}
const dbPath = path.join(dbDir, 'dev.db');
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, '');
}
const dbUrl = `file:///${dbPath.replace(/^\//, '')}`;
process.env.DATABASE_URL = dbUrl;

try {
  console.log('Synchronizing database schema...');
  execSync('npx prisma db push --accept-data-loss', { 
    stdio: 'inherit', 
    env: { ...process.env, DATABASE_URL: dbUrl } 
  });
  console.log('Database synchronization completed.');
} catch (error) {
  console.error('Database synchronization failed:', error);
}

let prisma: any;
try {
  prisma = new PrismaClient({
    datasources: {
      db: {
        url: dbUrl
      }
    }
  });
} catch {
  console.warn('[AI Studio] Database not connected — using mock');
  const noOp: any = { 
    findMany: async () => [], 
    findFirst: async () => null,
    findUnique: async () => null, 
    create: async (d: any) => d?.data ?? {},
    update: async (d: any) => d?.data ?? {}, 
    delete: async () => ({}), 
    count: async () => 0, 
    aggregate: async () => ({ _sum: { totalAmount: 0 } }),
    updateMany: async () => ({ count: 0 }),
    deleteMany: async () => ({ count: 0 })
  };
  noOp.$transaction = async (cb: any) => {
    if (typeof cb === 'function') {
      return cb(new Proxy({}, { get: () => noOp }));
    }
    return [];
  };
  prisma = new Proxy({}, { get: (target, prop) => {
    if (prop === '$transaction') return noOp.$transaction;
    return noOp;
  }});
}
const app = express();
import cookieParser from 'cookie-parser';
app.use(cookieParser());

// Helper to retrieve centralized system configuration values dynamically from DB
async function getSystemConfig(key: string, defaultValue: any): Promise<any> {
  try {
    const config = await prisma.systemConfig.findUnique({
      where: { key }
    });
    if (!config) return defaultValue;
    if (config.value === "true") return true;
    if (config.value === "false") return false;
    const num = Number(config.value);
    if (!isNaN(num) && config.value.trim() !== "") return num;
    return config.value;
  } catch (err) {
    return defaultValue;
  }
}

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.get("/api/debug-cookie", (req, res) => res.json({ cookies: req.cookies }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));



// Validation helpers
app.get('/api/health', (req, res) => res.json({ status: "ok" }));

// Public Messages for Landing Page
app.get('/api/public-messages', async (req, res) => {
  res.json([
    { id: 1, text: "به پلتفرم B2B ما خوش آمدید!", type: "info" },
    { id: 2, text: "ثبت‌نام برای تامین‌کنندگان با تخفیف ویژه", type: "success" }
  ]);
});


registerConfig(app);
registerAnnouncements(app);
app.get("/api/test-route", (req, res) => res.json({ test: true }));
registerOrderLabels(app, prisma);
registerNewFeatures(app, prisma);
registerPenaltyRoutes(app, prisma);

const IRANIAN_MOBILE_REGEX = /^09\d{9}$/;
const USERNAME_REGEX = /^[a-zA-Z0-9_]+$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function getRequestBaseUrl(r: any): string {
  if (process.env.PUBLIC_URL) {
    return process.env.PUBLIC_URL.replace(/\/$/, '');
  }
  const xForwardedHost = r.get('X-Forwarded-Host');
  if (xForwardedHost) {
    return `https://${xForwardedHost}`;
  }
  const h = r.get('host') || '';
  if (h && !h.includes('localhost') && !h.includes('127.0.0.1') && !h.includes('3000')) {
    return `https://${h}`;
  }
  return 'https://ais-dev-ske3r4fg6inzq3htdfdegv-388525082645.us-east5.run.app';
}

// Shaba (IBAN) mathematical validation
function formatAndValidateShaba(input: string): { isValid: boolean; formatted?: string; error?: string } {
  // Remove spaces and dashes
  let clean = input.toUpperCase().replace(/[\s-]/g, '');
  
  // If user entered IR, we process it. Otherwise, add IR.
  if (!clean.startsWith('IR')) {
    clean = 'IR' + clean;
  }
  
  const numericPart = clean.substring(2);
  
  if (numericPart.length !== 24 || !/^\d{24}$/.test(numericPart)) {
    return { isValid: false, error: 'شماره شبا باید دقیقاً شامل ۲۴ رقم عددی باشد.' };
  }
  
  return { isValid: true, formatted: clean };
}

// Seed Super Admin on startup
async function seedSuperAdmin() {
  try {
    const existingAdmin = await prisma.user.findFirst({
      where: { role: 'SUPER_ADMIN' }
    });
    
    if (!existingAdmin) {
      const adminUser = process.env.SUPER_ADMIN_USERNAME || 'admin';
      const adminPass = process.env.SUPER_ADMIN_PASSWORD || 'Bahankala@2026!';
      const hashedPassword = await bcrypt.hash(adminPass, 10);
      await prisma.user.create({
        data: {
          username: adminUser,
          email: 'admin@marketplace.com',
          password: hashedPassword,
          role: 'SUPER_ADMIN',
          status: 'ACTIVE',
          firstName: 'مدیر',
          lastName: 'ارشد',
          mobile: '09120000000'
        }
      });
      console.log('✅ Super Admin created successfully!');
    }

    // Seed default Supplier
    const existingSupplier = await prisma.user.findFirst({
      where: { role: 'SUPPLIER', username: 'supplier' }
    });
    if (!existingSupplier) {
      const supplierPass = 'Bahankala@2026!';
      const hashedSupplierPassword = await bcrypt.hash(supplierPass, 10);
      await prisma.user.create({
        data: {
          username: 'supplier',
          email: 'supplier@marketplace.com',
          password: hashedSupplierPassword,
          role: 'SUPPLIER',
          status: 'ACTIVE',
          firstName: 'تامین‌کننده',
          lastName: 'نمونه',
          mobile: '09121111111',
          brandName: 'برند آریا کالا',
          shaba: 'IR123456789012345678901234',
          agreementAccepted: true,
          agreementVersion: '1.0',
          agreementAcceptedAt: new Date(),
          performanceScore: 100,
          penaltyPoints: 0,
          warningLevel: 'NONE'
        }
      });
      console.log('✅ Default Supplier created successfully!');
    }

    // Seed default Store Manager
    const existingStore = await prisma.user.findFirst({
      where: { role: 'STORE_MANAGER', username: 'store' }
    });
    if (!existingStore) {
      const storePass = 'Bahankala@2026!';
      const hashedStorePassword = await bcrypt.hash(storePass, 10);
      await prisma.user.create({
        data: {
          username: 'store',
          email: 'store@marketplace.com',
          password: hashedStorePassword,
          role: 'STORE_MANAGER',
          status: 'ACTIVE',
          firstName: 'مدیر',
          lastName: 'فروشگاه',
          mobile: '09122222222',
          storeName: 'فروشگاه توسعه کالا',
          platformType: 'WOOCOMMERCE'
        }
      });
      console.log('✅ Default Store Manager created successfully!');
    }

    // Seed default Info Pages for announcements
    const infoPageCount = await prisma.infoPage.count();
    if (infoPageCount === 0) {
      await prisma.infoPage.createMany({
        data: [
          {
            title: 'راهنمای ثبت و ویرایش محصولات در پنل تامین‌کنندگان',
            slug: 'product-registration-guide',
            category: 'آموزش',
            summary: 'تامین‌کنندگان گرامی، جهت افزایش چشمگیر فروش خود، لطفا کالاها را با توضیحات کامل، قیمت رقابتی و تصاویر باکیفیت ثبت کنید.',
            content: 'تامین‌کنندگان گرامی، جهت افزایش چشمگیر فروش خود در پلتفرم بانک کالا، لطفا کالاها را با توضیحات کامل، مشخصات دقیق، قیمت رقابتی و تصاویر باکیفیت بارگذاری کنید. کلیه محصولات بلافاصله توسط ناظر بررسی و تایید خواهند شد.',
            author: 'پشتیبانی سیستم',
            isPublished: true,
            isPinned: true
          },
          {
            title: 'برگزاری جشنواره تخفیف پاییزی زنجیره تامین کالا',
            slug: 'seasonal-discount-festival',
            category: 'اطلاعیه',
            summary: 'جشنواره بزرگ تخفیف پاییزه بانک کالا آغاز شد. از تخفیف‌های پورسانت ویژه و ترافیک بالای فروشگاه‌ها بهره‌مند شوید.',
            content: 'جشنواره بزرگ تخفیف پاییزه بانک کالا آغاز شد. از تخفیف‌های پورسانت ویژه و ترافیک بالای فروشگاه‌ها بهره‌مند شوید. تامین‌کنندگانی که بیشترین تخفیف‌ها را ثبت کنند در صفحه اول پنل خریداران پین خواهند شد.',
            author: 'واحد بازرگانی',
            isPublished: true,
            isPinned: false
          }
        ]
      });
      console.log('✅ Default InfoPages seeded!');
    }

    // Seed default Public Messages for the login page
    const publicMsgCount = await prisma.publicMessage.count();
    if (publicMsgCount === 0) {
      await prisma.publicMessage.create({
        data: {
          content: 'به نسخه جدید پلتفرم هوشمند بانک کالا خوش آمدید. تغییرات اساسی در رابط کاربری جهت بهبود خوانایی و دسترسی‌پذیری اعمال شده است.',
          icon: 'info',
          color: 'indigo',
          isActive: true
        }
      });
      console.log('✅ Default PublicMessage seeded!');
    }
  } catch (error) {
    console.error('Error seeding Super Admin:', error);
  }
}

// Routes
// 1. Register Supplier (تامین کننده)
app.post('/api/auth/register/supplier', async (req, res) => {
  try {
    const {
      username,
      password,
      firstName,
      lastName,
      mobile,
      email,
      nationalCode,
      brandName,
      activityType,
      address,
      province,
      city,
      postalCode,
      telephone,
      website,
      accountHolderName,
      shaba,
      bankName,
      agreementAccepted,
      agreementVersion,
      agreementAcceptedAt,
      referralCode
    } = req.body;

    // Field Validations
    if (!username || !password || !firstName || !lastName || !mobile) {
      return res.status(400).json({ error: 'لطفاً فیلدهای اجباری (نام، نام خانوادگی، موبایل، نام کاربری و رمز عبور) را وارد کنید.' });
    }

    if (!USERNAME_REGEX.test(username)) {
      return res.status(400).json({ error: 'نام کاربری فقط میتواند شامل حروف انگلیسی، اعداد و خط تیره (_) باشد.' });
    }

    if (!IRANIAN_MOBILE_REGEX.test(mobile)) {
      return res.status(400).json({ error: 'شماره موبایل وارد شده معتبر نیست. باید با 09 شروع شده و ۱۱ رقم باشد.' });
    }

    if (email && !EMAIL_REGEX.test(email)) {
      return res.status(400).json({ error: 'آدرس ایمیل وارد شده معتبر نیست.' });
    }

    const shabaValidation = formatAndValidateShaba(shaba || '');
    if (!shabaValidation.isValid) {
      return res.status(400).json({ error: shabaValidation.error });
    }
    const finalShaba = shabaValidation.formatted;

    if (!agreementAccepted) {
      return res.status(400).json({ error: 'پذیرش قوانین و مقررات الزامی است.' });
    }

    // Check unique username
    const existingUser = await prisma.user.findUnique({ where: { username } });
    if (existingUser) {
      return res.status(400).json({ error: 'این نام کاربری قبلاً در سیستم ثبت شده است.' });
    }

    let referrerUser = null;
    if (referralCode) {
      referrerUser = await prisma.user.findUnique({
        where: { referralCode }
      });
      if (!referrerUser || referrerUser.role !== 'REFERRER') {
        return res.status(400).json({ error: 'کد معرف وارد شده معتبر نیست یا معرف فعال نیست.' });
      }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const autoVerify = await getSystemConfig('SUPPLIER_AUTO_VERIFY', false);
    const initialStatus = (autoVerify === 'true' || autoVerify === true) ? 'ACTIVE' : 'ACTIVE_NEW';

    // Save to DB
    const user = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        role: 'SUPPLIER',
        status: initialStatus,
        firstName,
        lastName,
        mobile,
        email: email || null,
        nationalCode,
        brandName,
        activityType,
        address,
        province,
        city,
        postalCode,
        telephone,
        website,
        accountHolderName,
        shaba: finalShaba,
        bankName,
        agreementAccepted,
        agreementVersion,
        agreementAcceptedAt: agreementAcceptedAt ? new Date(agreementAcceptedAt) : new Date()
      }
    });

    if (referrerUser) {
      await prisma.referrerReferral.create({
        data: {
          referrerId: referrerUser.id,
          supplierId: user.id
        }
      });
    }

    // Issue JWT
    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role, status: user.status },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password: _, ...userWithoutPassword } = user;
    return res.status(201).json({
      message: 'ثبتنام تامینکننده با موفقیت انجام شد.',
      token,
      user: userWithoutPassword
    });

  } catch (error: any) {
    console.error('Error in supplier registration:', error);
    return res.status(500).json({ error: error.message || 'خطایی در ثبتنام رخ داد. لطفاً مجدداً تلاش کنید.' });
  }
});

// 1.5 Register Referrer (معرف)
app.post('/api/auth/register-referrer', async (req, res) => {
  try {
    const { username, password, firstName, lastName, mobile, email } = req.body;

    if (!username || !password || !firstName || !lastName || !mobile) {
      return res.status(400).json({ error: 'لطفاً فیلدهای اجباری (نام، نام خانوادگی، موبایل، نام کاربری و رمز عبور) را وارد کنید.' });
    }

    if (!USERNAME_REGEX.test(username)) {
      return res.status(400).json({ error: 'نام کاربری فقط میتواند شامل حروف انگلیسی، اعداد و خط تیره (_) باشد.' });
    }

    if (!IRANIAN_MOBILE_REGEX.test(mobile)) {
      return res.status(400).json({ error: 'شماره موبایل وارد شده معتبر نیست. باید با 09 شروع شده و ۱۱ رقم باشد.' });
    }

    const existingUser = await prisma.user.findUnique({ where: { username } });
    if (existingUser) {
      return res.status(400).json({ error: 'این نام کاربری قبلاً در سیستم ثبت شده است.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const randomStr = Math.random().toString(36).substring(2, 8).toUpperCase();
    const generatedReferralCode = `REF-${randomStr}`;

    const user = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        role: 'REFERRER',
        status: 'ACTIVE',
        firstName,
        lastName,
        mobile,
        email: email || null,
        referralCode: generatedReferralCode
      }
    });

    // Create wallet for Referrer
    await prisma.wallet.create({
      data: {
        supplierId: user.id,
        balance: 0.0
      }
    });

    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role, status: user.status },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password: _, ...userWithoutPassword } = user;
    return res.status(201).json({
      message: 'ثبت‌نام معرف با موفقیت انجام شد.',
      token,
      user: userWithoutPassword
    });

  } catch (error: any) {
    console.error('Error in referrer registration:', error);
    return res.status(500).json({ error: error.message || 'خطایی در ثبت‌نام رخ داد. لطفاً مجدداً تلاش کنید.' });
  }
});

// 2. Register Store Manager (مدیر فروشگاه)
app.post('/api/auth/register/store-manager', async (req, res) => {
  try {
    const {
      username,
      password,
      firstName,
      lastName,
      mobile,
      email,
      storeName,
      storeUrl,
      platformType,
      fieldOfActivity,
      productCount,
      storeAddress,
      address
    } = req.body;

    // Field Validations
    if (!username || !password || !firstName || !lastName || !mobile || !storeName) {
      return res.status(400).json({ error: 'لطفاً فیلدهای اجباری (نام، نام خانوادگی، موبایل، نام فروشگاه، نام کاربری و رمز عبور) را وارد کنید.' });
    }

    if (!USERNAME_REGEX.test(username)) {
      return res.status(400).json({ error: 'نام کاربری فقط میتواند شامل حروف انگلیسی، اعداد و خط تیره (_) باشد.' });
    }

    if (!IRANIAN_MOBILE_REGEX.test(mobile)) {
      return res.status(400).json({ error: 'شماره موبایل وارد شده معتبر نیست. باید با 09 شروع شده و ۱۱ رقم باشد.' });
    }

    if (email && !EMAIL_REGEX.test(email)) {
      return res.status(400).json({ error: 'آدرس ایمیل وارد شده معتبر نیست.' });
    }

    // Check unique username
    const existingUser = await prisma.user.findUnique({ where: { username } });
    if (existingUser) {
      return res.status(400).json({ error: 'این نام کاربری قبلاً در سیستم ثبت شده است.' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save to DB
    const user = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        role: 'STORE_MANAGER',
        firstName,
        lastName,
        mobile,
        email: email || null,
        storeName,
        storeUrl,
        platformType,
        fieldOfActivity,
        productCount: productCount ? parseInt(productCount) : null,
        address: storeAddress || address || null
      }
    });

    // Issue JWT
    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password: _, ...userWithoutPassword } = user;
    return res.status(201).json({
      message: 'ثبتنام مدیر فروشگاه با موفقیت انجام شد.',
      token,
      user: userWithoutPassword
    });

  } catch (error: any) {
    console.error('Error in store manager registration:', error);
    return res.status(500).json({ error: 'خطایی در ثبتنام رخ داد. لطفاً مجدداً تلاش کنید.' });
  }
});

// 3. Login Endpoint
app.post('/api/auth/logout', (req: any, res: any) => {
  res.clearCookie('token');
  res.json({ success: true });
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'لطفاً نام کاربری و کلمه عبور را وارد کنید.' });
      

    }

    const user = await prisma.user.findUnique({ where: { username } });
    if (!user) {
      return res.status(401).json({ error: 'نام کاربری یا کلمه عبور نادرست است.' });
    }

    // Verify Password
    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: 'نام کاربری یا کلمه عبور نادرست است.' });
    }

    // Check Supplier status if Supplier
    if (user.role === 'SUPPLIER' && user.status === 'BLOCKED') {
      return res.status(403).json({ error: 'حساب کاربری شما مسدود شده است. لطفا با پشتیبانی تماس بگیرید.' });
    }

    // Issue JWT
    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role, status: user.status },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password: _, ...userWithoutPassword } = user;
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 24 * 60 * 60 * 1000 });
    return res.json({
      message: 'ورود با موفقیت انجام شد.',
      token,
      user: userWithoutPassword
    });

  } catch (error: any) {
    console.error('Error in login:', error);
    return res.status(500).json({ error: 'خطایی در ورود رخ داد. لطفاً مجدداً تلاش کنید.' });
  }
});

// --- Auth Middleware ---
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const headerToken = authHeader && authHeader.split(' ')[1];
  const token = req.cookies?.token || headerToken;
  
  if (!token) return res.status(401).json({ error: 'عدم دسترسی' });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ error: 'توکن نامعتبر است' });
    req.user = user;
    next();
  });
};

const requireSupplier = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'SUPPLIER') {
    return res.status(403).json({ error: 'فقط تامینکنندگان دسترسی دارند' });
  }
  next();
};

const requireReferrer = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'REFERRER') {
    return res.status(403).json({ error: 'دسترسی فقط برای معرف‌ها مجاز است' });
  }
  next();
};

// --- Referrer API Routes ---
app.get('/api/referrer/stats', authenticateToken, requireReferrer, async (req: any, res) => {
  try {
    const referrerId = parseInt(req.user.userId);

    const user = await prisma.user.findUnique({
      where: { id: referrerId },
      include: { wallet: true }
    });

    if (!user) {
      return res.status(404).json({ error: 'کاربر یافت نشد.' });
    }

    // Find referred suppliers
    const referrals = await prisma.referrerReferral.findMany({
      where: { referrerId },
      include: {
        supplier: {
          select: {
            id: true,
            username: true,
            firstName: true,
            lastName: true,
            brandName: true,
            status: true,
          }
        }
      }
    });

    const referredSuppliers = referrals.map(r => ({
      ...r.supplier,
      createdAt: r.createdAt
    }));

    // Calculate stats
    const totalReferred = referredSuppliers.length;
    const activeSuppliersCount = referredSuppliers.filter(s => s.status === 'ACTIVE').length;
    const pendingSuppliersCount = referredSuppliers.filter(s => s.status === 'ACTIVE_NEW' || s.status === 'UNDER_REVIEW').length;

    return res.json({
      referrerCode: user.referralCode,
      wallet: user.wallet || { balance: 0 },
      referredSuppliers,
      stats: {
        totalReferred,
        activeSuppliersCount,
        pendingSuppliersCount,
      }
    });
  } catch (error: any) {
    console.error('Error in referrer stats:', error);
    return res.status(500).json({ error: 'خطایی در دریافت اطلاعات رخ داد.' });
  }
});

// --- Supplier API Routes ---
// Get products for the logged in supplier
app.get('/api/supplier/products', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const products = await prisma.product.findMany({
      where: { supplierId: req.user.userId },
      include: { category: true, images: true, variants: true },
      orderBy: { id: 'desc' }
    });
    res.json(products);
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در دریافت محصولات' });
  }
});

// Add a new product
app.post('/api/supplier/products', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const { categoryId, name, shortDescription, longDescription, supplierBasePrice, discount, sku, brand, stock, images, mainImage, variants } = req.body;
    
    let actualCategoryId = parseInt(categoryId);
    if (actualCategoryId) {
      const categoryExists = await prisma.category.findUnique({ where: { id: actualCategoryId } });
      if (!categoryExists) {
        await prisma.category.create({
          data: { id: actualCategoryId, name: CATEGORIES[actualCategoryId - 1] || ('دسته‌بندی ' + actualCategoryId), isActive: true, sortOrder: 0 }
        });
      }
    } else {
      const firstCategory = await prisma.category.findFirst();
      if (firstCategory) {
        actualCategoryId = firstCategory.id;
      } else {
        const newCategory = await prisma.category.create({
          data: { name: 'عمومی', isActive: true, sortOrder: 0 }
        });
        actualCategoryId = newCategory.id;
      }
    }

    const product = await prisma.product.create({
      data: {
        supplierId: parseInt(req.user.userId),
        categoryId: actualCategoryId,
        name,
        shortDescription,
        longDescription,
        supplierBasePrice: parseFloat(supplierBasePrice),
        discount: parseFloat(discount) || 0,
        sku,
        brand,
        inventory: (stock !== undefined && stock !== '' && !isNaN(parseInt(stock))) ? parseInt(stock) : 100,
        status: 'PENDING_APPROVAL', // Start as pending
        images: {
          create: [
            ...(mainImage ? [{ url: mainImage }] : []),
            ...(images || []).map((url: string) => ({ url }))
          ]
        },
        variants: {
          create: (variants && variants.length > 0) ? variants.map((v: any) => ({
            attributes: JSON.stringify(v.attributes),
            supplierBasePrice: parseFloat(v.supplierBasePrice || supplierBasePrice),
            stock: parseInt(v.stock || 0),
            sku: v.sku || sku
          })) : [{
            attributes: JSON.stringify({}),
            supplierBasePrice: parseFloat(supplierBasePrice),
            stock: parseInt(stock || 0),
            sku: sku || ''
          }]
        }
      }
    });
    console.log('Product created:', product.id, 'for supplier:', req.user.userId);
    res.status(201).json({ message: 'محصول با موفقیت ثبت شد', product });
  } catch (err: any) {
    console.error('Error creating product:', err);
    res.status(500).json({ error: 'خطا در ثبت محصول', details: err.message });
  }
});

// Edit a product
app.put('/api/supplier/products/:id', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const { id } = req.params;
    const { categoryId, name, shortDescription, longDescription, supplierBasePrice, discount, sku, brand, stock, images, mainImage, variants } = req.body;
    
    // Ensure product belongs to supplier
    const existing = await prisma.product.findFirst({
      where: { id: parseInt(id), supplierId: req.user.userId }
    });
    if (!existing) return res.status(404).json({ error: 'محصول یافت نشد' });

    let actualCategoryId = parseInt(categoryId);
    if (actualCategoryId) {
      const categoryExists = await prisma.category.findUnique({ where: { id: actualCategoryId } });
      if (!categoryExists) {
        await prisma.category.create({
          data: { id: actualCategoryId, name: CATEGORIES[actualCategoryId - 1] || ('دسته‌بندی ' + actualCategoryId), isActive: true, sortOrder: 0 }
        });
      }
    } else {
      const firstCategory = await prisma.category.findFirst();
      actualCategoryId = firstCategory ? firstCategory.id : existing.categoryId;
    }

    // Determine if any specification other than stock has changed
    const hasSpecChanges = 
      name !== existing.name ||
      actualCategoryId !== existing.categoryId ||
      shortDescription !== existing.shortDescription ||
      longDescription !== existing.longDescription ||
      parseFloat(supplierBasePrice) !== existing.supplierBasePrice ||
      (discount !== undefined && parseFloat(discount) !== existing.discount) ||
      sku !== existing.sku ||
      brand !== existing.brand;

    const newStatus = hasSpecChanges ? 'INACTIVE' : existing.status;

    const product = await prisma.product.update({
      where: { id: parseInt(id) },
      data: {
        categoryId: actualCategoryId,
        name,
        shortDescription,
        longDescription,
        supplierBasePrice: parseFloat(supplierBasePrice),
        discount: parseFloat(discount) || 0,
        sku,
        brand,
        inventory: (stock !== undefined && stock !== '' && !isNaN(parseInt(stock))) ? parseInt(stock) : existing.inventory,
        minOrderQuantity: req.body.minOrderQuantity !== undefined ? parseInt(req.body.minOrderQuantity) : existing.minOrderQuantity,
        status: newStatus,
      }
    });
    
    // Process images if provided
    if (mainImage || (images && images.length > 0)) {
      await prisma.productImage.deleteMany({ where: { productId: parseInt(id) } });
      await prisma.productImage.createMany({
        data: [
          ...(mainImage ? [{ productId: parseInt(id), url: mainImage }] : []),
          ...(images || []).map((url: string) => ({ productId: parseInt(id), url }))
        ]
      });
    }

    res.json({ message: 'محصول با موفقیت ویرایش شد', product });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در ویرایش محصول', details: err.message });
  }
});

// Get orders containing this supplier's products
app.get('/api/supplier/orders', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const orderItems = await prisma.orderItem.findMany({
      where: { supplierId: req.user.userId, status: { not: 'CANCELLED' } },
      include: { 
        order: {
          include: {
            store: {
              select: {
                id: true,
                username: true,
                firstName: true,
                lastName: true,
                brandName: true,
                storeName: true
              }
            }
          }
        }, 
        product: true, 
        variant: true 
      }
    });
    res.json(orderItems);
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در دریافت سفارشات' });
  }
});

// Update order item status
app.patch('/api/supplier/orders/:itemId', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const { status, trackingCode } = req.body;
    const { itemId } = req.params;
    
    // Ensure item belongs to this supplier
    const item = await prisma.orderItem.findFirst({
      where: { id: parseInt(itemId), supplierId: req.user.userId }
    });

    if (!item) {
      return res.status(404).json({ error: 'سفارش یافت نشد' });
    }

    const updated = await prisma.orderItem.update({
      where: { id: item.id },
      data: { status, trackingCode }
    });
    
    // Also update order status
    await prisma.order.update({
      where: { id: item.orderId },
      data: { status }
    });
    
    res.json({ message: 'وضعیت سفارش به روز شد', updated });
  } catch (err: any) {
    res.status(500).json({ error: 'بروزرسانی سفارش با خطا مواجه شد' });
  }
});

// Get wallet balance and transactions


app.post('/api/supplier/payout/request', authenticateToken, requireSupplier, payoutRequestLimiter, async (req: any, res: any) => {
  try {
    const supplierId = req.user.userId;
    const { amount } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'مبلغ تسویه نامعتبر است' });
    }
    
    const user = await prisma.user.findUnique({ where: { id: supplierId } });
    if (!user || !user.shaba || !user.bankName || !user.accountHolderName) {
      return res.status(400).json({ error: 'لطفاً ابتدا اطلاعات حساب بانکی خود (شماره شبا، نام بانک و نام صاحب حساب) را در بخش پروفایل تکمیل کنید.' });
    }
    
    const wallet = await prisma.wallet.findUnique({ where: { supplierId } });
    if (!wallet) {
      return res.status(404).json({ error: 'کیف پول یافت نشد' });
    }
    
    // Import dynamically to avoid top-level issues if needed, or we can use WalletService directly
    const { WalletService } = await import('./src/services/WalletService.js');
    const walletService = new WalletService();
    
    const payoutRequest = await walletService.requestPayout(wallet.id, amount, user.shaba);
    
    res.json({ success: true, message: 'درخواست تسویه با موفقیت ثبت شد', payoutRequest });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/supplier/reports', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const supplierId = req.user.userId;
    const { status, type, page = '1', limit = '10' } = req.query;

    const wallet = await prisma.wallet.findUnique({
      where: { supplierId },
    });

    if (!wallet) {
      return res.status(404).json({ error: 'Wallet not found' });
    }

    // Calculate total earnings (ORDER_REVENUE, COMPLETED)
    const earningsResult = await prisma.ledgerEntry.aggregate({
      where: {
        walletId: wallet.id,
        type: 'ORDER_REVENUE',
        status: 'COMPLETED'
      },
      _sum: { amount: true }
    });

    // Calculate total withdrawn (WITHDRAWAL, COMPLETED)
    const withdrawnResult = await prisma.ledgerEntry.aggregate({
      where: {
        walletId: wallet.id,
        type: 'WITHDRAWAL',
        status: 'COMPLETED'
      },
      _sum: { amount: true }
    });

    // Sum all pending order item revenues for this supplier (where order is not PAID and order item is not cancelled/rejected)
    const pendingOrderItems = await prisma.orderItem.findMany({
      where: {
        supplierId,
        order: {
          status: { not: 'PAID' }
        },
        status: { notIn: ['CANCELLED', 'REJECTED'] }
      },
      select: {
        quantity: true,
        supplierPrice: true
      }
    });
    const pendingBalance = pendingOrderItems.reduce((acc, item) => acc + (item.quantity * item.supplierPrice), 0);

    // Fetch withdrawal requests (PayoutRequest)
    const payouts = await prisma.payoutRequest.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' }
    });

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    
    // Build filter for history
    const whereClause: any = { walletId: wallet.id };
    if (status) whereClause.status = status;
    if (type) whereClause.type = type;

    const history = await prisma.ledgerEntry.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      skip: (pageNum - 1) * limitNum,
      take: limitNum
    });

    const totalHistory = await prisma.ledgerEntry.count({ where: whereClause });

    res.json({
      balance: wallet.balance.toString(),
      pendingBalance: pendingBalance.toString(),
      totalEarnings: (earningsResult._sum.amount || 0).toString(),
      totalWithdrawn: Math.abs(parseFloat((withdrawnResult._sum.amount || 0).toString())).toString(),
      history,
      payouts,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalHistory,
        totalPages: Math.ceil(totalHistory / limitNum)
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/supplier/wallet', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const wallet = await prisma.wallet.findUnique({
      where: { supplierId: req.user.userId }
    });
    const transactions = wallet ? await prisma.ledgerEntry.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' }
    }) : [];
    res.json({ wallet, transactions });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در دریافت اطلاعات مالی' });
  }
});

app.get('/api/supplier/settlements/:id', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const supplierId = req.user.userId;

    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id },
      include: {
        wallet: true
      }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    if (payoutRequest.wallet.supplierId !== supplierId) {
      return res.status(403).json({ error: 'عدم دسترسی' });
    }

    // Retrieve LedgerEntries for this payout request (Wallet credits)
    const ledgerEntries = await prisma.ledgerEntry.findMany({
      where: {
        referenceId: payoutRequest.id,
        walletId: payoutRequest.walletId,
        type: 'ORDER_REVENUE'
      }
    });

    // Build breakdown
    const breakdown = [];
    for (const entry of ledgerEntries) {
      if (entry.orderItemId) {
        const orderItem = await prisma.orderItem.findUnique({
          where: { id: entry.orderItemId },
          include: {
            order: true,
            product: true
          }
        });

        if (orderItem) {
          breakdown.push({
            orderNumber: orderItem.order.id,
            orderDate: orderItem.order.createdAt,
            productName: orderItem.product.name,
            sku: orderItem.product.sku || 'N/A',
            quantity: orderItem.quantity,
            supplierRevenue: orderItem.supplierPrice * orderItem.quantity,
            walletCreditAmount: parseFloat(entry.amount.toString()),
            currentOrderStatus: orderItem.status
          });
        }
      }
    }

    res.json({
      success: true,
      settlement: {
        id: payoutRequest.id,
        amount: parseFloat(payoutRequest.amount.toString()),
        requestDate: payoutRequest.createdAt,
        status: payoutRequest.status,
        receiptUrl: payoutRequest.receiptUrl,
        transactionRef: payoutRequest.transactionRef,
        paymentDate: payoutRequest.paymentDate
      },
      breakdown
    });
  } catch (err: any) {
    console.error('Error fetching settlement detail:', err);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

// Update supplier profile


app.put('/api/supplier/profile', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    let { firstName, lastName, brandName, shaba, mobile, bankName, accountHolderName, address } = req.body;
    
    if (shaba) {
      shaba = shaba.toUpperCase().replace(/[\s-]/g, '');
      if (!shaba.startsWith('IR')) {
        shaba = 'IR' + shaba;
      }
    }

    const user = await prisma.user.update({
      where: { id: req.user.userId },
      data: { 
        firstName, 
        lastName, 
        brandName, 
        shaba, 
        mobile,
        bankName,
        accountHolderName,
        address
      }
    });
    res.json({ message: 'پروفایل با موفقیت بروزرسانی شد', user });
  } catch (err) {
    res.status(500).json({ error: 'خطا در بروزرسانی پروفایل' });
  }
});

// Get tickets
app.get('/api/supplier/tickets', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const tickets = await prisma.ticket.findMany({
      where: { userId: req.user.userId },
      include: { messages: true },
      orderBy: { createdAt: 'desc' }
    });
    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت تیکت‌ها' });
  }
});

// Create ticket
app.post('/api/supplier/tickets', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const { subject, department, priority, message } = req.body;
    const ticket = await prisma.ticket.create({
      data: {
        userId: req.user.userId,
        subject,
        department,
        priority,
        messages: {
          create: [{ userId: req.user.userId, message }]
        }
      }
    });
    res.status(201).json(ticket);
  } catch (err) {
    res.status(500).json({ error: 'خطا در ایجاد تیکت' });
  }
});

// Add message to ticket
app.post('/api/supplier/tickets/:id/messages', authenticateToken, requireSupplier, async (req: any, res) => {
  try {
    const { message } = req.body;
    const { id } = req.params;
    
    // Ensure ticket belongs to user
    const existing = await prisma.ticket.findFirst({
      where: { id: parseInt(id), userId: req.user.userId }
    });
    if (!existing) return res.status(404).json({ error: 'تیکت یافت نشد' });

    const ticketMsg = await prisma.ticketMessage.create({
      data: {
        ticketId: parseInt(id),
        userId: req.user.userId,
        message
      }
    });
    res.status(201).json(ticketMsg);
  } catch (err) {
    res.status(500).json({ error: 'خطا در ثبت پیام' });
  }
});

// --- Store Manager API Routes ---
const requireStoreManager = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'STORE_MANAGER') {
    return res.status(403).json({ error: 'دسترسی فقط برای مدیر فروشگاه مجاز است' });
  }
  next();
};

// Store Manager Tickets Endpoints
app.get('/api/store-manager/tickets', authenticateToken, requireStoreManager, async (req: any, res) => {
  try {
    const tickets = await prisma.ticket.findMany({
      where: { userId: req.user.userId },
      include: { 
        messages: {
          include: {
            user: { select: { firstName: true, lastName: true, role: true } }
          },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت تیکت‌ها' });
  }
});

app.post('/api/store-manager/tickets', authenticateToken, requireStoreManager, async (req: any, res) => {
  try {
    const { subject, department, priority, message } = req.body;
    const ticket = await prisma.ticket.create({
      data: {
        userId: req.user.userId,
        subject,
        department,
        priority,
        messages: {
          create: [{ userId: req.user.userId, message }]
        }
      }
    });
    res.status(201).json(ticket);
  } catch (err) {
    res.status(500).json({ error: 'خطا در ایجاد تیکت' });
  }
});

app.post('/api/store-manager/tickets/:id/messages', authenticateToken, requireStoreManager, async (req: any, res) => {
  try {
    const { message } = req.body;
    const { id } = req.params;
    
    const existing = await prisma.ticket.findFirst({
      where: { id: parseInt(id), userId: req.user.userId }
    });
    if (!existing) return res.status(404).json({ error: 'تیکت یافت نشد' });

    const ticketMsg = await prisma.ticketMessage.create({
      data: {
        ticketId: parseInt(id),
        userId: req.user.userId,
        message
      }
    });

    await prisma.ticket.update({
      where: { id: parseInt(id) },
      data: { status: 'OPEN', updatedAt: new Date() }
    });

    res.status(201).json(ticketMsg);
  } catch (err) {
    res.status(500).json({ error: 'خطا در ارسال پیام' });
  }
});

app.put('/api/store-manager/profile', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const userId = req.user.userId;
    const { firstName, lastName, mobile, shaba, address } = req.body;

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        firstName,
        lastName,
        mobile,
        shaba,
        address
      }
    });

    res.json(updatedUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در ویرایش مشخصات' });
  }
});

app.get('/api/store-manager/stats', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;

    const totalOrders = await prisma.order.count({ where: { storeId } });
    const paidInvoices = await prisma.storeInvoice.findMany({ where: { storeManagerId: storeId, status: 'PAID' } });
    const totalPaid = paidInvoices.reduce((acc, inv) => acc + inv.totalAmount, 0);

    // Get recently added items (mock)
    const recentActivity = await prisma.order.findMany({
      where: { storeId },
      orderBy: { createdAt: 'desc' },
      take: 5
    });

    res.json({ totalOrders, totalPaid, netProfit: totalPaid * 1.5, recentActivity });
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت آمار' });
  }
});


// Store Manager - Marketplace Catalog
app.get('/api/store-manager/marketplace-products', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const now = new Date();
    
    // Pagination params
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    // Filters
    const { search, category, minPrice, maxPrice } = req.query;

    const where: any = {
      status: { in: ['ACTIVE', 'PUBLISHED'] },
      
      OR: [
        { publishStartDate: null },
        { publishStartDate: { lte: now } }
      ],
      AND: [
        {
          OR: [
            { publishEndDate: null },
            { publishEndDate: { gte: now } }
          ]
        }
      ]
    };

    if (search) {
      where.AND.push({
        OR: [
          { name: { contains: search } },
          { shortDescription: { contains: search } },
          { category: { name: { contains: search } } }
        ]
      });
    }
    if (category) {
      where.category = { name: category };
    }

    const products = await prisma.product.findMany({
      where,
      include: {
        category: true,
        images: true,
        variants: true,
        supplier: {
          select: { brandName: true, firstName: true, lastName: true, city: true, province: true }
        }
      },
      orderBy: [
        { isPinned: 'desc' },
        { id: 'desc' }
      ],
      skip,
      take: limit
    });

    const total = await prisma.product.count({ where });

    const defaultCommission = await getSystemConfig("COMMISSION_PERCENTAGE", 10);

    // Exclude supplier details, calculate final price
    const sanitizedProducts = products.map((product: any) => {
      const supplierCity = product.supplier?.city 
        ? `${product.supplier.province ? product.supplier.province + '، ' : ''}${product.supplier.city}` 
        : 'تهران';
      let fPrice = product.finalPrice;
      if (!fPrice) {
        if (product.marginType === 'PERCENTAGE' && product.marginValue) {
          fPrice = product.supplierBasePrice * (1 + product.marginValue / 100);
        } else if (product.marginType === 'FIXED' && product.marginValue) {
          fPrice = product.supplierBasePrice + product.marginValue;
        } else {
          fPrice = product.supplierBasePrice * (1 + defaultCommission / 100);
        }
      }
      
      // SANITIZATION: drop supplier details completely
      const { supplierId, supplierBasePrice, marginType, marginValue, supplier, ...safeProduct } = product;
      
      return { ...safeProduct, supplierCity, finalPrice: fPrice };
    });

    // We need to only return those with calculated margin if rule says so:
    // "توسط مدیر کل حاشیه سود برایشان تعیین شده باشد"
    const validProducts = sanitizedProducts.filter(p => p.finalPrice !== undefined && p.finalPrice > 0);

    res.json({
      data: validProducts,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت محصولات' });
  }
});

// Add to My Catalog (بانک کالای من)
async function getStoreProductLimitStatus(storeId: number) {
  const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  // Count total selections ever made by this store
  const totalSelections = await prisma.storeProductSelection.count({
    where: { storeId }
  });

  if (totalSelections < 20) {
    return {
      limit: 20,
      current: totalSelections,
      isNewStore: true,
      reason: 'سهمیه اولیه بدون محدودیت زمانی (تا ۲۰ محصول)'
    };
  } else {
    const selectionsLast24h = await prisma.storeProductSelection.count({
      where: {
        storeId,
        selected_at: { gte: twentyFourHoursAgo }
      }
    });
    return {
      limit: 3,
      current: selectionsLast24h,
      isNewStore: false,
      reason: 'محدودیت ۲۴ ساعته بعد از اتمام سهمیه اولیه (حداکثر ۳ محصول در هر ۲۴ ساعت)'
    };
  }
}

app.post('/api/store-manager/my-catalog', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const { productId } = req.body;

    if (!productId) {
      return res.status(400).json({ error: 'Product ID is required.' });
    }

    // Check limit using new custom logic
    const limitStatus = await getStoreProductLimitStatus(storeId);
    if (limitStatus.current >= limitStatus.limit) {
      return res.status(400).json({ error: `شما به سقف مجاز انتخاب محصول (${limitStatus.limit} کالا) رسیده‌اید.` });
    }

    // Check if already selected
    const existing = await prisma.storeProductSelection.findFirst({
      where: { storeId, productId }
    });

    if (existing) {
      return res.status(400).json({ error: 'این محصول قبلاً به بانک کالای شما اضافه شده است.' });
    }

    const selection = await prisma.storeProductSelection.create({
      data: {
        storeId,
        productId,
        status: 'PENDING_SYNC'
      }
    });

    res.json({ message: 'محصول با موفقیت به بانک کالای شما اضافه شد.', selection });
  } catch (err) {
    res.status(500).json({ error: 'خطا در افزودن محصول به بانک کالا' });
  }
});

// Remove from My Catalog
app.delete('/api/store-manager/my-catalog/:productId', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const productId = parseInt(req.params.productId);

    await prisma.storeProductSelection.deleteMany({
      where: { storeId, productId }
    });

    res.json({ message: 'محصول از بانک کالای شما حذف شد.' });
  } catch (err) {
    res.status(500).json({ error: 'خطا در حذف محصول' });
  }
});

// Get My Catalog
app.get('/api/store-manager/my-catalog', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const selections = await prisma.storeProductSelection.findMany({
      where: { storeId },
      include: {
        product: {
          include: {
            category: true,
            images: true
          }
        }
      },
      orderBy: { selected_at: 'desc' }
    });

    // Sanitize product details inside selections
    const defaultCommission = await getSystemConfig("COMMISSION_PERCENTAGE", 10);
    const sanitizedSelections = selections.map(s => {
      const product = s.product;
      let fPrice = product.finalPrice;
      if (!fPrice) {
        if (product.marginType === 'PERCENTAGE' && product.marginValue) {
          fPrice = product.supplierBasePrice * (1 + product.marginValue / 100);
        } else if (product.marginType === 'FIXED' && product.marginValue) {
          fPrice = product.supplierBasePrice + product.marginValue;
        } else {
          fPrice = product.supplierBasePrice * (1 + defaultCommission / 100);
        }
      }
      const { supplierId, supplierBasePrice, marginType, marginValue, supplier, ...safeProduct } = product;
      return { ...s, product: { ...safeProduct, finalPrice: fPrice } };
    });

    res.json(sanitizedSelections);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت لیست محصولات' });
  }
});

// Check daily limit
app.get('/api/store-manager/daily-limit', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const limitStatus = await getStoreProductLimitStatus(storeId);
    res.json(limitStatus);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت وضعیت محدودیت' });
  }
});


app.get('/api/store-manager/orders', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const { status } = req.query; // unpaid or paid

    let whereClause: any = { storeId, status: { not: 'CANCELLED' } };
    if (status === 'unpaid') {
      whereClause.storeInvoiceId = null;
    } else if (status === 'paid') {
      whereClause.storeInvoiceId = { not: null };
    }

    const orders = await prisma.order.findMany({
      where: whereClause,
      include: {
        items: { include: { product: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت سفارشات' });
  }
});

app.get('/api/store-manager/wallet', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    let wallet = await prisma.wallet.findUnique({
      where: { supplierId: storeId },
      include: {
        ledgerEntries: {
          orderBy: { createdAt: 'desc' },
          take: 50
        }
      }
    });
    
    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: { supplierId: storeId, balance: 0 },
        include: { ledgerEntries: true }
      });
    }

    res.json({
      balance: wallet.balance,
      ledger: wallet.ledgerEntries
    });
  } catch (err: any) {
    console.error('Wallet fetch error:', err);
    res.status(500).json({ error: 'خطا در دریافت اطلاعات کیف پول' });
  }
});

app.post('/api/store-manager/settle-orders', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = parseInt(req.user.userId || req.user.id);
    const { orderIds, paymentMethod } = req.body;
    
    if (!orderIds || (Array.isArray(orderIds) && orderIds.length === 0)) {
      return res.status(400).json({ error: 'سفارشی انتخاب نشده است' });
    }

    const parsedOrderIds = (Array.isArray(orderIds) ? orderIds : [orderIds])
      .map((id: any) => parseInt(id))
      .filter((id: number) => !isNaN(id));

    if (parsedOrderIds.length === 0) {
      return res.status(400).json({ error: 'سفارشات انتخاب شده معتبر نیستند' });
    }

    // Verify all orders belong to this store and are unpaid
    const ordersToPay = await prisma.order.findMany({
      where: {
        id: { in: parsedOrderIds },
        storeId,
        storeInvoiceId: null
      }
    });

    if (ordersToPay.length !== parsedOrderIds.length) {
      return res.status(400).json({ error: 'برخی از سفارشات نامعتبر یا قبلا پرداخت شده اند' });
    }

    const totalAmount = ordersToPay.reduce((acc, o) => acc + o.totalAmount, 0);

    const isManual = paymentMethod === 'MANUAL';

    // Create invoice in PENDING status
    const invoice = await prisma.storeInvoice.create({
      data: {
        storeManagerId: storeId,
        totalAmount,
        status: 'PENDING',
        paymentMethod: isManual ? 'MANUAL' : 'ONLINE',
        receiptStatus: isManual ? 'PENDING' : null
      }
    });

    // Link orders to the StoreInvoice
    await prisma.order.updateMany({
      where: { id: { in: parsedOrderIds } },
      data: { 
        storeInvoiceId: invoice.id,
        status: 'WAITING_FOR_PAYMENT'
      }
    });

    if (isManual) {
      return res.json({
        success: true,
        message: 'فاکتور صادر شد. لطفاً جهت فعال‌سازی نهایی سفارشات، تصویر فیش واریزی را در بخش «صورت‌حساب‌ها» بارگذاری کنید.',
        invoiceId: invoice.id,
        manual: true
      });
    }

    // Request payment from Zibal gateway
    const baseUrl = getRequestBaseUrl(req);
    const callbackUrl = `${baseUrl}/api/store-manager/payment-callback`;

    const paymentGateway = PaymentServiceFactory.getService();
    const gatewayResponse = await paymentGateway.createPayment(
      totalAmount,
      `تسویه فاکتور شماره INV-${invoice.id}`,
      callbackUrl
    );

    // Update the invoice with gatewayReference
    await prisma.storeInvoice.update({
      where: { id: invoice.id },
      data: {
        gatewayReference: gatewayResponse.authority,
        trackId: gatewayResponse.authority
      }
    });

    res.json({
      success: true,
      message: 'فاکتور صادر شد و در حال انتقال به درگاه پرداخت...',
      payLink: gatewayResponse.payLink,
      invoiceId: invoice.id
    });

  } catch (err: any) {
    console.error('Error in settle-orders:', err);
    res.status(500).json({ error: 'خطا در تسویه سفارشات: ' + err.message });
  }
});

// Retry payment for an existing invoice
app.post('/api/store-manager/invoices/:id/pay', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const invoiceId = parseInt(req.params.id);

    const invoice = await prisma.storeInvoice.findUnique({
      where: { id: invoiceId }
    });

    if (!invoice || invoice.storeManagerId !== storeId) {
      return res.status(404).json({ error: 'فاکتور یافت نشد' });
    }

    if (invoice.status === 'PAID') {
      return res.status(400).json({ error: 'این فاکتور قبلا پرداخت شده است' });
    }

    // Request payment from Zibal gateway
    const baseUrl = getRequestBaseUrl(req);
    const callbackUrl = `${baseUrl}/api/store-manager/payment-callback`;

    const paymentGateway = PaymentServiceFactory.getService();
    const gatewayResponse = await paymentGateway.createPayment(
      invoice.totalAmount,
      `تسویه فاکتور شماره INV-${invoice.id}`,
      callbackUrl
    );

    // Update the invoice with new gatewayReference and ensure status is PENDING
    await prisma.storeInvoice.update({
      where: { id: invoice.id },
      data: {
        status: 'PENDING',
        gatewayReference: gatewayResponse.authority,
        trackId: gatewayResponse.authority
      }
    });

    res.json({
      success: true,
      message: 'در حال انتقال به درگاه پرداخت...',
      payLink: gatewayResponse.payLink,
      invoiceId: invoice.id
    });

  } catch (err: any) {
    console.error('Error in invoices/:id/pay:', err);
    res.status(500).json({ error: 'خطا در ایجاد تراکنش پرداخت: ' + err.message });
  }
});

// Submit receipt for manual payment
app.post('/api/store-manager/invoices/:id/receipt', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const invoiceId = parseInt(req.params.id);
    const { receiptUrl, receiptNotes } = req.body;

    if (!receiptUrl) {
      return res.status(400).json({ error: 'آدرس فیش پرداختی الزامی است' });
    }

    const invoice = await prisma.storeInvoice.findUnique({
      where: { id: invoiceId }
    });

    if (!invoice || invoice.storeManagerId !== storeId) {
      return res.status(404).json({ error: 'فاکتور یافت نشد' });
    }

    if (invoice.paymentMethod !== 'MANUAL') {
      return res.status(400).json({ error: 'این فاکتور برای پرداخت کارت به کارت تنظیم نشده است' });
    }

    await prisma.storeInvoice.update({
      where: { id: invoiceId },
      data: {
        receiptUrl,
        receiptNotes: receiptNotes || null,
        receiptStatus: 'PENDING'
      }
    });

    res.json({ success: true, message: 'فیش واریزی با موفقیت ثبت شد و در انتظار تایید مدیریت است.' });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در ثبت فیش: ' + err.message });
  }
});

// Zibal Payment Callback for Store Invoices
app.get('/api/store-manager/payment-callback', async (req: any, res: any) => {
  try {
    const baseUrl = getRequestBaseUrl(req);
    const trackId = req.query.trackId || req.query.Authority || req.query.authority;
    const successVal = req.query.success || req.query.Status || req.query.status;
    
    if (!trackId) {
      return res.status(400).send('کد رهگیری (trackId) مفقود است.');
    }

    const isSuccess = successVal === '1' || successVal === 'OK' || successVal === 'success' || successVal === '100';

    // Find the StoreInvoice by gatewayReference
    const invoice = await prisma.storeInvoice.findFirst({
      where: { gatewayReference: trackId.toString() },
      include: { orders: true }
    });

    if (!invoice) {
      return res.status(404).send('فاکتور منطبق با تراکنش یافت نشد.');
    }

    if (invoice.status === 'PAID') {
      return res.redirect(`${baseUrl}/?payment_status=success&trackId=${trackId}&invoiceId=${invoice.id}`);
    }

    if (!isSuccess) {
      // Payment failed or was cancelled
      await prisma.$transaction(async (tx) => {
        await tx.storeInvoice.update({
          where: { id: invoice.id },
          data: { status: 'FAILED' }
        });
        // Unlink orders so they can be paid again
        await tx.order.updateMany({
          where: { storeInvoiceId: invoice.id },
          data: { storeInvoiceId: null }
        });
      });
      return res.redirect(`${baseUrl}/?payment_status=failed&trackId=${trackId}&invoiceId=${invoice.id}`);
    }

    // Verify payment with Zibal gateway
    const paymentGateway = PaymentServiceFactory.getService();
    const verification = await paymentGateway.verifyPayment(trackId.toString(), invoice.totalAmount);

    if (verification.success) {
      // Complete transaction and perform wallet splitting inside a robust database transaction
      try {
        await prisma.$transaction(async (tx) => {
          // 1. Mark StoreInvoice as PAID (idempotency check)
          const updateResult = await tx.storeInvoice.updateMany({
            where: { id: invoice.id, status: { not: 'PAID' } },
            data: {
              status: 'PAID',
              paidAt: new Date(),
              trackId: verification.trackId || trackId.toString(),
              gatewayReference: verification.refId || trackId.toString()
            }
          });

          if (updateResult.count === 0) {
            throw new Error('DUPLICATE_CALLBACK');
          }

          // 2. Mark all associated orders as PAID
          await tx.order.updateMany({
            where: { storeInvoiceId: invoice.id },
            data: { status: 'PAID' }
          });

          // 2.5 Mark all associated order items as PAID
          await tx.orderItem.updateMany({
            where: {
              order: {
                storeInvoiceId: invoice.id
              }
            },
            data: { status: 'PAID' }
          });

          // 2.5.5 Find all OrderItems inside these orders to calculate supplier shares and decrement inventory
          const orderItems = await tx.orderItem.findMany({
            where: {
              order: {
                storeInvoiceId: invoice.id
              }
            }
          });

          // 2.5.6 Decrement inventory for all items
          for (const item of orderItems) {
            await tx.product.update({
              where: { id: item.productId },
              data: { inventory: { decrement: item.quantity } }
            });
          }

          // 2.6 Create a Payment record for receipt tracking
          const payment = await tx.payment.create({
            data: {
              amount: invoice.totalAmount,
              userId: invoice.storeManagerId,
              idempotencyKey: `INV_PAY_${invoice.id}_${verification.trackId || trackId}`,
              status: 'PAID',
              gatewayReference: verification.trackId || trackId.toString()
            }
          });

        // 2.6.5 Create Accounting Entry (Invoice)
        await tx.invoice.create({
          data: {
            invoiceNumber: `AC-INV-${invoice.id}-${Date.now()}`,
            paymentId: payment.id,
          }
        });

        // 2.7 Create TransactionLog
        await tx.transactionLog.create({
          data: {
            paymentId: payment.id,
            action: 'PAYMENT_SUCCESS',
            payload: `تسویه فاکتور #${invoice.id} با موفقیت انجام شد. کد پیگیری: ${verification.trackId || trackId}`
          }
        });

        // 4. Group & calculate supplier shares
        const supplierShares = new Map<number, number>();
        let totalPlatformRevenue = 0;

        for (const item of orderItems) {
          const share = item.quantity * item.supplierPrice;
          const storePays = item.quantity * item.price;
          const commission = storePays - share;

          if (share > 0) {
            supplierShares.set(item.supplierId, (supplierShares.get(item.supplierId) || 0) + share);
          }
          if (commission > 0) {
            totalPlatformRevenue += commission;
          }
        }

        // 5. Credit each supplier's wallet and log in Ledger
        for (const [supplierId, totalShare] of supplierShares.entries()) {
          let wallet = await tx.wallet.findUnique({
            where: { supplierId }
          });

          if (!wallet) {
            wallet = await tx.wallet.create({
              data: {
                supplierId,
                balance: 0
              }
            });
          }

          // Increment balance
          await tx.wallet.update({
            where: { id: wallet.id },
            data: {
              balance: {
                increment: totalShare
              }
            }
          });

          // Create LedgerEntry
          await tx.ledgerEntry.create({
            data: {
              walletId: wallet.id,
              amount: totalShare,
              type: 'ORDER_REVENUE',
              status: 'COMPLETED',
              description: `سهم تامین‌کننده از تسویه فاکتور شماره INV-${invoice.id} برای سفارشات مربوطه`,
              referenceId: invoice.id.toString()
            }
          });
        }

        // 6. Record Platform Revenue (Commission)
        if (totalPlatformRevenue > 0) {
          await tx.auditTrail.create({
            data: {
              actorId: invoice.storeManagerId,
              action: 'PLATFORM_REVENUE',
              resource: `StoreInvoice:${invoice.id}`,
              metadata: JSON.stringify({
                amount: totalPlatformRevenue,
                description: `سود پلتفرم از تسویه فاکتور #${invoice.id}`
              })
            }
          });
        }
      });
      } catch (err: any) {
        if (err.message === 'DUPLICATE_CALLBACK') {
          return res.redirect(`${baseUrl}/?payment_status=success&trackId=${verification.trackId || trackId}&invoiceId=${invoice.id}`);
        }
        throw err;
      }

      return res.redirect(`${baseUrl}/?payment_status=success&trackId=${verification.trackId || trackId}&invoiceId=${invoice.id}`);
    } else {
      // Verification failed
      await prisma.$transaction(async (tx) => {
        await tx.storeInvoice.update({
          where: { id: invoice.id },
          data: { status: 'FAILED' }
        });
        await tx.order.updateMany({
          where: { storeInvoiceId: invoice.id },
          data: { storeInvoiceId: null }
        });
      });
      return res.redirect(`${baseUrl}/?payment_status=failed&trackId=${trackId}&invoiceId=${invoice.id}&reason=verification_failed`);
    }

  } catch (err: any) {
    console.error('Error in payment-callback:', err);
    return res.status(500).send('خطای داخلی سرور در تایید پرداخت: ' + err.message);
  }
});

app.get('/api/store-manager/invoices', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const invoices = await prisma.storeInvoice.findMany({
      where: { storeManagerId: storeId },
      include: {
        orders: {
          include: {
            items: {
              include: {
                product: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(invoices);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت فاکتورها' });
  }
});

app.get('/api/store-manager/settings', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    let settings = await prisma.storeSettings.findUnique({
      where: { storeManagerId: storeId }
    });
    
    if (!settings) {
      settings = await prisma.storeSettings.create({
        data: { storeManagerId: storeId }
      });
    }
    res.json(settings);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت تنظیمات' });
  }
});

app.post('/api/store-manager/settings', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const { platformType, apiKey, webhookUrl } = req.body;
    
    const settings = await prisma.storeSettings.upsert({
      where: { storeManagerId: storeId },
      update: { platformType, apiKey, webhookUrl },
      create: { storeManagerId: storeId, platformType, apiKey, webhookUrl }
    });
    
    res.json({ message: 'تنظیمات با موفقیت ذخیره شد', settings });
  } catch (err) {
    res.status(500).json({ error: 'خطا در ذخیره تنظیمات' });
  }
});


// --- Admin API Routes ---
const requireAdmin = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ error: 'دسترسی فقط برای مدیر کل مجاز است' });
  }
  next();
};


// GET /api/admin/referrers
app.get('/api/admin/referrers', authenticateToken, requireAdmin, async (req: any, res) => {
  try {
    const referrers = await prisma.user.findMany({
      where: { role: 'REFERRER' },
      include: {
        wallet: true,
        referrerReferrals: true
      }
    });

    const formattedReferrers = referrers.map(r => ({
      id: r.id,
      username: r.username,
      firstName: r.firstName,
      lastName: r.lastName,
      mobile: r.mobile,
      email: r.email,
      status: r.status || 'ACTIVE',
      referralCode: r.referralCode,
      walletBalance: r.wallet ? Number(r.wallet.balance) : 0,
      referralCount: r.referrerReferrals.length,
      createdAt: r.createdAt || new Date()
    }));

    return res.json(formattedReferrers);
  } catch (error: any) {
    console.error('Error in GET /api/admin/referrers:', error);
    return res.status(500).json({ error: 'خطایی رخ داد.' });
  }
});

// PATCH /api/admin/referrers/:id/status
app.patch('/api/admin/referrers/:id/status', authenticateToken, requireAdmin, async (req: any, res) => {
  try {
    const referrerId = parseInt(req.params.id);
    const { status } = req.body;

    if (!['ACTIVE', 'BLOCKED', 'SUSPENDED'].includes(status)) {
      return res.status(400).json({ error: 'وضعیت ارسالی نامعتبر است.' });
    }

    const updated = await prisma.user.update({
      where: { id: referrerId },
      data: { status }
    });

    return res.json({ message: 'وضعیت معرف با موفقیت بروزرسانی شد.', user: updated });
  } catch (error: any) {
    console.error('Error updating referrer status:', error);
    return res.status(500).json({ error: 'خطایی رخ داد.' });
  }
});

// POST /api/admin/referrers/:id/wallet
app.post('/api/admin/referrers/:id/wallet', authenticateToken, requireAdmin, async (req: any, res) => {
  try {
    const referrerId = parseInt(req.params.id);
    const { amount, type, description } = req.body; // type: "DEPOSIT" (increase) or "WITHDRAWAL" (decrease)

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'مبلغ باید بزرگتر از صفر باشد.' });
    }

    let wallet = await prisma.wallet.findUnique({
      where: { supplierId: referrerId }
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          supplierId: referrerId,
          balance: 0.0
        }
      });
    }

    const currentBalance = Number(wallet.balance);
    let newBalance = currentBalance;

    if (type === 'DEPOSIT') {
      newBalance += amount;
    } else if (type === 'WITHDRAWAL') {
      if (currentBalance < amount) {
        return res.status(400).json({ error: 'موجودی کافی نیست.' });
      }
      newBalance -= amount;
    } else {
      return res.status(400).json({ error: 'نوع تراکنش نامعتبر است.' });
    }

    // Update wallet balance
    const updatedWallet = await prisma.wallet.update({
      where: { supplierId: referrerId },
      data: { balance: newBalance }
    });

    // Create ledger entry
    await prisma.ledgerEntry.create({
      data: {
        walletId: wallet.id,
        amount: amount,
        type: type === 'DEPOSIT' ? 'DEPOSIT' : 'WITHDRAWAL',
        status: 'COMPLETED',
        description: description || 'تراکنش دستی توسط مدیر سیستم'
      }
    });

    return res.json({ message: 'کیف پول با موفقیت بروزرسانی شد.', balance: newBalance });
  } catch (error: any) {
    console.error('Error modifying referrer wallet:', error);
    return res.status(500).json({ error: 'خطایی رخ داد.' });
  }
});


// Review/Force-Update payout status (Super Admin Only)
app.put('/api/admin/payouts/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const payoutId = req.params.id;
    const { status } = req.body; // e.g. 'SUCCESS' or 'FAILED'
    
    if (!['SUCCESS', 'FAILED'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const payoutRequest = await prisma.payoutRequest.findUnique({ where: { id: payoutId } });
    if (!payoutRequest) {
      return res.status(404).json({ error: 'Payout request not found' });
    }
    
    // Check if it's already in final state
    if (payoutRequest.status === 'SUCCESS' || payoutRequest.status === 'FAILED') {
      return res.status(400).json({ error: 'Payout is already in a final state' });
    }

    await prisma.$transaction(async (tx) => {
      // Update payout status
      await tx.payoutRequest.update({
        where: { id: payoutId },
        data: { status }
      });

      // Update associated ledger entry
      await tx.ledgerEntry.updateMany({
        where: { referenceId: payoutId, type: 'WITHDRAWAL' },
        data: { status: status === 'SUCCESS' ? 'COMPLETED' : 'FAILED' }
      });

      // If failed, return funds to wallet
      if (status === 'FAILED') {
        await tx.wallet.update({
          where: { id: payoutRequest.walletId },
          data: {
            balance: {
              increment: payoutRequest.amount
            }
          }
        });
      }
    });

    res.json({ success: true, message: `Payout status updated to ${status}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});


// ----------------- MANUAL INVOICE APPROVAL (ADMIN) -----------------
app.get('/api/admin/manual-invoices', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const invoices = await prisma.storeInvoice.findMany({
      where: { paymentMethod: 'MANUAL' },
      include: {
        storeManager: {
          select: { id: true, firstName: true, lastName: true, storeName: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(invoices);
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در دریافت فاکتورهای دستی: ' + err.message });
  }
});

app.post('/api/admin/manual-invoices/:id/approve', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const invoiceId = parseInt(req.params.id);
    const invoice = await prisma.storeInvoice.findUnique({
      where: { id: invoiceId },
      include: { orders: { include: { items: true } } }
    });

    if (!invoice) return res.status(404).json({ error: 'فاکتور یافت نشد' });
    if (invoice.status === 'PAID') return res.status(400).json({ error: 'این فاکتور قبلا پرداخت شده است' });
    if (invoice.paymentMethod !== 'MANUAL') return res.status(400).json({ error: 'این فاکتور دستی نیست' });

    await prisma.$transaction(async (tx) => {
      // 1. Update invoice status
      await tx.storeInvoice.update({
        where: { id: invoice.id },
        data: {
          status: 'PAID',
          receiptStatus: 'APPROVED',
          paidAt: new Date()
        }
      });

      // 2. Mark orders as PAID
      await tx.order.updateMany({
        where: { storeInvoiceId: invoice.id },
        data: { status: 'PAID' }
      });

      // 3. Create Payment and Accounting Records
      const payment = await tx.payment.create({
        data: {
          amount: invoice.totalAmount,
          userId: invoice.storeManagerId,
          idempotencyKey: `INV_PAY_MANUAL_${invoice.id}`,
          status: 'PAID',
          gatewayReference: 'MANUAL_TRANSFER'
        }
      });

      await tx.invoice.create({
        data: {
          invoiceNumber: `AC-INV-${invoice.id}-${Date.now()}`,
          paymentId: payment.id,
        }
      });

      await tx.transactionLog.create({
        data: {
          paymentId: payment.id,
          action: 'PAYMENT_SUCCESS',
          payload: `تایید دستی فیش واریزی برای فاکتور #${invoice.id}`
        }
      });

      // 5. Gather order items and calculate supplier shares
      const orderItems: any[] = [];
      for (const order of invoice.orders) {
        for (const item of order.items) {
          orderItems.push(item);
        }
      }

      const supplierShares = new Map<number, number>();
      let totalPlatformRevenue = 0;

      for (const item of orderItems) {
        const share = item.quantity * item.supplierPrice;
        const storePays = item.quantity * item.price;
        const commission = storePays - share;

        if (share > 0) {
          supplierShares.set(item.supplierId, (supplierShares.get(item.supplierId) || 0) + share);
        }
        if (commission > 0) {
          totalPlatformRevenue += commission;
        }
      }

      // 6. Credit suppliers' wallets
      const supplierIds = Array.from(supplierShares.keys());
      const existingWallets = await tx.wallet.findMany({
        where: { supplierId: { in: supplierIds } }
      });
      const walletMap = new Map<number, any>(existingWallets.map(w => [w.supplierId, w]));

      for (const [supplierId, totalShare] of supplierShares.entries()) {
        let wallet = walletMap.get(supplierId);
        if (!wallet) {
          wallet = await tx.wallet.create({ data: { supplierId, balance: 0 } });
          walletMap.set(supplierId, wallet);
        }
        await tx.wallet.update({
          where: { id: wallet.id },
          data: { balance: { increment: totalShare } }
        });
        await tx.ledgerEntry.create({
          data: {
            walletId: wallet.id,
            amount: totalShare,
            type: 'ORDER_REVENUE',
            status: 'COMPLETED',
            description: `سهم تامین‌کننده از فاکتور دستی شماره INV-${invoice.id}`,
            referenceId: invoice.id.toString()
          }
        });
      }

      // 7. Record Platform Revenue
      if (totalPlatformRevenue > 0) {
        await tx.auditTrail.create({
          data: {
            actorId: req.user.userId,
            action: 'PLATFORM_REVENUE',
            resource: `StoreInvoice:${invoice.id}`,
            metadata: JSON.stringify({ amount: totalPlatformRevenue, description: `سود پلتفرم از فاکتور دستی #${invoice.id}` })
          }
        });
      }
    }, { maxWait: 15000, timeout: 30000 });

    res.json({ success: true, message: 'فیش واریزی تایید و کیف پول تامین‌کنندگان شارژ شد.' });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در تایید فیش: ' + err.message });
  }
});

app.post('/api/admin/manual-invoices/:id/reject', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const invoiceId = parseInt(req.params.id);
    const invoice = await prisma.storeInvoice.findUnique({
      where: { id: invoiceId }
    });

    if (!invoice) return res.status(404).json({ error: 'فاکتور یافت نشد' });
    
    await prisma.storeInvoice.update({
      where: { id: invoiceId },
      data: { receiptStatus: 'REJECTED' }
    });

    res.json({ success: true, message: 'فیش رد شد.' });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در رد فیش: ' + err.message });
  }
});


// ----------------- WALLET DEPOSIT (SUPPLIER & STORE MANAGER) -----------------
app.post('/api/wallet/deposit', authenticateToken, async (req: any, res: any) => {
  try {
    const userId = req.user.userId;
    const { amount } = req.body;

    if (!amount || amount < 1000) {
      return res.status(400).json({ error: 'مبلغ نامعتبر است' });
    }

    let wallet = await prisma.wallet.findUnique({ where: { supplierId: userId } });
    if (!wallet) {
      wallet = await prisma.wallet.create({ data: { supplierId: userId, balance: 0 } });
    }

    const idempotencyKey = `DEPOSIT_${wallet.id}_${Date.now()}`;
    
    const payment = await prisma.payment.create({
      data: {
        amount,
        userId: userId,
        idempotencyKey,
        status: 'PENDING',
        gatewayReference: ''
      }
    });

    const baseUrl = getRequestBaseUrl(req);
    const callbackUrl = `${baseUrl}/api/wallet/deposit/callback`;

    const zibalReq = await fetch('https://gateway.zibal.ir/v1/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        merchant: process.env.ZIBAL_MERCHANT || 'zibal',
        amount: amount * 10,
        callbackUrl,
        orderId: payment.id.toString(),
        description: 'شارژ کیف پول'
      })
    });

    const zibalRes = await zibalReq.json();
    if (zibalRes.result === 100) {
      res.json({ payLink: `https://gateway.zibal.ir/start/${zibalRes.trackId}` });
    } else {
      res.status(500).json({ error: 'خطا در ارتباط با درگاه پرداخت' });
    }
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در ایجاد درخواست پرداخت: ' + err.message });
  }
});

app.get('/api/wallet/deposit/callback', async (req: any, res: any) => {
  try {
    const { success, trackId, orderId, status } = req.query;

    if (!orderId || !trackId) {
      return res.send('ورودی نامعتبر');
    }

    const payment = await prisma.payment.findUnique({
      where: { id: parseInt(orderId as string) }
    });

    if (!payment) return res.send('تراکنش یافت نشد');
    if (payment.status === 'PAID') return res.send('این تراکنش قبلا تایید شده است');

    const redirectBaseUrl = getRequestBaseUrl(req);

    if (success === '1' && status === '2') {
      const zibalVerifyReq = await fetch('https://gateway.zibal.ir/v1/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchant: process.env.ZIBAL_MERCHANT || 'zibal',
          trackId: trackId
        })
      });
      const zibalVerifyRes = await zibalVerifyReq.json();

      if (zibalVerifyRes.result === 100) {
        await prisma.$transaction(async (tx) => {
          await tx.payment.update({
            where: { id: payment.id },
            data: { status: 'PAID', gatewayReference: trackId.toString() }
          });

          await tx.transactionLog.create({
            data: {
              paymentId: payment.id,
              action: 'PAYMENT_SUCCESS',
              payload: `تراکنش شارژ کیف پول با کد رهگیری ${trackId}`
            }
          });

          const wallet = await tx.wallet.findUnique({ where: { supplierId: payment.userId } });
          if (wallet) {
            await tx.wallet.update({
              where: { id: wallet.id },
              data: { balance: { increment: payment.amount } }
            });

            await tx.ledgerEntry.create({
              data: {
                walletId: wallet.id,
                amount: payment.amount,
                type: 'DEPOSIT',
                status: 'COMPLETED',
                description: `شارژ مستقیم کیف پول (کد رهگیری درگاه: ${trackId})`,
                referenceId: payment.id.toString()
              }
            });
          }
        });

        res.send(`
          <div style="font-family: Tahoma, sans-serif; text-align: center; margin-top: 50px;" dir="rtl">
            <h2 style="color: green;">پرداخت موفقیت‌آمیز بود</h2>
            <p>کیف پول شما شارژ شد. کد رهگیری: ${trackId}</p>
            <script>
              setTimeout(() => {
                window.location.href = "${redirectBaseUrl}";
              }, 3000);
            </script>
          </div>
        `);
      } else {
        await prisma.payment.update({
          where: { id: payment.id },
          data: { status: 'FAILED', gatewayReference: trackId.toString() }
        });
        res.send(`
          <div style="font-family: Tahoma, sans-serif; text-align: center; margin-top: 50px;" dir="rtl">
            <h2 style="color: red;">خطا در تایید تراکنش بانکی (کد ${zibalVerifyRes.result})</h2>
            <script>
              setTimeout(() => {
                window.location.href = "${redirectBaseUrl}";
              }, 3000);
            </script>
          </div>
        `);
      }
    } else {
      await prisma.payment.update({
        where: { id: payment.id },
        data: { status: 'FAILED' }
      });
      res.send(`
        <div style="font-family: Tahoma, sans-serif; text-align: center; margin-top: 50px;" dir="rtl">
          <h2 style="color: red;">تراکنش لغو شد یا ناموفق بود</h2>
          <script>
            setTimeout(() => {
              window.location.href = "${redirectBaseUrl}";
            }, 3000);
          </script>
        </div>
      `);
    }
  } catch (err: any) {
    res.status(500).send('خطا در پردازش بازگشت از درگاه: ' + err.message);
  }
});


// ----------------- SUPER ADMIN SETTLEMENT REQUESTS ENDPOINTS -----------------

// Retrieve all settlement requests (PayoutRequest)
app.get('/api/admin/settlements', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { status } = req.query;
    const whereClause: any = {};
    if (status) {
      whereClause.status = status; // PENDING, PROCESSING, SUCCESS, FAILED
    }

    const payoutRequests = await prisma.payoutRequest.findMany({
      where: whereClause,
      include: {
        wallet: {
          include: {
            supplier: {
              select: {
                id: true,
                name: true,
                shaba: true,
                bankName: true,
                accountHolderName: true,
                email: true,
                phone: true,
                companyName: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const formattedRequests = payoutRequests.map((pr: any) => {
      const balance = parseFloat(pr.wallet.balance.toString());
      const amount = parseFloat(pr.amount.toString());
      return {
        id: pr.id,
        supplierId: pr.wallet.supplierId,
        supplierName: pr.wallet.supplier?.name || 'نامشخص',
        walletBalance: balance,
        requestedAmount: amount,
        remainingBalance: balance, // balance is already decremented/locked in requestPayout
        iban: pr.shaba || pr.wallet.supplier?.shaba || 'ثبت نشده',
        bankName: pr.wallet.supplier?.bankName || 'ثبت نشده',
        accountHolderName: pr.wallet.supplier?.accountHolderName || 'ثبت نشده',
        requestDate: pr.createdAt,
        status: pr.status, // PENDING, PROCESSING, SUCCESS, FAILED
        trackId: pr.trackId
      };
    });

    res.json({ success: true, settlements: formattedRequests });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Approve Settlement Request
app.post('/api/admin/settlements/:id/approve', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id },
      include: { wallet: true }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    if (payoutRequest.status !== 'PENDING') {
      return res.status(400).json({ error: 'فقط درخواست‌های در انتظار تایید امکان تایید دارند' });
    }

    const updated = await prisma.$transaction(async (tx) => {
      const pr = await tx.payoutRequest.update({
        where: { id },
        data: { status: 'PROCESSING' } // Approved / Processing
      });

      // Associated ledger entry status to PENDING
      await tx.ledgerEntry.updateMany({
        where: { referenceId: id, type: 'WITHDRAWAL' },
        data: { status: 'PENDING' }
      });

      // Create Audit Trail
      await tx.auditTrail.create({
        data: {
          actorId: req.user.userId,
          action: 'APPROVE_PAYOUT_REQUEST',
          resource: `PayoutRequest:${id}`,
          metadata: JSON.stringify({ amount: payoutRequest.amount.toString(), walletId: payoutRequest.walletId })
        }
      });

      return pr;
    });

    res.json({ success: true, message: 'درخواست تسویه با موفقیت تایید شد', payoutRequest: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Reject Settlement Request
app.post('/api/admin/settlements/:id/reject', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    if (payoutRequest.status === 'SUCCESS' || payoutRequest.status === 'FAILED') {
      return res.status(400).json({ error: 'درخواست در وضعیت نهایی است و امکان رد آن وجود ندارد' });
    }

    await prisma.$transaction(async (tx) => {
      // Update request status to FAILED (Rejected)
      await tx.payoutRequest.update({
        where: { id },
        data: { status: 'FAILED' }
      });

      // Update associated ledger entry
      await tx.ledgerEntry.updateMany({
        where: { referenceId: id, type: 'WITHDRAWAL' },
        data: { status: 'FAILED' }
      });

      // Refund the locked amount back to the wallet balance
      await tx.wallet.update({
        where: { id: payoutRequest.walletId },
        data: {
          balance: {
            increment: payoutRequest.amount
          }
        }
      });

      // Create Audit Log
      await tx.auditTrail.create({
        data: {
          actorId: req.user.userId,
          action: 'REJECT_PAYOUT_REQUEST',
          resource: `PayoutRequest:${id}`,
          metadata: JSON.stringify({ amount: payoutRequest.amount.toString(), walletId: payoutRequest.walletId })
        }
      });
    });

    res.json({ success: true, message: 'درخواست تسویه با موفقیت رد شد و موجودی به کیف پول بازگشت' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Mark Settlement Request as Paid
app.post('/api/admin/settlements/:id/pay', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { receiptUrl, transactionRef, paymentDate, paymentNotes } = req.body;

    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id },
      include: { wallet: true }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    // Prevent paying the same request twice
    if (payoutRequest.status === 'SUCCESS' || payoutRequest.financiallyLocked) {
      return res.status(400).json({ error: 'این درخواست قبلاً پرداخت و قفل مالی شده است' });
    }
    if (payoutRequest.status === 'FAILED') {
      return res.status(400).json({ error: 'این درخواست قبلاً رد شده است و امکان پرداخت آن وجود ندارد' });
    }

    await prisma.$transaction(async (tx) => {
      // Set status to SUCCESS (Paid) and apply financial lock
      const updateResult = await tx.payoutRequest.updateMany({
        where: { 
          id,
          status: { not: 'SUCCESS' },
          financiallyLocked: false
        },
        data: { 
          status: 'SUCCESS',
          financiallyLocked: true,
          receiptUrl: receiptUrl || null,
          transactionRef: transactionRef || null,
          paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
          paymentNotes: paymentNotes || null
        }
      });

      if (updateResult.count === 0) {
        throw new Error('DUPLICATE_SETTLEMENT_PAYMENT');
      }

      // Mark associated ledger entry (Wallet Transaction) as COMPLETED
      const ledgerEntry = await tx.ledgerEntry.findFirst({
        where: { referenceId: id, type: 'WITHDRAWAL' }
      });

      if (ledgerEntry) {
        await tx.ledgerEntry.update({
          where: { id: ledgerEntry.id },
          data: { status: 'COMPLETED' }
        });
      } else {
        // Fallback: If no transaction was pre-created, decrease wallet and create transaction now
        await tx.wallet.update({
          where: { id: payoutRequest.walletId },
          data: {
            balance: {
              decrement: payoutRequest.amount
            }
          }
        });

        await tx.ledgerEntry.create({
          data: {
            walletId: payoutRequest.walletId,
            amount: payoutRequest.amount.negated(),
            type: 'WITHDRAWAL',
            status: 'COMPLETED',
            referenceId: id,
            description: `تسویه حساب دستی - شبا: ${payoutRequest.shaba}`
          }
        });
      }

      // Create Accounting Entry (Settlement record)
      await tx.settlement.create({
        data: {
          supplierId: payoutRequest.wallet.supplierId,
          totalAmount: payoutRequest.amount,
          status: 'SUCCESS',
          settlementDate: paymentDate ? new Date(paymentDate) : new Date(),
          bankReference: transactionRef || payoutRequest.trackId || `MANUAL_PAY_${Date.now()}`
        }
      });

      // Create Audit Log
      await tx.auditTrail.create({
        data: {
          actorId: req.user.userId,
          action: 'MARK_PAYOUT_AS_PAID',
          resource: `PayoutRequest:${id}`,
          metadata: JSON.stringify({
            amount: payoutRequest.amount.toString(),
            walletId: payoutRequest.walletId,
            shaba: payoutRequest.shaba,
            transactionRef,
            receiptUrl
          })
        }
      });
      
      // Notify Supplier
      await tx.notification.create({
        data: {
          userId: payoutRequest.wallet.supplierId,
          title: 'تسویه حساب انجام شد',
          message: `مبلغ ${payoutRequest.amount.toString()} تومان به حساب شما واریز شد و رسید در دسترس است.`
        }
      });
    });

    res.json({ success: true, message: 'درخواست تسویه با موفقیت به عنوان پرداخت شده قفل شد' });
  } catch (err: any) {
    if (err.message === 'DUPLICATE_SETTLEMENT_PAYMENT') {
      return res.status(400).json({ error: 'این درخواست قبلاً پرداخت و قفل مالی شده است' });
    }
    res.status(500).json({ error: err.message });
  }
});

// Super Admin Financial Adjustment for Locked Settlements
app.post('/api/admin/settlements/:id/adjust', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    // Only superadmin can make adjustments
    if (req.user.role !== 'superadmin') {
      return res.status(403).json({ error: 'عدم دسترسی. فقط سوپر ادمین مجاز به ثبت اصلاحیه است.' });
    }

    const { id } = req.params;
    const { type, amount, reason } = req.body;

    if (!type || !amount || !reason) {
      return res.status(400).json({ error: 'تمامی فیلدها (نوع، مبلغ، دلیل) الزامی هستند' });
    }

    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id },
      include: { wallet: true }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    if (!payoutRequest.financiallyLocked) {
      return res.status(400).json({ error: 'اصلاحیه فقط برای تسویه‌های قفل شده مجاز است' });
    }

    await prisma.$transaction(async (tx) => {
      // Create Adjustment Record
      await tx.adjustmentRecord.create({
        data: {
          payoutRequestId: id,
          type,
          amount: new (require('decimal.js').Decimal)(amount),
          reason,
          actorId: req.user.userId
        }
      });

      // Update Wallet Balance appropriately
      // If we credited the user by mistake, we debit their wallet.
      // If we debited too much, we credit them.
      const adjustmentAmount = type === 'CREDIT' ? amount : -amount;
      
      await tx.wallet.update({
        where: { id: payoutRequest.walletId },
        data: {
          balance: {
            increment: adjustmentAmount
          }
        }
      });

      // Create Ledger Entry for the adjustment
      await tx.ledgerEntry.create({
        data: {
          walletId: payoutRequest.walletId,
          amount: adjustmentAmount,
          type: type === 'CREDIT' ? 'REFUND' : 'WITHDRAWAL',
          status: 'COMPLETED',
          referenceId: id,
          description: `اصلاحیه مالی تسویه حساب: ${reason}`
        }
      });

      // Audit log
      await tx.auditTrail.create({
        data: {
          actorId: req.user.userId,
          action: 'FINANCIAL_ADJUSTMENT',
          resource: `PayoutRequest:${id}`,
          metadata: JSON.stringify({
            type,
            amount,
            reason
          })
        }
      });
    });

    res.json({ success: true, message: 'اصلاحیه مالی با موفقیت ثبت شد' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Get Supplier Profile
app.get('/api/admin/suppliers/:id/profile', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const supplierId = parseInt(req.params.id);
    const supplier = await prisma.user.findUnique({
      where: { id: supplierId },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        mobile: true,
        role: true,
        status: true,
        shaba: true,
        bankName: true,
        accountHolderName: true,
        brandName: true
      }
    });

    if (!supplier) {
      return res.status(404).json({ error: 'تامین‌کننده یافت نشد' });
    }

    const mappedProfile = {
      id: supplier.id,
      name: `${supplier.firstName || ''} ${supplier.lastName || ''}`.trim() || 'نامشخص',
      email: supplier.email,
      phone: supplier.mobile,
      role: supplier.role,
      status: supplier.status,
      shaba: supplier.shaba,
      bankName: supplier.bankName,
      accountHolderName: supplier.accountHolderName,
      companyName: supplier.brandName,
      createdAt: new Date()
    };

    res.json({ success: true, profile: mappedProfile });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Get Supplier Wallet Transactions
app.get('/api/admin/suppliers/:id/wallet-transactions', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const supplierId = parseInt(req.params.id);
    const wallet = await prisma.wallet.findUnique({
      where: { supplierId }
    });

    if (!wallet) {
      return res.status(404).json({ error: 'کیف پول برای این تامین‌کننده یافت نشد' });
    }

    const transactions = await prisma.ledgerEntry.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, transactions });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Get Order History related to Wallet Credits
app.get('/api/admin/suppliers/:id/wallet-orders', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const supplierId = parseInt(req.params.id);
    const wallet = await prisma.wallet.findUnique({
      where: { supplierId }
    });

    if (!wallet) {
      return res.status(404).json({ error: 'کیف پول برای این تامین‌کننده یافت نشد' });
    }

    // Get all completed order revenue ledger entries
    const ledgerEntries = await prisma.ledgerEntry.findMany({
      where: {
        walletId: wallet.id,
        type: 'ORDER_REVENUE',
        status: 'COMPLETED'
      },
      orderBy: { createdAt: 'desc' }
    });

    // Extract reference IDs (which are storeInvoiceIds)
    const invoiceIds = ledgerEntries
      .map(entry => parseInt(entry.referenceId || ''))
      .filter(id => !isNaN(id));

    // Find all orders associated with these storeInvoiceIds where the supplier has items
    const orders = await prisma.order.findMany({
      where: {
        storeInvoiceId: { in: invoiceIds },
        items: {
          some: { supplierId }
        }
      },
      include: {
        store: {
          select: { id: true, name: true, email: true }
        },
        items: {
          where: { supplierId },
          include: {
            product: {
              select: { id: true, name: true, sku: true }
            }
          }
        },
        invoice: true
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, orders, ledgerEntries });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Generate Settlement Report
app.get('/api/admin/settlements/report', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const payoutRequests = await prisma.payoutRequest.findMany({
      include: {
        wallet: {
          include: {
            supplier: {
              select: {
                id: true,
                name: true,
                shaba: true,
                bankName: true,
                accountHolderName: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    // Calculate metrics
    let totalRequested = 0;
    let totalPaid = 0;
    let totalPending = 0;
    let totalApproved = 0;
    let totalRejected = 0;

    const items = payoutRequests.map((pr: any) => {
      const amount = parseFloat(pr.amount.toString());
      totalRequested += amount;
      
      if (pr.status === 'SUCCESS') totalPaid += amount;
      else if (pr.status === 'PENDING') totalPending += amount;
      else if (pr.status === 'PROCESSING') totalApproved += amount;
      else if (pr.status === 'FAILED') totalRejected += amount;

      return {
        id: pr.id,
        supplierId: pr.wallet.supplierId,
        supplierName: pr.wallet.supplier?.name || 'نامشخص',
        amount,
        shaba: pr.shaba,
        bankName: pr.wallet.supplier?.bankName || 'نامشخص',
        accountHolderName: pr.wallet.supplier?.accountHolderName || 'نامشخص',
        date: pr.createdAt,
        status: pr.status
      };
    });

    res.json({
      success: true,
      report: {
        generatedAt: new Date(),
        summary: {
          totalRequested,
          totalPaid,
          totalPending,
          totalApproved,
          totalRejected,
          count: payoutRequests.length
        },
        items
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});


// ----------------- SUPER ADMIN SETTLEMENT DETAILS & HISTORIES -----------------

// Retrieve complete details for a single settlement request
app.get('/api/admin/settlements/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;

    const payoutRequest = await prisma.payoutRequest.findUnique({
      where: { id },
      include: {
        wallet: {
          include: {
            supplier: true
          }
        },
        adjustments: {
          include: {
            actor: {
              select: { name: true, firstName: true, lastName: true }
            }
          }
        }
      }
    });

    if (!payoutRequest) {
      return res.status(404).json({ error: 'درخواست تسویه یافت نشد' });
    }

    // Retrieve all LedgerEntry records linked to this payout request
    const ledgerEntries = await prisma.ledgerEntry.findMany({
      where: {
        payoutRequestId: id,
        type: 'ORDER_REVENUE'
      },
      orderBy: { createdAt: 'desc' }
    });

    // For each LedgerEntry, trace the associated order items
    const breakdownItems: any[] = [];

    for (const entry of ledgerEntries) {
      const refId = entry.referenceId;
      if (!refId) continue;

      let orders: any[] = [];

      if (refId.startsWith('ORDER_')) {
        const orderIdStr = refId.replace('ORDER_', '');
        const orderId = parseInt(orderIdStr);
        if (!isNaN(orderId)) {
          const order = await prisma.order.findUnique({
            where: { id: orderId },
            include: {
              items: {
                where: { supplierId: payoutRequest.wallet.supplierId },
                include: { product: true }
              },
              invoice: true
            }
          });
          if (order) orders.push(order);
        }
      } else {
        const invoiceId = parseInt(refId);
        if (!isNaN(invoiceId)) {
          const fetchedOrders = await prisma.order.findMany({
            where: {
              storeInvoiceId: invoiceId,
              items: {
                some: { supplierId: payoutRequest.wallet.supplierId }
              }
            },
            include: {
              items: {
                where: { supplierId: payoutRequest.wallet.supplierId },
                include: { product: true }
              },
              invoice: true
            }
          });
          orders = fetchedOrders;
        }
      }

      for (const order of orders) {
        for (const item of order.items) {
          const supplierRevenue = parseFloat(item.supplierPrice.toString()) * item.quantity;
          const customerPrice = parseFloat(item.price.toString()) * item.quantity;
          const commission = Math.max(0, customerPrice - supplierRevenue);

          breakdownItems.push({
            orderNumber: order.id,
            orderDate: order.createdAt,
            productName: item.product?.name || 'نامشخص',
            sku: item.product?.sku || 'ثبت نشده',
            quantity: item.quantity,
            supplierRevenue,
            platformCommission: commission,
            paymentDate: entry.createdAt,
            walletCreditAmount: parseFloat(entry.amount.toString()),
            currentOrderStatus: order.status
          });
        }
      }
    }

    // Retrieve Audit history for this payout request
    const auditLogs = await prisma.auditTrail.findMany({
      where: {
        resource: {
          in: [`PayoutRequest:${id}`]
        }
      },
      include: {
        actor: {
          select: { id: true, name: true, email: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    // Format audit history response
    const auditHistory = auditLogs.map((log: any) => ({
      id: log.id,
      actorName: log.actor?.name || 'سیستم',
      action: log.action,
      metadata: log.metadata ? JSON.parse(log.metadata) : null,
      date: log.createdAt
    }));

    // Generate Accounting summary
    const totalOrdersIncluded = breakdownItems.length;
    const totalWalletCredits = breakdownItems.reduce((sum, item) => sum + item.walletCreditAmount, 0);
    const accountingSummary = {
      totalOrdersIncluded,
      totalWalletCredits,
      totalSupplierRevenue: breakdownItems.reduce((sum, item) => sum + item.supplierRevenue, 0),
      totalPlatformCommission: breakdownItems.reduce((sum, item) => sum + item.platformCommission, 0)
    };

    const formattedRequest = {
      id: payoutRequest.id,
      supplierId: payoutRequest.supplierId || payoutRequest.wallet.supplierId,
      supplierName: payoutRequest.supplierName || payoutRequest.wallet.supplier?.name || 'نامشخص',
      walletBalance: parseFloat((payoutRequest.currentBalance || payoutRequest.wallet.balance).toString()),
      requestedAmount: parseFloat(payoutRequest.amount.toString()),
      remainingBalance: parseFloat((payoutRequest.remainingBalance || payoutRequest.wallet.balance).toString()),
      iban: payoutRequest.shaba,
      bankName: payoutRequest.bankName || payoutRequest.wallet.supplier?.bankName || 'ثبت نشده',
      accountHolderName: payoutRequest.accountHolderName || payoutRequest.wallet.supplier?.accountHolderName || 'ثبت نشده',
      requestDate: payoutRequest.createdAt,
      status: payoutRequest.status,
      trackId: payoutRequest.trackId,
      financiallyLocked: payoutRequest.financiallyLocked,
      receiptUrl: payoutRequest.receiptUrl,
      transactionRef: payoutRequest.transactionRef,
      paymentDate: payoutRequest.paymentDate,
      paymentNotes: payoutRequest.paymentNotes,
      adjustments: payoutRequest.adjustments?.map((adj: any) => ({
        id: adj.id,
        type: adj.type,
        amount: parseFloat(adj.amount.toString()),
        reason: adj.reason,
        actorName: adj.actor?.name || `${adj.actor?.firstName || ''} ${adj.actor?.lastName || ''}`.trim() || 'نامشخص',
        createdAt: adj.createdAt
      })) || []
    };

    res.json({
      success: true,
      settlement: formattedRequest,
      breakdown: breakdownItems,
      accountingSummary,
      auditHistory
    });

  } catch (err: any) {
    console.error('Error fetching settlement details:', err);
    res.status(500).json({ error: err.message });
  }
});

// Retrieve Settlement history for a specific supplier
app.get('/api/admin/suppliers/:id/settlement-history', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const supplierId = parseInt(req.params.id);
    const wallet = await prisma.wallet.findUnique({
      where: { supplierId }
    });

    if (!wallet) {
      return res.status(404).json({ error: 'کیف پول برای این تامین‌کننده یافت نشد' });
    }

    const payoutRequests = await prisma.payoutRequest.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' }
    });

    const formatted = payoutRequests.map((pr: any) => ({
      id: pr.id,
      amount: parseFloat(pr.amount.toString()),
      currentBalance: pr.currentBalance ? parseFloat(pr.currentBalance.toString()) : null,
      remainingBalance: pr.remainingBalance ? parseFloat(pr.remainingBalance.toString()) : null,
      shaba: pr.shaba,
      bankName: pr.bankName,
      accountHolderName: pr.accountHolderName,
      status: pr.status,
      trackId: pr.trackId,
      date: pr.createdAt
    }));

    res.json({ success: true, settlements: formatted });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Retrieve global Wallet Credit history (Credits/ORDER_REVENUE entries across suppliers)
app.get('/api/admin/financial/credits', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const credits = await prisma.ledgerEntry.findMany({
      where: {
        type: 'ORDER_REVENUE',
        status: 'COMPLETED'
      },
      include: {
        wallet: {
          include: {
            supplier: {
              select: { id: true, name: true, email: true }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const formattedCredits = credits.map((cr: any) => ({
      id: cr.id,
      supplierId: cr.wallet.supplierId,
      supplierName: cr.wallet.supplier?.name || 'نامشخص',
      amount: parseFloat(cr.amount.toString()),
      description: cr.description,
      date: cr.createdAt,
      referenceId: cr.referenceId,
      settlementId: cr.payoutRequestId
    }));

    res.json({ success: true, credits: formattedCredits });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Retrieve global Accounting History (Settlement records across suppliers)
app.get('/api/admin/financial/accounting', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const settlements = await prisma.settlement.findMany({
      include: {
        supplier: {
          select: { id: true, name: true, companyName: true, shaba: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const formattedSettlements = settlements.map((st: any) => ({
      id: st.id,
      supplierId: st.supplierId,
      supplierName: st.supplier?.name || 'نامشخص',
      companyName: st.supplier?.companyName || 'ثبت نشده',
      amount: parseFloat(st.totalAmount.toString()),
      status: st.status,
      settlementDate: st.settlementDate,
      bankReference: st.bankReference,
      createdAt: st.createdAt
    }));

    res.json({ success: true, history: formattedSettlements });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});


app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const suppliersCount = await prisma.user.count({ where: { role: 'SUPPLIER' } });
    const storesCount = await prisma.user.count({ where: { role: 'STORE_MANAGER' } });
    const productsCount = await prisma.product.count();
    const ordersCount = await prisma.order.count();
    const totalRevenue = await prisma.storeInvoice.aggregate({ _sum: { totalAmount: true }, where: { status: 'PAID' } });

    res.json({
      suppliers: suppliersCount,
      stores: storesCount,
      activeProducts: productsCount,
      orders: ordersCount,
      totalRevenue: totalRevenue._sum.totalAmount || 0
    });
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت آمار' });
  }
});

app.post('/api/admin/create-proforma', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { storeManagerId, totalAmount, notes } = req.body;
    if (!storeManagerId || !totalAmount) {
      return res.status(400).json({ error: 'انتخاب مدیر فروشگاه و مبلغ الزامی است' });
    }
    const invoice = await prisma.storeInvoice.create({
      data: {
        storeManagerId: parseInt(storeManagerId),
        totalAmount: parseFloat(totalAmount),
        status: 'PENDING',
        paymentMethod: 'MANUAL',
        receiptStatus: 'PENDING',
        receiptNotes: notes || ''
      }
    });
    res.json({ success: true, invoice });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در صدور پیش‌فاکتور: ' + err.message });
  }
});

app.get('/api/admin/products', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const products = await prisma.product.findMany({
      include: {
        category: true,
        images: true,
        supplier: { select: { firstName: true, lastName: true, brandName: true } }
      }
    });
    console.log('Fetched products:', products.length);
    res.json(products);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: 'خطا در دریافت محصولات' });
  }
});

// Admin add product directly
app.post('/api/admin/products', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { name, categoryId, supplierId, shortDescription, longDescription, supplierBasePrice, finalPrice, sku, brand, inventory, imageUrl } = req.body;

    if (!name || !categoryId || !supplierBasePrice) {
      return res.status(400).json({ error: 'نام محصول، دسته‌بندی و قیمت پایه الزامی هستند' });
    }

    // If no supplierId specified, find the first available supplier
    let targetSupplierId = supplierId ? parseInt(supplierId) : null;
    if (!targetSupplierId) {
      const supplier = await prisma.user.findFirst({ where: { role: 'SUPPLIER' } });
      if (!supplier) {
        return res.status(400).json({ error: 'هیچ تامین‌کننده‌ای در سیستم یافت نشد. لطفا ابتدا یک تامین‌کننده تعریف کنید.' });
      }
      targetSupplierId = supplier.id;
    }

    const newProduct = await prisma.product.create({
      data: {
        name,
        categoryId: parseInt(categoryId),
        supplierId: targetSupplierId,
        shortDescription: shortDescription || null,
        longDescription: longDescription || null,
        supplierBasePrice: parseFloat(supplierBasePrice),
        finalPrice: finalPrice ? parseFloat(finalPrice) : parseFloat(supplierBasePrice),
        sku: sku || null,
        brand: brand || null,
        inventory: inventory ? parseInt(inventory) : 0,
        status: 'PUBLISHED', // Auto-publish for admin additions
        images: imageUrl ? {
          create: {
            url: imageUrl,
            isMain: true
          }
        } : undefined
      }
    });

    res.json({ message: 'محصول با موفقیت توسط مدیر ایجاد شد.', product: newProduct });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در ثبت محصول توسط مدیر' });
  }
});

// Admin update/edit product directly (including SKU and finalPrice)
app.put('/api/admin/products/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { name, categoryId, supplierId, shortDescription, longDescription, supplierBasePrice, finalPrice, sku, brand, inventory, imageUrl } = req.body;

    const dataToUpdate: any = {};
    if (name) dataToUpdate.name = name;
    if (categoryId) dataToUpdate.categoryId = parseInt(categoryId);
    if (supplierId) dataToUpdate.supplierId = parseInt(supplierId);
    if (shortDescription !== undefined) dataToUpdate.shortDescription = shortDescription;
    if (longDescription !== undefined) dataToUpdate.longDescription = longDescription;
    if (supplierBasePrice !== undefined) dataToUpdate.supplierBasePrice = parseFloat(supplierBasePrice);
    if (finalPrice !== undefined) dataToUpdate.finalPrice = finalPrice ? parseFloat(finalPrice) : null;
    if (sku !== undefined) dataToUpdate.sku = sku;
    if (brand !== undefined) dataToUpdate.brand = brand;
    if (inventory !== undefined) dataToUpdate.inventory = parseInt(inventory);

    if (imageUrl) {
      await prisma.productImage.deleteMany({ where: { productId: parseInt(id) } });
      dataToUpdate.images = {
        create: {
          url: imageUrl,
          isMain: true
        }
      };
    }

    const updatedProduct = await prisma.product.update({
      where: { id: parseInt(id) },
      data: dataToUpdate
    });

    res.json({ message: 'محصول با موفقیت بروزرسانی شد.', product: updatedProduct });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در بروزرسانی محصول' });
  }
});

// Admin delete product directly
app.delete('/api/admin/products/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    await prisma.product.delete({ where: { id: parseInt(id) } });
    res.json({ message: 'محصول با موفقیت حذف شد.' });
  } catch (err) {
    res.status(500).json({ error: 'خطا در حذف محصول' });
  }
});


app.patch('/api/admin/products/:id/publish', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { finalPrice, marginType, marginValue, publishStartDate, publishEndDate, isPinned } = req.body;
    
    // Check if pinning limit reached
    if (isPinned) {
      const pinnedCount = await prisma.product.count({ where: { isPinned: true, status: 'PUBLISHED' } });
      if (pinnedCount >= 10) {
        // Maybe we just unpin the oldest? Or return error.
        // Let's return error.
        return res.status(400).json({ error: 'Maximum 10 pinned products allowed.' });
      }
    }

    const product = await prisma.product.update({
      where: { id: parseInt(id) },
      data: {
        finalPrice: finalPrice ? parseFloat(finalPrice) : null,
        marginType,
        marginValue: marginValue ? parseFloat(marginValue) : null,
        publishStartDate: publishStartDate ? new Date(publishStartDate) : null,
        publishEndDate: publishEndDate ? new Date(publishEndDate) : null,
        isPinned: !!isPinned,
        status: 'PUBLISHED'
      }
    });
    console.log('Product published:', product.id, 'finalPrice:', finalPrice, 'marginType:', marginType, 'marginValue:', marginValue);
    res.json({ message: 'Product published and activated', product });
  } catch (err) {
    console.error('Error publishing product:', err);
    res.status(500).json({ error: 'Error publishing product' });
  }
});

app.patch('/api/admin/products/:id/status', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    let { status } = req.body;
    
    // Once approved or published, status is automatically set to PUBLISHED
    if (status === 'APPROVED' || status === 'PUBLISHED' || status === 'ACTIVE') {
      status = 'PUBLISHED';
    }

    const product = await prisma.product.update({
      where: { id: parseInt(id) },
      data: { status }
    });
    res.json({ message: 'Status updated', product });
  } catch (err) {
    res.status(500).json({ error: 'Error updating status' });
  }
});


// --- USER MANAGEMENT (SUPER ADMIN) ---


// Add User
app.post('/api/admin/users', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { username, password, role, firstName, lastName, mobile, brandName, storeName, nationalCode } = req.body;
    
    if (!username || !password || !role) {
      return res.status(400).json({ error: 'نام کاربری، رمز عبور و نقش الزامی است' });
    }
    
    const existing = await prisma.user.findUnique({ where: { username } });
    if (existing) {
      return res.status(400).json({ error: 'نام کاربری تکراری است' });
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const user = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        role,
        firstName,
        lastName,
        mobile,
        brandName,
        storeName,
        nationalCode,
        status: 'ACTIVE'
      }
    });
    
    res.json({ message: 'کاربر با موفقیت ایجاد شد', user });
  } catch (err) {
    res.status(500).json({ error: 'خطا در ایجاد کاربر' });
  }
});

// Edit User
app.put('/api/admin/users/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const id = parseInt(req.params.id);
    const { firstName, lastName, mobile, brandName, storeName, nationalCode } = req.body;
    
    const user = await prisma.user.update({
      where: { id },
      data: { firstName, lastName, mobile, brandName, storeName, nationalCode }
    });
    
    res.json({ message: 'کاربر با موفقیت ویرایش شد', user });
  } catch (err) {
    res.status(500).json({ error: 'خطا در ویرایش کاربر' });
  }
});

// Reset Password
app.post('/api/admin/users/:id/reset-password', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const id = parseInt(req.params.id);
    const { newPassword } = req.body;
    
    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' });
    }
    
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    await prisma.user.update({
      where: { id },
      data: { password: hashedPassword }
    });
    
    res.json({ message: 'رمز عبور با موفقیت تغییر یافت' });
  } catch (err) {
    res.status(500).json({ error: 'خطا در تغییر رمز عبور' });
  }
});

// Change Status
app.patch('/api/admin/users/:id/status', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const id = parseInt(req.params.id);
    const { status, reason } = req.body; // ACTIVE, WARNING, SUSPENDED, BLOCKED
    
    await prisma.user.update({
      where: { id },
      data: { status }
    });
    
    // Log reason if needed
    if (reason) {
      await prisma.activityLog.create({
        data: {
          userId: id,
          action: 'STATUS_CHANGE',
          details: `تغییر وضعیت به ${status}. دلیل: ${reason}`
        }
      });
    }
    
    res.json({ message: 'وضعیت با موفقیت تغییر یافت' });
  } catch (err) {
    res.status(500).json({ error: 'خطا در تغییر وضعیت' });
  }
});

app.get('/api/admin/suppliers', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const suppliers = await prisma.user.findMany({
      where: { role: 'SUPPLIER' },
      select: { id: true, firstName: true, lastName: true, brandName: true, status: true, mobile: true, }
    });

    const enrichedSuppliers = await Promise.all(suppliers.map(async (s: any) => {
      // Fetch penalties applied to this supplier
      const penalties = await prisma.supplierPenalty.findMany({
        where: { supplierId: s.id }
      });

      // Count specific penalty categories dynamically
      const delayCount = penalties.filter((p: any) => p.reason.includes("تاخیر") || p.reason.toLowerCase().includes("delay")).length;
      const cancelCount = penalties.filter((p: any) => p.reason.includes("لغو") || p.reason.toLowerCase().includes("cancel")).length;
      const returnCount = penalties.filter((p: any) => p.reason.includes("مرجوع") || p.reason.toLowerCase().includes("return")).length;

      // Seed deterministic satisfaction and response times based on supplier id
      const baseSatisfaction = s.id % 2 === 0 ? 98 : 94;
      const baseResponsiveness = s.id % 2 === 0 ? 95 : 97;

      const satisfaction = Math.max(70, baseSatisfaction - (cancelCount * 3) - (returnCount * 1.5));
      const responsiveness = Math.max(75, baseResponsiveness - (delayCount * 2));

      // Composite overall score from 100
      const totalPenaltyPoints = penalties.reduce((sum: number, p: any) => sum + p.points, 0);
      const scoreDeductions = (delayCount * 2) + (returnCount * 3) + (cancelCount * 4);
      const healthScore = Math.min(100, Math.max(10, 100 - totalPenaltyPoints - scoreDeductions));

      return {
        ...s,
        penaltiesCount: penalties.length,
        totalPenaltyPoints,
        healthMetrics: {
          delayCount,
          cancelCount,
          returnCount,
          satisfaction,
          responsiveness,
          healthScore
        }
      };
    }));

    res.json(enrichedSuppliers);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/stores', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const stores = await prisma.user.findMany({
      where: { role: 'STORE_MANAGER' },
      select: { id: true, firstName: true, lastName: true, storeName: true, status: true, mobile: true, }
    });
    res.json(stores);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/orders', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const orders = await prisma.order.findMany({
      include: {
        store: { select: { storeName: true, address: true, firstName: true, lastName: true, mobile: true } },
        items: { 
          include: { 
            product: {
              include: {
                supplier: { select: { id: true, brandName: true, firstName: true, lastName: true, address: true, mobile: true } }
              }
            } 
          } 
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'خطا در دریافت سفارشات' });
  }
});

app.patch('/api/admin/orders/:id/postal-label', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { postalLabel } = req.body;
    
    if (!postalLabel) {
      return res.status(400).json({ error: 'آدرس فایل یا توضیح لیبل پستی الزامی است.' });
    }

    const order = await prisma.order.update({
      where: { id: parseInt(id) },
      data: { postalLabel }
    });

    res.json({ message: 'لیبل پستی با موفقیت ثبت شد', order });
  } catch (err: any) {
    res.status(500).json({ error: 'خطا در ثبت لیبل پستی: ' + err.message });
  }
});



// --- Additional Super Admin API Routes ---
app.patch('/api/admin/suppliers/:id/status', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;
    const updated = await prisma.user.update({
      where: { id: parseInt(id) },
      data: { status }
    });
    // Log action
    await prisma.activityLog.create({
      data: { userId: req.user.userId, action: 'CHANGE_SUPPLIER_STATUS', details: `Supplier ${id} changed to ${status}. Reason: ${reason || 'none'}` }
    });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'خطا در تغییر وضعیت تامین کننده' });
  }
});

app.get('/api/admin/financial', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const totalRevenue = await prisma.storeInvoice.aggregate({ _sum: { totalAmount: true }, where: { status: 'PAID' } });
    const pendingStorePayments = await prisma.storeInvoice.aggregate({ _sum: { totalAmount: true }, where: { status: 'PENDING' } });
    const supplierWalletTotal = await prisma.wallet.aggregate({ _sum: { balance: true } });
    
    // Sum all pending order item revenues (where order is not PAID and order item is not cancelled/rejected)
    const pendingOrderItems = await prisma.orderItem.findMany({
      where: {
        order: {
          status: { not: 'PAID' }
        },
        status: { notIn: ['CANCELLED', 'REJECTED'] }
      },
      select: {
        quantity: true,
        supplierPrice: true
      }
    });
    const pendingSum = pendingOrderItems.reduce((acc, item) => acc + (item.quantity * item.supplierPrice), 0);
    
    res.json({
      totalRevenue: totalRevenue._sum.totalAmount || 0,
      pendingStorePayments: pendingStorePayments._sum.totalAmount || 0,
      supplierWalletBalance: supplierWalletTotal._sum.balance || 0,
      supplierWalletPending: pendingSum
    });
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/categories', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const cats = await prisma.category.findMany();
    res.json(cats);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.post('/api/admin/categories', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const cat = await prisma.category.create({ data: req.body });
    res.json(cat);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/tickets', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const tickets = await prisma.ticket.findMany({
      include: { 
        user: { select: { firstName: true, lastName: true, role: true } },
        messages: {
          include: {
            user: { select: { firstName: true, lastName: true, role: true } }
          },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(tickets);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.post('/api/admin/tickets/:id/reply', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { message } = req.body;
    const msg = await prisma.ticketMessage.create({
      data: { ticketId: parseInt(id), userId: req.user.userId, message }
    });
    await prisma.ticket.update({ where: { id: parseInt(id) }, data: { status: 'ANSWERED', updatedAt: new Date() } });
    res.json(msg);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/logs', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const logs = await prisma.activityLog.findMany({
      include: { user: { select: { username: true, role: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100
    });
    res.json(logs);
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});

app.get('/api/admin/health', authenticateToken, requireAdmin, async (req, res) => {
  try {
    res.json({
      status: 'OK',
      apiStatus: 'Online',
      dbStatus: 'Connected',
      serverTime: new Date().toISOString(),
      uptime: process.uptime()
    });
  } catch (err) {
    console.error(err); res.status(500).json({ error: 'خطا' });
  }
});



// ==========================================
// WooCommerce Integration Routes
// ==========================================

const rateLimitMap = new Map<string, { count: number, resetTime: number }>();
const wooRateLimiter = (req: any, res: any, next: any) => {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 20;

  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs });
    return next();
  }

  const record = rateLimitMap.get(ip)!;
  if (now > record.resetTime) {
    record.count = 1;
    record.resetTime = now + windowMs;
    return next();
  }

  record.count++;
  if (record.count > maxRequests) {
    return res.status(429).json({ error: 'Too many requests, please try again later.' });
  }
  next();
};

import { ConnectionService, SyncService, WebhookService, syncSingleOrder } from './src/services/integrations/woocommerce/index.js';

app.get('/api/store/connection', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const conn = await ConnectionService.getConnection(storeId);
    if (conn) {
      const logs = await prisma.syncLog.findMany({ where: { connectionId: conn.id }, orderBy: { createdAt: 'desc' }, take: 5 });
      res.json({ ...conn, syncLogs: logs });
    } else {
      res.json(null);
    }
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/store/test', wooRateLimiter, authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const { storeUrl, consumerKey, consumerSecret } = req.body;
    const result = await ConnectionService.testConnection(storeUrl, consumerKey, consumerSecret);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/store/connect', wooRateLimiter, authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const { storeUrl, consumerKey, consumerSecret } = req.body;
    const result = await ConnectionService.connect(storeId, storeUrl, consumerKey, consumerSecret);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/store/disconnect', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    await ConnectionService.disconnect(storeId);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/store/sync/products', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const result = await SyncService.runProductSync(storeId);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/store/sync/stock', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const result = await SyncService.runStockSync(storeId);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/store/sync/orders', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const result = await SyncService.runOrderSync(storeId);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/sync/order/:orderId', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId;
    const orderId = req.params.orderId;
    const result = await syncSingleOrder(storeId, orderId);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/webhooks/woocommerce', webhookLimiter, async (req: any, res: any) => {
  try {
    const signature = req.headers['x-wc-webhook-signature'];
    const storeId = req.query.store_id; // Pass store_id in query
    await WebhookService.handleWebhook(req.body, signature, Number(storeId));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});



// ==========================================
// Mock Payment Gateway Routes (Development Only)
// ==========================================
app.get('/api/mock/payment-callback', async (req, res) => {
  const { authority, status, callbackUrl } = req.query;
  
  // If no status is provided, we simulate a payment UI
  if (!status && authority && callbackUrl) {
    const record = mockPaymentStore.get(authority as string);
    const amount = record ? Number(record.amount) : 50000;
    const amountRials = amount * 10;

    const html = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>درگاه پرداخت اینترنتی بانک سامان (شبیه‌ساز)</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700;900&display=swap');
            * {
              box-sizing: border-box;
              font-family: 'Vazirmatn', Tahoma, sans-serif;
            }
            body {
              background-color: #f3f4f6;
              margin: 0;
              padding: 0;
              display: flex;
              flex-direction: column;
              min-height: 100vh;
              color: #1f2937;
            }
            header {
              background: linear-gradient(135deg, #1e3a8a, #0f172a);
              color: white;
              padding: 1.25rem 2rem;
              display: flex;
              justify-content: space-between;
              align-items: center;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }
            .header-title {
              display: flex;
              align-items: center;
              gap: 10px;
            }
            .header-title h1 {
              font-size: 1.25rem;
              margin: 0;
              font-weight: 900;
              letter-spacing: -0.5px;
            }
            .shaparak-logo {
              background-color: white;
              color: #1e3a8a;
              padding: 4px 8px;
              border-radius: 6px;
              font-weight: bold;
              font-size: 11px;
            }
            .container {
              max-width: 900px;
              width: 100%;
              margin: 2rem auto;
              padding: 0 1rem;
              flex: 1;
              display: grid;
              grid-template-columns: 1fr 1.3fr;
              gap: 2rem;
            }
            @media (max-width: 768px) {
              .container {
                grid-template-columns: 1fr;
                margin: 1rem auto;
              }
            }
            .info-card {
              background: white;
              border-radius: 20px;
              padding: 1.5rem;
              box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
              border: 1px solid #e5e7eb;
              height: fit-content;
            }
            .info-card h3 {
              margin-top: 0;
              font-size: 1rem;
              color: #4b5563;
              border-bottom: 2px solid #f3f4f6;
              padding-bottom: 0.75rem;
              margin-bottom: 1.25rem;
            }
            .info-row {
              display: flex;
              justify-content: space-between;
              margin-bottom: 1rem;
              font-size: 13px;
            }
            .info-label {
              color: #6b7280;
            }
            .info-value {
              font-weight: bold;
              color: #1f2937;
            }
            .amount-box {
              background-color: #f0fdf4;
              border: 1px dashed #bbf7d0;
              padding: 1rem;
              border-radius: 12px;
              text-align: center;
              margin-top: 1.5rem;
            }
            .amount-toman {
              font-size: 1.5rem;
              font-weight: 900;
              color: #166534;
            }
            .amount-rial {
              font-size: 12px;
              color: #15803d;
              margin-top: 4px;
            }
            .gateway-card {
              background: white;
              border-radius: 20px;
              padding: 2rem;
              box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
              border: 1px solid #e5e7eb;
            }
            .gateway-card h2 {
              margin-top: 0;
              font-size: 1.15rem;
              font-weight: 800;
              color: #1e3a8a;
              margin-bottom: 1.5rem;
            }
            .form-group {
              margin-bottom: 1.25rem;
            }
            .form-label {
              display: block;
              font-size: 12px;
              font-weight: bold;
              color: #374151;
              margin-bottom: 0.5rem;
            }
            .card-inputs {
              display: flex;
              gap: 8px;
              direction: ltr;
            }
            .card-inputs input {
              width: 25%;
              text-align: center;
              padding: 0.75rem;
              border: 1px solid #d1d5db;
              border-radius: 10px;
              font-weight: bold;
              font-size: 14px;
              background-color: #f9fafb;
            }
            .card-inputs input:focus {
              border-color: #3b82f6;
              outline: none;
              background-color: white;
            }
            .input-style {
              width: 100%;
              padding: 0.75rem;
              border: 1px solid #d1d5db;
              border-radius: 10px;
              font-weight: bold;
              font-size: 13px;
              background-color: #f9fafb;
              text-align: right;
            }
            .input-style:focus {
              border-color: #3b82f6;
              outline: none;
              background-color: white;
            }
            .input-style.ltr {
              direction: ltr;
              text-align: left;
            }
            .grid-cols-2 {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 1rem;
            }
            .otp-group {
              display: flex;
              gap: 8px;
            }
            .otp-btn {
              background-color: #e0f2fe;
              color: #0369a1;
              border: 1px solid #bae6fd;
              padding: 0.5rem 1rem;
              border-radius: 10px;
              font-size: 11px;
              font-weight: bold;
              cursor: pointer;
              white-space: nowrap;
              transition: all 0.2s;
            }
            .otp-btn:hover {
              background-color: #bae6fd;
            }
            .actions-row {
              display: flex;
              gap: 1rem;
              margin-top: 2rem;
            }
            .btn {
              flex: 1;
              padding: 0.85rem;
              border-radius: 12px;
              font-weight: bold;
              text-align: center;
              text-decoration: none;
              cursor: pointer;
              border: none;
              transition: all 0.2s;
              font-size: 14px;
            }
            .btn-pay {
              background-color: #10b981;
              color: white;
              box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.2);
            }
            .btn-pay:hover {
              background-color: #059669;
            }
            .btn-cancel {
              background-color: #ef4444;
              color: white;
              box-shadow: 0 4px 6px -1px rgba(239, 68, 68, 0.2);
            }
            .btn-cancel:hover {
              background-color: #dc2626;
            }
            .security-tips {
              margin-top: 1.5rem;
              background-color: #fffbeb;
              border: 1px solid #fef3c7;
              border-radius: 12px;
              padding: 1rem;
              font-size: 11px;
              color: #b45309;
              line-height: 1.6;
            }
            .security-tips ul {
              margin: 0;
              padding-right: 1.25rem;
            }
            footer {
              background-color: #e5e7eb;
              text-align: center;
              padding: 1.5rem;
              font-size: 11px;
              color: #6b7280;
              border-top: 1px solid #d1d5db;
            }
          </style>
        </head>
        <body>
          <header>
            <div class="header-title">
              <span class="shaparak-logo">شاپرک</span>
              <h1>درگاه پرداخت الکترونیک سامان</h1>
            </div>
            <div style="font-size: 11px; opacity: 0.8;">اتصال امن SSL</div>
          </header>

          <div class="container">
            <!-- Left Panel: Payment Info -->
            <div class="info-card">
              <h3>اطلاعات پرداخت</h3>
              
              <div class="info-row">
                <span class="info-label">پذیرنده:</span>
                <span class="info-value">سیستم مدیریت زنجیره تامین کالا</span>
              </div>
              
              <div class="info-row">
                <span class="info-label">کد رهگیری پذیرنده:</span>
                <span class="info-value" style="font-family: monospace;">${authority}</span>
              </div>

              <div class="info-row">
                <span class="info-label">کد صنف:</span>
                <span class="info-value">۵۷۹۹۰۲۴</span>
              </div>

              <div class="info-row">
                <span class="info-label">شماره تراکنش:</span>
                <span class="info-value" style="font-family: monospace;">TRX_${Math.floor(100000 + Math.random() * 900000)}</span>
              </div>

              <div class="amount-box">
                <div class="info-label" style="font-size: 11px; margin-bottom: 4px; color: #15803d;">مبلغ قابل پرداخت:</div>
                <div class="amount-toman">${amount.toLocaleString()} <span style="font-size: 14px; font-weight: normal;">تومان</span></div>
                <div class="amount-rial">${amountRials.toLocaleString()} ریال</div>
              </div>

              <div class="security-tips">
                <strong>توصیه‌های امنیتی مهم:</strong>
                <ul>
                  <li>هرگز رمزهای اول و دوم خود را در اختیار دیگران قرار ندهید.</li>
                  <li>این صفحه یک محیط شبیه‌سازی شده تراکنش‌های امن زنجیره تامین است.</li>
                  <li>کد رمز پویا صرفاً جهت ورود آزمایشی شبیه‌سازی شده است.</li>
                </ul>
              </div>
            </div>

            <!-- Right Panel: Gateway Card Form -->
            <div class="gateway-card">
              <h2>ورود اطلاعات کارت بانکی</h2>
              
              <div class="form-group">
                <label class="form-label">شماره کارت ۱۶ رقمی</label>
                <div class="card-inputs">
                  <input type="text" maxlength="4" placeholder="5022" id="c1" onkeyup="moveFocus('c1', 'c2')">
                  <input type="text" maxlength="4" placeholder="2910" id="c2" onkeyup="moveFocus('c2', 'c3')">
                  <input type="text" maxlength="4" placeholder="1234" id="c3" onkeyup="moveFocus('c3', 'c4')">
                  <input type="text" maxlength="4" placeholder="5678" id="c4">
                </div>
              </div>

              <div class="grid-cols-2">
                <div class="form-group">
                  <label class="form-label">کد امنیتی CVV2</label>
                  <input type="password" maxlength="4" placeholder="••••" class="input-style ltr" style="letter-spacing: 4px;">
                </div>
                
                <div class="form-group">
                  <label class="form-label">تاریخ انقضای کارت</label>
                  <div style="display: flex; gap: 4px; direction: ltr;">
                    <input type="text" maxlength="2" placeholder="ماه" class="input-style" style="text-align: center; width: 50%;">
                    <input type="text" maxlength="2" placeholder="سال" class="input-style" style="text-align: center; width: 50%;">
                  </div>
                </div>
              </div>

              <div class="form-group">
                <label class="form-label">رمز دوم (رمز پویا)</label>
                <div class="otp-group">
                  <input type="text" id="otp-input" placeholder="کد رمز یکبار مصرف" class="input-style ltr" style="flex: 1;">
                  <button type="button" class="otp-btn" id="otp-btn" onclick="requestOtp()">درخواست رمز پویا</button>
                </div>
                <div id="otp-alert" style="display: none; font-size: 11px; color: #16a34a; font-weight: bold; margin-top: 6px;">
                  رمز ایستای آزمایشی به شماره همراه شما ارسال شد: <span id="otp-code">123456</span>
                </div>
              </div>

              <div class="actions-row">
                <a href="/api/mock/payment-callback?authority=${authority}&status=success&callbackUrl=${encodeURIComponent(callbackUrl as string)}" class="btn btn-pay">تایید و پرداخت</a>
                <a href="/api/mock/payment-callback?authority=${authority}&status=failed&callbackUrl=${encodeURIComponent(callbackUrl as string)}" class="btn btn-cancel">انصراف از پرداخت</a>
              </div>
            </div>
          </div>

          <footer>
            کلیه حقوق این درگاه شبیه‌ساز امن متعلق به سامانه هوشمند زنجیره تامین و بستر شبکه بانکی شاپرک می‌باشد.
          </footer>

          <script>
            function moveFocus(currentId, nextId) {
              const currentInput = document.getElementById(currentId);
              if (currentInput.value.length === 4) {
                document.getElementById(nextId).focus();
              }
            }

            function requestOtp() {
              const code = Math.floor(100000 + Math.random() * 900000);
              document.getElementById('otp-code').innerText = code;
              document.getElementById('otp-input').value = code;
              document.getElementById('otp-alert').style.display = 'block';
              document.getElementById('otp-btn').innerText = 'ارسال مجدد رمز';
            }
          </script>
        </body>
      </html>
    `;
    res.send(html);
    return;
  }

  // Handle the simulation callback
  if (authority && typeof authority === 'string') {
    const record = mockPaymentStore.get(authority);
    if (record) {
      record.status = status === 'failed' ? 'failed' : 'success';
    }
  }
  
  if (callbackUrl && typeof callbackUrl === 'string') {
    res.redirect(`${callbackUrl}?Authority=${authority}&Status=${status === 'success' ? 'OK' : 'NOK'}`);
  } else {
    res.json({ message: 'Mock payment processed', authority, status });
  }
});

async function startServer() {
  NotificationService.init();
  FinancialJobs.start();

  // Start Express Server
  const PORT = 3000;

// --- Financial Engine Routes ---
const paymentService = new PaymentLifecycleService();

app.post('/api/financial/payments/initiate', authenticateToken, async (req: any, res: any) => {
  try {
    const data = initiatePaymentSchema.parse(req.body);
    const result = await paymentService.initiatePayment(req.user.userId, data.amount, data.callbackUrl);
    res.json(result);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.issues });
    }
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/financial/payments/callback', async (req: any, res: any) => {
  try {
    const { trackId, success, status } = req.query; // Zibal uses trackId
    if (!trackId) {
      return res.status(400).json({ error: 'Missing trackId' });
    }

    // Since we don't have the user ID from the callback directly, we can use 0 or lookup from payment
    // Zibal callback doesn't have auth, so we just pass a system user 0, but IP is available.
    const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    
    // We pass 0 for userId as this is a system-level verification via callback
    const result = await paymentService.verifyPayment(trackId.toString(), 0, ipAddress?.toString() || '');
    
    // Redirect to frontend success page
    if (result.payment.status === 'PAID') {
      res.redirect(`/?payment_status=success&trackId=${trackId}`);
    } else {
      res.redirect(`/?payment_status=failed&trackId=${trackId}`);
    }
  } catch (err: any) {
    res.redirect(`/?payment_status=error&message=${encodeURIComponent(err.message)}`);
  }
});

app.post('/api/financial/payments/:id/refund', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const result = await paymentService.refundPayment(id, req.user.userId);
    res.json({ success: true, payment: result });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/financial/reports', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const query = reportQuerySchema.parse(req.query);
    const pageNum = parseInt(query.page);
    const limitNum = parseInt(query.limit);
    
    const whereClause: any = {};
    if (query.status) whereClause.status = query.status;
    if (query.startDate && query.endDate) {
      whereClause.createdAt = {
        gte: new Date(query.startDate),
        lte: new Date(query.endDate)
      };
    }

    const payments = await prisma.payment.findMany({
      where: whereClause,
      include: { user: { select: { id: true, username: true, role: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (pageNum - 1) * limitNum,
      take: limitNum
    });

    const total = await prisma.payment.count({ where: whereClause });

    // Also get settlements
    const settlements = await prisma.settlement.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { supplier: { select: { id: true, username: true, brandName: true } } }
    });

    res.json({
      payments,
      settlements,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.issues });
    }
    res.status(500).json({ error: err.message });
  }
});

  
// =========================================================================
// MANUAL ORDERS (STORE MANAGER)
// =========================================================================
app.post('/api/store-manager/orders', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const { productId, quantity, notes, shippingAddressType, shippingAddress, shippingMethod, postalLabel } = req.body;
    
    console.log('Order creation request received:', { storeId, productId, quantity, notes, shippingAddressType, shippingAddress, shippingMethod, postalLabel });
    
    if (!productId || !quantity) {
      return res.status(400).json({ error: 'شناسه محصول و تعداد الزامی هستند.' });
    }

    if (shippingMethod === 'PERSONAL_PANEL' && !postalLabel) {
      return res.status(400).json({ error: 'برای استفاده از پنل پستی شخصی، بارگذاری لیبل پستی الزامی است.' });
    }
    
    const parsedProductId = parseInt(productId);
    if (isNaN(parsedProductId)) {
      return res.status(400).json({ error: 'شناسه محصول نامعتبر است.' });
    }
    
    const product = await prisma.product.findUnique({ where: { id: parsedProductId } });
    if (!product) return res.status(404).json({ error: 'محصول یافت نشد' });
    
    const qty = parseInt(quantity);
    if (isNaN(qty) || qty <= 0) {
      return res.status(400).json({ error: 'تعداد سفارش نامعتبر است.' });
    }
    
    if (product.inventory < qty) {
      return res.status(400).json({ error: `موجودی کافی نیست. موجودی فعلی: ${product.inventory}` });
    }
    
    const defaultCommission = await getSystemConfig("COMMISSION_PERCENTAGE", 10);
    let finalPrice = product.finalPrice;
    if (!finalPrice) {
      if (product.marginType === 'PERCENTAGE' && product.marginValue) {
        finalPrice = product.supplierBasePrice * (1 + product.marginValue / 100);
      } else if (product.marginType === 'FIXED' && product.marginValue) {
        finalPrice = product.supplierBasePrice + product.marginValue;
      } else {
        finalPrice = product.supplierBasePrice * (1 + defaultCommission / 100);
      }
    }
    
    const totalAmount = finalPrice * qty;

    const storeUser = await prisma.user.findUnique({ where: { id: storeId } });
    let resolvedShippingAddress = shippingAddress;
    if (shippingAddressType === 'STORE_ADDRESS') {
      resolvedShippingAddress = storeUser?.address || 'آدرس ثبت نشده در مشخصات فروشگاه';
    }
    
    const newOrder = await prisma.order.create({
      data: {
        storeId,
        totalAmount,
        status: 'REQUESTED',
        shippingAddressType: shippingAddressType || 'OTHER_ADDRESS',
        shippingAddress: resolvedShippingAddress || '',
        shippingMethod: shippingMethod || 'PLATFORM_PANEL',
        postalLabel: postalLabel || null,
        items: {
          create: {
            supplierId: product.supplierId,
            productId: product.id,
            status: 'REQUESTED',
            quantity: qty,
            notes: notes || null,
            price: finalPrice,
            supplierPrice: product.supplierBasePrice
          }
        }
      },
      include: { items: true }
    });
    
    // Notify supplier
    await prisma.notification.create({
      data: {
        userId: product.supplierId,
        title: 'سفارش جدید',
        message: 'شما یک سفارش جدید دارید (منتظر تایید)',
        isRead: false
      }
    });
    
    res.json(newOrder);
  } catch (err: any) {
    console.error('Error in order creation:', err);
    res.status(500).json({ error: err.message || 'خطای سرور در ثبت سفارش' });
  }
});

app.post('/api/store-manager/orders/:orderId/pay', authenticateToken, requireStoreManager, async (req: any, res: any) => {
  try {
    const storeId = req.user.userId || req.user.id;
    const { orderId } = req.params;
    
    const order = await prisma.order.findFirst({
      where: { id: parseInt(orderId), storeId },
      include: { items: true }
    });
    
    if (!order) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (order.status !== 'SUPPLIER_APPROVED' && order.status !== 'WAITING_FOR_PAYMENT') {
      return res.status(400).json({ error: 'سفارش در وضعیت پرداخت نیست' });
    }
    
    await prisma.$transaction(async (tx) => {
      await tx.order.update({
        where: { id: order.id },
        data: { status: 'PAID' }
      });
      
      const idempotencyKey = `PAY_ORD_${order.id}_${Date.now()}`;
      
      const payment = await tx.payment.create({
        data: {
          amount: order.totalAmount,
          userId: storeId,
          idempotencyKey,
          status: 'PAID',
          gatewayReference: `ZIBAL_MOCK_${Date.now()}`
        }
      });
      
      await tx.transactionLog.create({
        data: {
          paymentId: payment.id,
          action: 'PAYMENT_SUCCESS',
          payload: 'پرداخت دستی سفارش توسط مدیر فروشگاه (Mock Zibal)'
        }
      });
      
      await tx.auditTrail.create({
         data: {
           actorId: storeId,
           action: 'ORDER_PAYMENT',
           resource: 'ORDER',
           metadata: JSON.stringify({ orderId: order.id, amount: order.totalAmount })
         }
      });
      
      for (const item of order.items) {
        await tx.orderItem.update({
          where: { id: item.id },
          data: { status: 'PAID' }
        });
        
        let wallet = await tx.wallet.findUnique({ where: { supplierId: item.supplierId } });
        if (!wallet) {
          wallet = await tx.wallet.create({ data: { supplierId: item.supplierId, balance: 0 } });
        }
        
        const supplierAmount = item.supplierPrice * item.quantity;
        
        await tx.ledgerEntry.create({
          data: {
            walletId: wallet.id,
            type: 'ORDER_REVENUE',
            amount: supplierAmount,
            description: `سهم فروش از سفارش #${order.id}`,
            status: 'COMPLETED',
            referenceId: `ORDER_${order.id}`
          }
        });
        
        await tx.supplierPayable.create({
          data: {
            supplierId: item.supplierId,
            paymentId: payment.id,
            amount: supplierAmount,
            status: 'PENDING'
          }
        });
        
        await tx.wallet.update({
          where: { id: wallet.id },
          data: { balance: { increment: supplierAmount } }
        });
      }
    });
    
    res.json({ message: 'پرداخت با موفقیت انجام شد' });
  } catch(e) {
     console.error(e);
     res.status(500).json({ error: 'Server error' });
  }
});

// =========================================================================
// SUPPLIER ORDER ACTIONS (APPROVE/REJECT)
// =========================================================================
app.post('/api/supplier/orders/approve-batch', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { itemIds } = req.body;
    const supplierId = req.user.userId || req.user.id;
    
    if (!itemIds || !Array.isArray(itemIds) || itemIds.length === 0) {
      return res.status(400).json({ error: 'هیچ سفارشی انتخاب نشده است' });
    }

    const items = await prisma.orderItem.findMany({
      where: {
        id: { in: itemIds.map(id => parseInt(id)) },
        supplierId
      },
      include: { order: true }
    });

    if (items.length === 0) {
      return res.status(404).json({ error: 'سفارشات یافت نشدند' });
    }

    // Filter items that are in REQUESTED or PENDING status
    const pendingItems = items.filter(item => item.status === 'REQUESTED' || item.status === 'PENDING');
    if (pendingItems.length === 0) {
      return res.status(400).json({ error: 'سفارشات انتخاب شده قبلا بررسی شده‌اند' });
    }

    // Check inventory for all items
    for (const item of pendingItems) {
      const product = await prisma.product.findUnique({ where: { id: item.productId } });
      if (!product || product.inventory < item.quantity) {
        return res.status(400).json({ error: `موجودی برای محصول ${product?.name || 'کالا'} کافی نیست` });
      }
    }

    // Approve them inside a transaction with optimization
    await prisma.$transaction(async (tx) => {
      // 1. Bulk update OrderItem status
      await tx.orderItem.updateMany({
        where: { id: { in: pendingItems.map(item => item.id) } },
        data: { status: 'SUPPLIER_APPROVED' }
      });

      // 2. Bulk update Order status
      const uniqueOrderIds = Array.from(new Set(pendingItems.map(item => item.orderId)));
      await tx.order.updateMany({
        where: { id: { in: uniqueOrderIds } },
        data: { status: 'SUPPLIER_APPROVED' }
      });

      // 3. Bulk create Notifications
      const uniqueOrders: { storeId: number; orderId: number }[] = [];
      const seenOrderIds = new Set<number>();
      for (const item of pendingItems) {
        if (!seenOrderIds.has(item.orderId)) {
          seenOrderIds.add(item.orderId);
          uniqueOrders.push({
            storeId: item.order.storeId,
            orderId: item.orderId
          });
        }
      }

      await tx.notification.createMany({
        data: uniqueOrders.map(o => ({
          userId: o.storeId,
          title: 'تایید سفارش',
          message: `سفارش #${o.orderId} توسط تامین‌کننده تایید شد و آماده پرداخت است.`,
          isRead: false
        }))
      });
    }, { maxWait: 15000, timeout: 30000 });

    res.json({ message: 'تمامی سفارشات با موفقیت تایید شدند.' });
  } catch (e: any) {
    console.error('Error in batch approval:', e);
    res.status(500).json({ error: 'خطای سرور در تایید گروهی سفارشات' });
  }
});

app.post('/api/supplier/orders/:itemId/approve', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { itemId } = req.params;
    const supplierId = req.user.userId || req.user.id;
    
    const item = await prisma.orderItem.findFirst({
      where: { id: parseInt(itemId), supplierId },
      include: { order: true }
    });
    
    if (!item) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (item.status !== 'REQUESTED') return res.status(400).json({ error: 'وضعیت سفارش نامعتبر است' });
    
    const product = await prisma.product.findUnique({ where: { id: item.productId } });
    if (!product || product.inventory < item.quantity) {
      return res.status(400).json({ error: 'موجودی کافی نیست' });
    }

    await prisma.$transaction(async (tx) => {
      await tx.orderItem.update({
        where: { id: item.id },
        data: { status: 'SUPPLIER_APPROVED' }
      });
      
      await tx.order.update({
        where: { id: item.orderId },
        data: { status: 'SUPPLIER_APPROVED' }
      });
    });
    
    await prisma.notification.create({
      data: {
        userId: item.order.storeId,
        title: 'تایید سفارش',
        message: `سفارش #${item.orderId} توسط تامین‌کننده تایید شد و آماده پرداخت است.`,
        isRead: false
      }
    });
    
    res.json({ message: 'سفارش تایید شد' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

app.post('/api/supplier/orders/:itemId/reject', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const { itemId } = req.params;
    const supplierId = req.user.userId || req.user.id;
    
    const item = await prisma.orderItem.findFirst({
      where: { id: parseInt(itemId), supplierId },
      include: { order: true }
    });
    
    if (!item) return res.status(404).json({ error: 'سفارش یافت نشد' });
    if (item.status !== 'REQUESTED') return res.status(400).json({ error: 'وضعیت سفارش نامعتبر است' });
    
    await prisma.orderItem.update({
      where: { id: item.id },
      data: { status: 'REJECTED' }
    });
    
    await prisma.order.update({
      where: { id: item.orderId },
      data: { status: 'REJECTED' }
    });
    
    await prisma.notification.create({
      data: {
        userId: item.order.storeId,
        title: 'رد سفارش',
        message: `متاسفانه سفارش #${item.orderId} توسط تامین‌کننده رد شد.`,
        isRead: false
      }
    });
    
    res.json({ message: 'سفارش رد شد' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور' });
  }
});


// Banners API
app.get('/api/banners', async (req: any, res: any) => {
  try {
    const banners = await prisma.banner.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(banners);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/banners', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { title, description, imageUrl, isActive } = req.body;
    const banner = await prisma.banner.create({
      data: { title, description, imageUrl, isActive }
    });
    res.status(201).json(banner);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/banners/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const id = parseInt(req.params.id);
    const { title, description, imageUrl, isActive } = req.body;
    const banner = await prisma.banner.update({
      where: { id },
      data: { title, description, imageUrl, isActive }
    });
    res.json(banner);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/banners/:id', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const id = parseInt(req.params.id);
    await prisma.banner.delete({ where: { id } });
    res.json({ message: 'Deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});


  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

app.listen(PORT, '0.0.0.0', async () => {
    console.log(`🚀 Backend Express server running on port ${PORT}`);
    await seedSuperAdmin();
  });
}

startServer();
