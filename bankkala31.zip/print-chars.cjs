const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');
const line = lines[246]; // index 246 is line 247

console.log('Line 247 length:', line.length);
console.log('Around index 224:');
for (let i = Math.max(0, 224 - 50); i < Math.min(line.length, 224 + 50); i++) {
  const marker = (i === 224) ? ' => [224]' : (i === 225) ? ' => [225]' : (i === 234) ? ' => [234]' : '';
  console.log(`${i}: ${JSON.stringify(line[i])}${marker}`);
}
