import fs from 'fs';
import { execSync } from 'child_process';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// We want to replace the end of the wallet tab block
// Original segment before {activeTab ==='add-product'
const target = " </form> )} </div> </div> )} {/* ADD PRODUCT TAB */}";
const replacement = " </form> )} </div> </div> ) )}$ {/* ADD PRODUCT TAB */}";

// Let's check if the target exists
if (content.includes(target)) {
  console.log('Found target end of wallet tab!');
  const updatedContent = content.replace(target, " </form> )} </div> </div> ) )}$ {/* ADD PRODUCT TAB */}").replace(')$', ')');
  fs.writeFileSync(filePath, updatedContent, 'utf8');
  console.log('Modified file with the closing parenthesis.');
  
  // Try running prettier
  try {
    execSync('npx prettier --check src/components/supplier/SupplierDashboard.tsx', { stdio: 'pipe' });
    console.log('Prettier validation succeeded!');
  } catch (err) {
    console.error('Prettier validation failed with error:');
    console.error(err.stderr?.toString() || err.message);
  }
} else {
  console.log('Target end of wallet tab not found. Let\'s search for it.');
}
