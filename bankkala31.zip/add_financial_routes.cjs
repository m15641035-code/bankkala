const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

const imports = `
import { z } from 'zod';
import { PaymentLifecycleService } from './src/services/financial/PaymentLifecycleService.js';
import { initiatePaymentSchema, refundPaymentSchema, reportQuerySchema } from './src/validators/financial.js';
`;
code = code.replace("import { createServer as createViteServer } from 'vite';", "import { createServer as createViteServer } from 'vite';\n" + imports);

const financialRoutes = `
// --- Financial Engine Routes ---
const paymentService = new PaymentLifecycleService();

app.post('/api/financial/payments/initiate', authenticateToken, async (req: any, res: any) => {
  try {
    const data = initiatePaymentSchema.parse(req.body);
    const result = await paymentService.initiatePayment(req.user.userId, data.amount, data.callbackUrl);
    res.json(result);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.errors });
    }
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/financial/payments/callback', async (req: any, res: any) => {
  try {
    const { trackId, success, status } = req.query; // Zibal uses trackId
    if (!trackId) {
      return res.status(400).json({ error: 'Missing trackId' });
    }

    // Since we don't have the user ID from the callback directly, we can use 0 or lookup from payment
    // Zibal callback doesn't have auth, so we just pass a system user 0, but IP is available.
    const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    
    // We pass 0 for userId as this is a system-level verification via callback
    const result = await paymentService.verifyPayment(trackId.toString(), 0, ipAddress?.toString() || '');
    
    // Redirect to frontend success page
    if (result.payment.status === 'PAID') {
      res.redirect(\`/?payment_status=success&trackId=\${trackId}\`);
    } else {
      res.redirect(\`/?payment_status=failed&trackId=\${trackId}\`);
    }
  } catch (err: any) {
    res.redirect(\`/?payment_status=error&message=\${encodeURIComponent(err.message)}\`);
  }
});

app.post('/api/financial/payments/:id/refund', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const { id } = req.params;
    const result = await paymentService.refundPayment(id, req.user.userId);
    res.json({ success: true, payment: result });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/financial/reports', authenticateToken, requireAdmin, async (req: any, res: any) => {
  try {
    const query = reportQuerySchema.parse(req.query);
    const pageNum = parseInt(query.page);
    const limitNum = parseInt(query.limit);
    
    const whereClause: any = {};
    if (query.status) whereClause.status = query.status;
    if (query.startDate && query.endDate) {
      whereClause.createdAt = {
        gte: new Date(query.startDate),
        lte: new Date(query.endDate)
      };
    }

    const payments = await prisma.payment.findMany({
      where: whereClause,
      include: { user: { select: { id: true, username: true, role: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (pageNum - 1) * limitNum,
      take: limitNum
    });

    const total = await prisma.payment.count({ where: whereClause });

    // Also get settlements
    const settlements = await prisma.settlement.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { supplier: { select: { id: true, username: true, brandName: true } } }
    });

    res.json({
      payments,
      settlements,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.errors });
    }
    res.status(500).json({ error: err.message });
  }
});
`;

code = code.replace("  app.listen(PORT, '0.0.0.0', async () => {", financialRoutes + "\n  app.listen(PORT, '0.0.0.0', async () => {");
fs.writeFileSync('server.ts', code);
