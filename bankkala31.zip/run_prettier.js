import prettier from 'prettier';
import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

try {
  prettier.format(content, { filepath: filePath });
  console.log('Prettier format success!');
} catch (err) {
  console.error('Prettier format failed:');
  console.error(err.message || err);
}
