const fs = require('fs');

let code = fs.readFileSync('src/components/supplier/SupplierDashboard.tsx', 'utf8');

const targetMethodStr = `  const updateOrderStatus = async (itemId: number, newStatus: string) => {
    try {
      const res = await fetch(\`/api/supplier/orders/\${itemId}\`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${localStorage.getItem('token')}\`
        },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setOrders(orders.map(o => o.id === itemId ? { ...o, status: newStatus } : o));
      }
    } catch (err) {
      console.error(err);
    }
  };`;

const newMethodStr = `  const updateOrderStatus = async (itemId: number, newStatus: string) => {
    try {
      const res = await fetch(\`/api/supplier/orders/\${itemId}\`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${localStorage.getItem('token')}\`
        },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setOrders(orders.map(o => o.id === itemId ? { ...o, status: newStatus } : o));
      }
    } catch (err) {
      console.error(err);
    }
  };
  
  const approveOrder = async (itemId: number) => {
    try {
      const res = await fetch(\`/api/supplier/orders/\${itemId}/approve\`, {
        method: 'POST',
        headers: {
          'Authorization': \`Bearer \${localStorage.getItem('token')}\`
        }
      });
      if (res.ok) {
        setOrders(orders.map(o => o.id === itemId ? { ...o, status: 'SUPPLIER_APPROVED' } : o));
      }
    } catch (err) {
      console.error(err);
    }
  };
  
  const rejectOrder = async (itemId: number) => {
    try {
      const res = await fetch(\`/api/supplier/orders/\${itemId}/reject\`, {
        method: 'POST',
        headers: {
          'Authorization': \`Bearer \${localStorage.getItem('token')}\`
        }
      });
      if (res.ok) {
        setOrders(orders.map(o => o.id === itemId ? { ...o, status: 'REJECTED' } : o));
      }
    } catch (err) {
      console.error(err);
    }
  };`;

code = code.replace(targetMethodStr, newMethodStr);

const targetRenderStr = `                              <td className="px-6 py-4">
                                <span className={\`px-2.5 py-1 rounded-full text-xs font-semibold \${
                                  order.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                                  order.status === 'PROCESSING' ? 'bg-blue-100 text-blue-700' :
                                  order.status === 'SHIPPED' ? 'bg-purple-100 text-purple-700' :
                                  'bg-emerald-100 text-emerald-700'
                                }\`}>
                                  {order.status === 'PENDING' ? 'در انتظار بررسی' :
                                   order.status === 'PROCESSING' ? 'در حال پردازش' :
                                   order.status === 'SHIPPED' ? 'ارسال شده' : 'تحویل شده'}
                                </span>
                              </td>
                              <td className="px-6 py-4 font-mono text-slate-600 text-xs">
                                {order.trackingCode || '-'}
                              </td>
                              <td className="px-6 py-4">
                                {order.status === 'PENDING' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'PROCESSING')}
                                    className="text-xs bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    تایید و پردازش
                                  </button>
                                )}
                                {order.status === 'PROCESSING' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'SHIPPED')}
                                    className="text-xs bg-purple-50 text-purple-600 hover:bg-purple-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    ثبت ارسال
                                  </button>
                                )}
                              </td>`;

const newRenderStr = `                              <td className="px-6 py-4">
                                <span className={\`px-2.5 py-1 rounded-full text-xs font-semibold \${
                                  order.status === 'REQUESTED' ? 'bg-amber-100 text-amber-700' :
                                  order.status === 'SUPPLIER_APPROVED' ? 'bg-blue-100 text-blue-700' :
                                  order.status === 'WAITING_FOR_PAYMENT' ? 'bg-purple-100 text-purple-700' :
                                  order.status === 'PAID' ? 'bg-emerald-100 text-emerald-700' :
                                  order.status === 'PREPARING' ? 'bg-indigo-100 text-indigo-700' :
                                  order.status === 'REJECTED' ? 'bg-red-100 text-red-700' :
                                  order.status === 'CANCELLED' ? 'bg-rose-100 text-rose-700' :
                                  'bg-emerald-100 text-emerald-700'
                                }\`}>
                                  {order.status === 'REQUESTED' ? 'درخواست شده' :
                                   order.status === 'SUPPLIER_APPROVED' ? 'تایید تامین‌کننده' :
                                   order.status === 'WAITING_FOR_PAYMENT' ? 'در انتظار پرداخت' :
                                   order.status === 'PAID' ? 'پرداخت شده' :
                                   order.status === 'PREPARING' ? 'در حال آماده‌سازی' :
                                   order.status === 'COMPLETED' ? 'تکمیل شده' :
                                   order.status === 'REJECTED' ? 'رد شده' :
                                   order.status === 'CANCELLED' ? 'لغو شده' : order.status}
                                </span>
                              </td>
                              <td className="px-6 py-4 font-mono text-slate-600 text-xs">
                                {order.trackingCode || '-'}
                              </td>
                              <td className="px-6 py-4 space-x-2 space-x-reverse">
                                {order.status === 'REQUESTED' && (
                                  <>
                                    <button 
                                      onClick={() => approveOrder(order.id)}
                                      className="text-xs bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                    >
                                      تایید سفارش
                                    </button>
                                    <button 
                                      onClick={() => rejectOrder(order.id)}
                                      className="text-xs bg-red-50 text-red-600 hover:bg-red-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                    >
                                      رد سفارش
                                    </button>
                                  </>
                                )}
                                {order.status === 'PAID' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'PREPARING')}
                                    className="text-xs bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    در حال آماده‌سازی
                                  </button>
                                )}
                                {order.status === 'PREPARING' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'COMPLETED')}
                                    className="text-xs bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    تکمیل سفارش
                                  </button>
                                )}
                              </td>`;

code = code.replace(targetRenderStr, newRenderStr);
fs.writeFileSync('src/components/supplier/SupplierDashboard.tsx', code);
