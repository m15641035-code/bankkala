import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

const idx = line339.indexOf("activeTab ==='wallet'");
console.log('Wallet Tab start:');
console.log(line339.substring(idx - 50, idx + 250));
