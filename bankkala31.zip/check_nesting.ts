import ts from 'typescript';
import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const scanner = ts.createScanner(ts.ScriptTarget.Latest, true);
scanner.setText(content);

const stack: any[] = [];
const errors: string[] = [];

let token = scanner.scan();
while (token !== ts.SyntaxKind.EndOfFileToken) {
  const pos = scanner.getTokenPos();
  const beforeText = content.substring(0, pos);
  const line = beforeText.split('\n').length;
  
  if (token === ts.SyntaxKind.OpenParen) {
    stack.push({ type: 'paren', line, pos });
  } else if (token === ts.SyntaxKind.CloseParen) {
    if (stack.length === 0) {
      errors.push(`Extra Close Paren at Line ${line}`);
    } else {
      const top = stack.pop();
      if (top.type !== 'paren') {
        errors.push(`Nesting Violation: Closed Parenthesis ')' on Line ${line}, but open Curly Brace '{' from Line ${top.line} was on top of stack.`);
      }
    }
  } else if (token === ts.SyntaxKind.OpenBrace) {
    stack.push({ type: 'brace', line, pos });
  } else if (token === ts.SyntaxKind.CloseBrace) {
    if (stack.length === 0) {
      errors.push(`Extra Close Brace at Line ${line}`);
    } else {
      const top = stack.pop();
      if (top.type !== 'brace') {
        errors.push(`Nesting Violation: Closed Curly Brace '}' on Line ${line}, but open Parenthesis '(' from Line ${top.line} was on top of stack.`);
      }
    }
  }
  
  token = scanner.scan();
}

console.log(`Found ${errors.length} nesting/matching errors:`);
errors.forEach(err => console.log(err));

console.log(`\nRemaining open stack size: ${stack.length}`);
if (stack.length > 0) {
  console.log('Open elements:');
  stack.forEach((item, idx) => {
    console.log(`${idx + 1}. ${item.type === 'paren' ? '(' : '{'} opened on Line ${item.line}`);
  });
}
