import fs from 'fs';

const content = fs.readFileSync('./src/components/supplier/SupplierDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line339 = lines[338];
console.log('Line 339 last 1000 chars:');
console.log(line339.substring(line339.length - 1000));
