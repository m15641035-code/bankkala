import fs from 'fs';
import path from 'path';

function walk(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walk(dirPath, callback) : callback(path.join(dir, f));
  });
}

const colorMap = {
  // Backgrounds
  'bg-white': 'bg-card',
  'bg-slate-50': 'bg-background',
  'bg-slate-100': 'bg-surface',
  'bg-slate-200': 'bg-surface',
  'bg-slate-800': 'bg-surface',
  'bg-slate-900': 'bg-background',
  
  // Text
  'text-slate-900': 'text-primary',
  'text-slate-800': 'text-primary',
  'text-gray-900': 'text-primary',
  'text-gray-800': 'text-primary',
  'text-slate-700': 'text-secondary',
  'text-gray-700': 'text-secondary',
  'text-slate-600': 'text-muted',
  'text-slate-500': 'text-muted',
  'text-gray-600': 'text-muted',
  'text-gray-500': 'text-muted',
  'text-slate-400': 'text-muted',
  'text-white': 'text-inverse',
  'text-slate-50': 'text-inverse',
  'text-slate-100': 'text-inverse',

  // Borders
  'border-slate-100': 'border-subtle',
  'border-slate-200': 'border-subtle',
  'border-slate-300': 'border-default',
  'border-slate-400': 'border-default',
  'border-slate-600': 'border-default',
  'border-slate-700': 'border-default',
  'border-slate-800': 'border-subtle',
};

const removeDarkRegex = /dark:(bg|text|border)-(slate|gray|white|black)[-\w]*(?:\/[0-9]+)?/g;
const removeHoverDarkRegex = /dark:hover:(bg|text|border)-(slate|gray|white|black)[-\w]*(?:\/[0-9]+)?/g;

walk('src', (filepath) => {
  if (!filepath.endsWith('.tsx') && !filepath.endsWith('.ts')) return;
  let content = fs.readFileSync(filepath, 'utf8');
  let original = content;

  // Remove dark: variants of hardcoded colors we are replacing
  content = content.replace(removeDarkRegex, '');
  content = content.replace(removeHoverDarkRegex, '');

  // Replace light mode hardcoded colors
  for (const [oldClass, newClass] of Object.entries(colorMap)) {
    // regex to match the exact class name
    const regex = new RegExp(`(?<![a-zA-Z0-9:-])` + oldClass + `(?![a-zA-Z0-9-])`, 'g');
    content = content.replace(regex, newClass);
  }
  
  // Also clean up multiple spaces left by removal
  content = content.replace(/className=(["'`])\s+/g, 'className=$1');
  content = content.replace(/\s+(["'`])/g, '$1');
  content = content.replace(/\s{2,}/g, ' ');

  if (content !== original) {
    fs.writeFileSync(filepath, content, 'utf8');
  }
});
console.log('Refactoring complete.');
