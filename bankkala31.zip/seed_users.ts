import { PrismaClient } from '@prisma/client';
import bcryptjs from 'bcryptjs';

const prisma = new PrismaClient();

const CATEGORIES = [
  'موبایل', 'لپ‌تاپ', 'کالای دیجیتال', 'خانه و آشپزخانه', 'لوازم خانگی برقی',
  'آرایشی و بهداشتی', 'مد و پوشاک', 'طلا و نقره', 'خودرو و موتورسیکلت',
  'سلامت و پزشکی', 'ابزارآلات و تجهیزات', 'کتاب و هنر', 'ورزش و سفر',
  'اسباب بازی کودک و نوزاد', 'محصولات بومی و محلی', 'پت شاپ'
];

async function main() {
  console.log('🌱 Seeding database with active accounts...');

  const passwordHash = await bcryptjs.hash('Bahankala@2026!', 10);

  // 1. Create or Update Super Admin
  const superAdmin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {
      password: passwordHash,
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      firstName: 'مدیر',
      lastName: 'ارشد',
    },
    create: {
      username: 'admin',
      password: passwordHash,
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      firstName: 'مدیر',
      lastName: 'ارشد',
      email: 'admin@marketplace.com',
      mobile: '09120000000',
    },
  });
  console.log('✅ Super Admin "admin" seeded.');

  // 2. Create or Update Store Manager
  const storeManager = await prisma.user.upsert({
    where: { username: 'store' },
    update: {
      password: passwordHash,
      role: 'STORE_MANAGER',
      status: 'ACTIVE',
      firstName: 'مدیر',
      lastName: 'فروشگاه',
    },
    create: {
      username: 'store',
      password: passwordHash,
      role: 'STORE_MANAGER',
      status: 'ACTIVE',
      firstName: 'مدیر',
      lastName: 'فروشگاه',
      email: 'store@marketplace.com',
      mobile: '09121111111',
      storeName: 'فروشگاه تست بهان‌کالا',
      storeUrl: 'https://teststore.com',
    },
  });
  console.log('✅ Store Manager "store" seeded.');

  // 3. Create or Update Supplier
  const supplier = await prisma.user.upsert({
    where: { username: 'Testshop' },
    update: {
      password: passwordHash,
      role: 'SUPPLIER',
      status: 'ACTIVE',
      firstName: 'تامین‌کننده',
      lastName: 'تست',
    },
    create: {
      username: 'Testshop',
      password: passwordHash,
      role: 'SUPPLIER',
      status: 'ACTIVE',
      firstName: 'تامین‌کننده',
      lastName: 'تست',
      email: 'supplier@marketplace.com',
      mobile: '09122222222',
      brandName: 'تست‌شاپ',
      shaba: 'IR123456789012345678901234',
    },
  });
  console.log('✅ Supplier "Testshop" seeded.');

  // 4. Ensure Wallets exist
  const storeWallet = await prisma.wallet.upsert({
    where: { supplierId: storeManager.id },
    update: {},
    create: {
      supplierId: storeManager.id,
      balance: 50000000, // Pre-fund store wallet with 50,000,000 Rials (or Tomans)
    },
  });
  
  const supplierWallet = await prisma.wallet.upsert({
    where: { supplierId: supplier.id },
    update: {},
    create: {
      supplierId: supplier.id,
      balance: 0,
    },
  });
  console.log('✅ Wallets initialized.');

  // 5. Seed Categories
  const categoryMap = new Map<string, number>();
  for (const name of CATEGORIES) {
    const cat = await prisma.category.findFirst({ where: { name } });
    if (!cat) {
      const newCat = await prisma.category.create({ data: { name, isActive: true } });
      categoryMap.set(name, newCat.id);
    } else {
      categoryMap.set(name, cat.id);
    }
  }
  console.log('✅ Categories seeded.');

  // Get a category ID
  const digitalCatId = categoryMap.get('کالای دیجیتال') || 1;

  // 6. Seed some default products if empty
  const productCount = await prisma.product.count();
  if (productCount === 0) {
    await prisma.product.create({
      data: {
        supplierId: supplier.id,
        categoryId: digitalCatId,
        name: 'گوشی موبایل گلکسی S24',
        supplierBasePrice: 45000000,
        discount: 0,
        sku: 'GALAXY-S24',
        brand: 'سامسونگ',
        status: 'ACTIVE',
        marginType: 'PERCENTAGE',
        marginValue: 10,
        finalPrice: 49500000,
        inventory: 100,
        minOrderQuantity: 1,
      },
    });

    await prisma.product.create({
      data: {
        supplierId: supplier.id,
        categoryId: digitalCatId,
        name: 'لپ‌تاپ مک‌بوک پرو M3',
        supplierBasePrice: 85000000,
        discount: 500000,
        sku: 'MBP-M3',
        brand: 'اپل',
        status: 'ACTIVE',
        marginType: 'FIXED',
        marginValue: 2000000,
        finalPrice: 86500000,
        inventory: 50,
        minOrderQuantity: 1,
      },
    });
    console.log('✅ Mock products seeded.');
  }

  console.log('🎉 Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
