import express from 'express';
import registerAnnouncements from './src/services/announcementsRoute.js';
const app = express();
app.get('/test', (req, res) => { res.json({ ok: true }); });
registerAnnouncements(app);
const server = app.listen(3001, () => {
  fetch('http://localhost:3001/api/announcements')
    .then(res => res.text())
    .then(text => { console.log("Response:", text); server.close(); })
    .catch(err => { console.error(err); server.close(); });
});
