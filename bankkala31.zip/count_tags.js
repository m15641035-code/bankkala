import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');
const line339 = lines[338];

// We want to strip out everything inside curly braces { ... }
// since curly braces contain JS expressions (which can contain arrow functions => and comparison operators <, >)
let stripped = '';
let braceDepth = 0;

for (let i = 0; i < line339.length; i++) {
  const char = line339[i];
  if (char === '{') {
    if (braceDepth === 0) {
      // replace the whole brace expression with a placeholder that has no '<', '>', or '/'
      stripped += '"placeholder"';
    }
    braceDepth++;
  } else if (char === '}') {
    braceDepth--;
  } else {
    if (braceDepth === 0) {
      stripped += char;
    }
  }
}

// Now we can parse the tags on the stripped string
const tagRegex = /<\/?([a-zA-Z0-9]+)(?:\s+[^>]*)?>/g;
let match;
const stack = [];
const unmatched = [];

while ((match = tagRegex.exec(stripped)) !== null) {
  const fullTag = match[0];
  const tagName = match[1];
  const isClosing = fullTag.startsWith('</');
  const isSelfClosing = fullTag.endsWith('/>') || ['img', 'input', 'hr', 'br'].includes(tagName);

  if (isSelfClosing) {
    continue;
  }

  if (isClosing) {
    if (stack.length > 0) {
      const last = stack.pop();
      if (last.name !== tagName) {
        unmatched.push({ type: 'mismatch', expected: last.name, got: tagName, pos: match.index, context: stripped.substring(match.index - 50, match.index + 50) });
      }
    } else {
      unmatched.push({ type: 'extra_closing', name: tagName, pos: match.index, context: stripped.substring(match.index - 50, match.index + 50) });
    }
  } else {
    stack.push({ name: tagName, pos: match.index, full: fullTag });
  }
}

console.log('--- STRIPPED TAG BALANCE RESULTS ---');
console.log('Unmatched errors:', unmatched);
console.log('Remaining open stack:', stack.map(s => s.name));
if (stack.length > 0) {
  console.log('Remaining open tags with context:');
  stack.forEach(s => {
    console.log(`- <${s.name}> at pos ${s.pos}: ${stripped.substring(s.pos, s.pos + 100)}`);
  });
}
