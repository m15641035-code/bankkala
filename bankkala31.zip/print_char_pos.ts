import fs from 'fs';

const filePath = './src/components/supplier/SupplierDashboard.tsx';
const content = fs.readFileSync(filePath, 'utf8');

const positions = [6, 1744, 2305, 2529, 24999, 29079, 32733, 32767, 33341];

positions.forEach((pos, idx) => {
  console.log(`\n=== Position ${pos} (around ${pos}) ===`);
  const start = Math.max(0, pos - 50);
  const end = Math.min(content.length, pos + 250);
  console.log(content.substring(start, end));
});
