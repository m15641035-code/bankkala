const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const routeCode = `
app.get('/api/supplier/reports', authenticateToken, requireSupplier, async (req: any, res: any) => {
  try {
    const supplierId = req.user.userId;
    const { status, type, page = '1', limit = '10' } = req.query;

    const wallet = await prisma.wallet.findUnique({
      where: { supplierId },
    });

    if (!wallet) {
      return res.status(404).json({ error: 'Wallet not found' });
    }

    // Calculate total earnings (ORDER_REVENUE, COMPLETED)
    const earningsResult = await prisma.ledgerEntry.aggregate({
      where: {
        walletId: wallet.id,
        type: 'ORDER_REVENUE',
        status: 'COMPLETED'
      },
      _sum: { amount: true }
    });

    // Calculate total withdrawn (WITHDRAWAL, COMPLETED)
    const withdrawnResult = await prisma.ledgerEntry.aggregate({
      where: {
        walletId: wallet.id,
        type: 'WITHDRAWAL',
        status: 'COMPLETED'
      },
      _sum: { amount: true }
    });

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    
    // Build filter for history
    const whereClause: any = { walletId: wallet.id };
    if (status) whereClause.status = status;
    if (type) whereClause.type = type;

    const history = await prisma.ledgerEntry.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      skip: (pageNum - 1) * limitNum,
      take: limitNum
    });

    const totalHistory = await prisma.ledgerEntry.count({ where: whereClause });

    res.json({
      balance: wallet.balance.toString(),
      totalEarnings: (earningsResult._sum.amount || 0).toString(),
      totalWithdrawn: Math.abs(parseFloat((withdrawnResult._sum.amount || 0).toString())).toString(),
      history,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalHistory,
        totalPages: Math.ceil(totalHistory / limitNum)
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
`;

code = code.replace("app.get('/api/supplier/wallet', authenticateToken, requireSupplier, async (req: any, res) => {", routeCode + "\napp.get('/api/supplier/wallet', authenticateToken, requireSupplier, async (req: any, res) => {");

fs.writeFileSync('server.ts', code);
