const fs = require('fs');

let code = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Add indexes to LedgerEntry
code = code.replace(
  "wallet Wallet @relation(fields: [walletId], references: [id])\n}",
  "wallet Wallet @relation(fields: [walletId], references: [id])\n\n  @@index([walletId])\n  @@index([createdAt])\n  @@index([referenceId])\n}"
);

// Add indexes to PayoutRequest
code = code.replace(
  "wallet Wallet @relation(fields: [walletId], references: [id])\n}",
  "wallet Wallet @relation(fields: [walletId], references: [id])\n\n  @@index([walletId])\n  @@index([status])\n}"
);

fs.writeFileSync('prisma/schema.prisma', code);
