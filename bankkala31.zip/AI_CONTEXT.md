# AI Context

## Goal
To maintain and enhance the B2B marketplace platform.

## Architecture
- **Frontend**: React (SPA) + Vite.
- **Backend**: Express API server running on Node.js.
- **Database**: SQLite with Prisma ORM.

## Modules
- **SuperAdmin**: Dashboard for platform management.
- **Supplier**: Dashboard for inventory and order management.
- **StoreManager**: Dashboard for retail store management.
- **Financials**: Settlement and wallet system.
- **Integrations**: WooCommerce, Zibal.

## Status
- **Current**: Functional, but requires UI clean-up (contrast button removal, theme toggle fix).
- **Known Issues**: Chunk size warnings during build.

## Known Bugs
- Some UI components may have legacy theme-related styling issues.
- Build warnings regarding chunk sizes.
