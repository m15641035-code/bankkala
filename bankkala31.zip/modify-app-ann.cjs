const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Add import
code = code.replace("import { ThemeProvider", "import Announcements from './components/Announcements';\nimport { ThemeProvider");

// Find Login View render
const loginHeaderRegex = /<h1 className="text-3xl font-black text-slate-800 tracking-tight">/;
code = code.replace(loginHeaderRegex, "<Announcements role=\"ALL\" />\n                <h1 className=\"text-3xl font-black text-slate-800 tracking-tight\">");

fs.writeFileSync('src/App.tsx', code);
