const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function updateAdmin() {
  const adminPass = 'Bahankala@2026!';
  const hashedPassword = await bcrypt.hash(adminPass, 10);
  
  await prisma.user.updateMany({
    where: { username: 'admin' },
    data: { password: hashedPassword }
  });
  console.log('Admin password updated to Bahankala@2026!');
}

updateAdmin().catch(console.error).finally(() => prisma.$disconnect());
