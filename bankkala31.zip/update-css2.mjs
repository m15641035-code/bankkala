import fs from 'fs';

let css = fs.readFileSync('src/index.css', 'utf8');

// Append some base table and layout styles to index.css
const baseStyles = `
@layer base {
  /* Tables */
  table {
    @apply w-full text-right border-collapse;
  }
  
  th {
    @apply bg-surface text-text-muted font-bold text-xs py-4 px-4 border-b border-border-subtle sticky top-0 z-10;
  }

  td {
    @apply py-4 px-4 border-b border-border-subtle text-sm text-text-primary;
  }

  tr:hover td {
    @apply bg-surface/50 transition-colors;
  }
  
  /* Make zebra stripes very subtle */
  tbody tr:nth-child(even) td {
    background-color: color-mix(in srgb, var(--surface) 30%, transparent);
  }

  /* Consistent border radius and subtle shadows for cards */
  .bg-card {
    @apply rounded-[1.25rem] shadow-sm;
  }

  .dark .bg-card {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -2px rgba(0, 0, 0, 0.3), inset 0 1px 0 0 rgba(255, 255, 255, 0.05);
  }

  /* Typography improvements */
  h1, h2, h3, h4, h5, h6 {
    @apply text-text-primary tracking-tight;
  }

  label {
    @apply text-text-secondary font-medium;
  }
}
`;

fs.appendFileSync('src/index.css', baseStyles);
console.log('Appended table and card base styles.');
