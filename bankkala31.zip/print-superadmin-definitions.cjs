const fs = require('fs');
const content = fs.readFileSync('src/components/superadmin/SuperAdminDashboard.tsx', 'utf8');

// Find Overview, ProductsList etc. and print their vicinity
const words = ['Overview', 'ProductsList', 'OrdersList', 'Financial'];
for (const word of words) {
  const idx = content.indexOf(`function ${word}`);
  const idx2 = content.indexOf(`const ${word}`);
  const finalIdx = idx !== -1 ? idx : idx2;
  if (finalIdx !== -1) {
    console.log(`=== Context for ${word} ===`);
    console.log(content.substring(finalIdx, finalIdx + 500));
  }
}
