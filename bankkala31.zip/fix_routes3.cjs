const fs = require('fs');

function fixLine(code) {
  // Replace // ... app.get with /* ... */ app.get
  code = code.replace(/\/\/([^]*?)app\./g, '/* $1 */ app.');
  code = code.replace(/\/\/([^]*?)const /g, '/* $1 */ const ');
  code = code.replace(/\/\/([^]*?)let /g, '/* $1 */ let ');
  code = code.replace(/\/\/([^]*?)return /g, '/* $1 */ return ');
  code = code.replace(/\/\/([^]*?)res\./g, '/* $1 */ res.');
  code = code.replace(/\/\/([^]*?)await /g, '/* $1 */ await ');
  // any // followed by text then '}'
  code = code.replace(/\/\/([^]*?) \}/g, '/* $1 */ }');
  return code;
}

['src/services/announcementsRoute.ts', 'src/services/newFeaturesRoute.ts'].forEach(filename => {
  let code = fs.readFileSync(filename, 'utf8');
  fs.writeFileSync(filename, fixLine(code));
});
