const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

const line248 = lines[247]; // line 248 is index 247
console.log('Line 248 length:', line248?.length);

const regex = /\/\/[^'"`]*/g;
let match;
let count = 0;
while ((match = regex.exec(line248)) !== null) {
  count++;
  console.log(`[${count}] index: ${match.index}, text: ${match[0].substring(0, 100)}`);
}
